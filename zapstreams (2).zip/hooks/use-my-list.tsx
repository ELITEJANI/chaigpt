"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type MediaItem = {
  id: string
  title: string
  image: string
  rating?: string
  year?: string
  genres?: string[]
}

interface MyListContextType {
  myList: MediaItem[]
  addToMyList: (item: MediaItem) => void
  removeFromMyList: (id: string) => void
  clearMyList: () => void
}

const MyListContext = createContext<MyListContextType | undefined>(undefined)

export function MyListProvider({ children }: { children: ReactNode }) {
  const [myList, setMyList] = useState<MediaItem[]>([])

  // Load saved list from localStorage on mount
  useEffect(() => {
    const savedList = localStorage.getItem("zapstreams-mylist")
    if (savedList) {
      try {
        setMyList(JSON.parse(savedList))
      } catch (error) {
        console.error("Error parsing saved list:", error)
      }
    }
  }, [])

  // Save list to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("zapstreams-mylist", JSON.stringify(myList))
  }, [myList])

  const addToMyList = (item: MediaItem) => {
    setMyList((prev) => {
      // Check if item already exists
      if (prev.some((i) => i.id === item.id)) {
        return prev
      }
      return [...prev, item]
    })
  }

  const removeFromMyList = (id: string) => {
    setMyList((prev) => prev.filter((item) => item.id !== id))
  }

  const clearMyList = () => {
    setMyList([])
  }

  return (
    <MyListContext.Provider value={{ myList, addToMyList, removeFromMyList, clearMyList }}>
      {children}
    </MyListContext.Provider>
  )
}

export function useMyList() {
  const context = useContext(MyListContext)
  if (context === undefined) {
    throw new Error("useMyList must be used within a MyListProvider")
  }
  return context
}
