"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export type Profile = {
  id: string
  name: string
  avatar: string
  isKids: boolean
  isPinProtected: boolean
  pin?: string
  language: string
  maturityLevel: "all" | "7+" | "13+" | "16+" | "18+"
  autoplayEnabled: boolean
}

interface ProfilesContextType {
  profiles: Profile[]
  activeProfile: Profile | null
  addProfile: (profile: Omit<Profile, "id">) => void
  updateProfile: (id: string, data: Partial<Profile>) => void
  deleteProfile: (id: string) => void
  setActiveProfile: (id: string) => void
  validatePin: (id: string, pin: string) => boolean
}

const ProfilesContext = createContext<ProfilesContextType | undefined>(undefined)

const DEFAULT_PROFILES: Profile[] = [
  {
    id: "default",
    name: "Default",
    avatar: "/placeholder.svg?height=200&width=200",
    isKids: false,
    isPinProtected: false,
    language: "english",
    maturityLevel: "18+",
    autoplayEnabled: true,
  },
]

export function ProfilesProvider({ children }: { children: ReactNode }) {
  const [profiles, setProfiles] = useState<Profile[]>(DEFAULT_PROFILES)
  const [activeProfile, setActiveProfileState] = useState<Profile | null>(null)

  // Load saved profiles from localStorage on mount
  useEffect(() => {
    const savedProfiles = localStorage.getItem("zapstreams-profiles")
    if (savedProfiles) {
      try {
        setProfiles(JSON.parse(savedProfiles))
      } catch (error) {
        console.error("Error parsing saved profiles:", error)
      }
    }

    const activeProfileId = localStorage.getItem("zapstreams-active-profile")
    if (activeProfileId) {
      const profile = JSON.parse(savedProfiles || "[]").find((p: Profile) => p.id === activeProfileId)
      if (profile) {
        setActiveProfileState(profile)
      } else {
        setActiveProfileState(DEFAULT_PROFILES[0])
      }
    } else {
      setActiveProfileState(DEFAULT_PROFILES[0])
    }
  }, [])

  // Save profiles to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("zapstreams-profiles", JSON.stringify(profiles))
  }, [profiles])

  // Add a new profile
  const addProfile = (profile: Omit<Profile, "id">) => {
    const newProfile: Profile = {
      ...profile,
      id: `profile-${Date.now()}`,
    }
    setProfiles((prev) => [...prev, newProfile])
  }

  // Update a profile
  const updateProfile = (id: string, data: Partial<Profile>) => {
    setProfiles((prev) => {
      const updated = prev.map((profile) => (profile.id === id ? { ...profile, ...data } : profile))

      // If we're updating the active profile, update that too
      if (activeProfile && activeProfile.id === id) {
        const updatedActiveProfile = updated.find((p) => p.id === id)
        if (updatedActiveProfile) {
          setActiveProfileState(updatedActiveProfile)
        }
      }

      return updated
    })
  }

  // Delete a profile
  const deleteProfile = (id: string) => {
    // Don't allow deleting the last profile
    if (profiles.length <= 1) {
      return
    }

    setProfiles((prev) => {
      const filtered = prev.filter((profile) => profile.id !== id)

      // If we're deleting the active profile, set the first available profile as active
      if (activeProfile && activeProfile.id === id) {
        const newActiveProfile = filtered[0]
        setActiveProfileState(newActiveProfile)
        localStorage.setItem("zapstreams-active-profile", newActiveProfile.id)
      }

      return filtered
    })
  }

  // Set the active profile
  const setActiveProfile = (id: string) => {
    const profile = profiles.find((p) => p.id === id)
    if (profile) {
      setActiveProfileState(profile)
      localStorage.setItem("zapstreams-active-profile", id)
    }
  }

  // Validate a profile's PIN
  const validatePin = (id: string, pin: string) => {
    const profile = profiles.find((p) => p.id === id)
    return profile?.pin === pin
  }

  return (
    <ProfilesContext.Provider
      value={{
        profiles,
        activeProfile,
        addProfile,
        updateProfile,
        deleteProfile,
        setActiveProfile,
        validatePin,
      }}
    >
      {children}
    </ProfilesContext.Provider>
  )
}

export function useProfiles() {
  const context = useContext(ProfilesContext)
  if (context === undefined) {
    throw new Error("useProfiles must be used within a ProfilesProvider")
  }
  return context
}
