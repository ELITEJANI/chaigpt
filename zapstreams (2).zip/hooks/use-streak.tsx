"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { toast } from "@/hooks/use-toast"

interface StreakContextType {
  currentStreak: number
  lastWatched: Date | null
  badges: string[]
  incrementStreak: () => void
  resetStreak: () => void
}

const StreakContext = createContext<StreakContextType | undefined>(undefined)

export function StreakProvider({ children }: { children: ReactNode }) {
  const [currentStreak, setCurrentStreak] = useState(0)
  const [lastWatched, setLastWatched] = useState<Date | null>(null)
  const [badges, setBadges] = useState<string[]>([])

  // Load streak data from localStorage on mount
  useEffect(() => {
    const savedStreak = localStorage.getItem("zapstreams-streak")
    const savedLastWatched = localStorage.getItem("zapstreams-last-watched")
    const savedBadges = localStorage.getItem("zapstreams-badges")

    if (savedStreak) {
      setCurrentStreak(Number.parseInt(savedStreak, 10))
    }

    if (savedLastWatched) {
      setLastWatched(new Date(savedLastWatched))
    }

    if (savedBadges) {
      try {
        setBadges(JSON.parse(savedBadges))
      } catch (error) {
        console.error("Error parsing saved badges:", error)
      }
    }

    // Check if streak should be reset (more than 48 hours since last watch)
    if (savedLastWatched) {
      const lastDate = new Date(savedLastWatched)
      const now = new Date()
      const hoursDiff = (now.getTime() - lastDate.getTime()) / (1000 * 60 * 60)

      if (hoursDiff > 48) {
        setCurrentStreak(0)
        localStorage.setItem("zapstreams-streak", "0")
      }
    }
  }, [])

  // Save streak data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("zapstreams-streak", currentStreak.toString())

    if (lastWatched) {
      localStorage.setItem("zapstreams-last-watched", lastWatched.toISOString())
    }

    localStorage.setItem("zapstreams-badges", JSON.stringify(badges))
  }, [currentStreak, lastWatched, badges])

  // Increment streak when user watches something
  const incrementStreak = () => {
    const now = new Date()

    // If this is the first watch or it's been more than 20 hours since last watch
    if (!lastWatched || now.getTime() - lastWatched.getTime() > 20 * 60 * 60 * 1000) {
      const newStreak = currentStreak + 1
      setCurrentStreak(newStreak)
      setLastWatched(now)

      // Check for streak milestones and award badges
      if (newStreak === 3) {
        const newBadge = "3-day-streak"
        if (!badges.includes(newBadge)) {
          setBadges([...badges, newBadge])
          toast({
            title: "🔥 3-Day Streak!",
            description: "You've earned the 3-Day Streak badge!",
          })
        }
      } else if (newStreak === 7) {
        const newBadge = "7-day-streak"
        if (!badges.includes(newBadge)) {
          setBadges([...badges, newBadge])
          toast({
            title: "🔥 7-Day Streak!",
            description: "You've earned the 7-Day Streak badge and unlocked a special theme!",
          })
        }
      } else if (newStreak === 30) {
        const newBadge = "30-day-streak"
        if (!badges.includes(newBadge)) {
          setBadges([...badges, newBadge])
          toast({
            title: "🔥 30-Day Streak!",
            description: "You've earned the 30-Day Streak badge! You're a true ZapStreams fan!",
          })
        }
      }

      // Show streak notification
      if (newStreak > 1) {
        toast({
          title: `🔥 ${newStreak}-Day Streak!`,
          description: "Keep watching daily to earn badges and unlock special themes!",
        })
      }
    }
  }

  // Reset streak
  const resetStreak = () => {
    setCurrentStreak(0)
    setLastWatched(null)
  }

  return (
    <StreakContext.Provider value={{ currentStreak, lastWatched, badges, incrementStreak, resetStreak }}>
      {children}
    </StreakContext.Provider>
  )
}

export function useStreak() {
  const context = useContext(StreakContext)
  if (context === undefined) {
    throw new Error("useStreak must be used within a StreakProvider")
  }
  return context
}
