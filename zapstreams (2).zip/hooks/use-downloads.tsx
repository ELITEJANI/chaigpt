"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type DownloadStatus = "queued" | "downloading" | "paused" | "completed" | "error"

export type DownloadItem = {
  id: string
  title: string
  image: string
  progress: number
  size: string
  status: DownloadStatus
  url: string
  localUrl?: string
  dateAdded: number
  type: "movie" | "series"
  episode?: {
    season: number
    number: number
    title: string
  }
}

interface DownloadsContextType {
  downloads: DownloadItem[]
  addDownload: (item: Omit<DownloadItem, "progress" | "status" | "dateAdded" | "localUrl">) => void
  removeDownload: (id: string) => void
  pauseDownload: (id: string) => void
  resumeDownload: (id: string) => void
  getDownload: (id: string) => DownloadItem | undefined
  isDownloaded: (id: string) => boolean
}

const DownloadsContext = createContext<DownloadsContextType | undefined>(undefined)

export function DownloadsProvider({ children }: { children: ReactNode }) {
  const [downloads, setDownloads] = useState<DownloadItem[]>([])

  // Load saved downloads from localStorage on mount
  useEffect(() => {
    const savedDownloads = localStorage.getItem("zapstreams-downloads")
    if (savedDownloads) {
      try {
        setDownloads(JSON.parse(savedDownloads))
      } catch (error) {
        console.error("Error parsing saved downloads:", error)
      }
    }
  }, [])

  // Save downloads to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("zapstreams-downloads", JSON.stringify(downloads))
  }, [downloads])

  // Simulate download progress
  useEffect(() => {
    const interval = setInterval(() => {
      setDownloads((prevDownloads) => {
        let updated = false
        const newDownloads = prevDownloads.map((download) => {
          if (download.status === "downloading" && download.progress < 100) {
            updated = true
            const newProgress = Math.min(download.progress + 5, 100)
            return {
              ...download,
              progress: newProgress,
              status: newProgress === 100 ? "completed" : "downloading",
              // When download completes, store a local URL
              ...(newProgress === 100 && { localUrl: download.url }),
            }
          }
          return download
        })
        return updated ? newDownloads : prevDownloads
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  // Add a new download
  const addDownload = (item: Omit<DownloadItem, "progress" | "status" | "dateAdded" | "localUrl">) => {
    // Check if already exists
    if (downloads.some((d) => d.id === item.id)) {
      return
    }

    const newDownload: DownloadItem = {
      ...item,
      progress: 0,
      status: "downloading",
      dateAdded: Date.now(),
    }

    setDownloads((prev) => [...prev, newDownload])
  }

  // Remove a download
  const removeDownload = (id: string) => {
    setDownloads((prev) => prev.filter((download) => download.id !== id))
  }

  // Pause a download
  const pauseDownload = (id: string) => {
    setDownloads((prev) =>
      prev.map((download) =>
        download.id === id && download.status === "downloading" ? { ...download, status: "paused" } : download,
      ),
    )
  }

  // Resume a download
  const resumeDownload = (id: string) => {
    setDownloads((prev) =>
      prev.map((download) =>
        download.id === id && download.status === "paused" ? { ...download, status: "downloading" } : download,
      ),
    )
  }

  // Get a specific download
  const getDownload = (id: string) => {
    return downloads.find((download) => download.id === id)
  }

  // Check if a media is downloaded
  const isDownloaded = (id: string) => {
    return downloads.some((download) => download.id === id && download.status === "completed")
  }

  return (
    <DownloadsContext.Provider
      value={{
        downloads,
        addDownload,
        removeDownload,
        pauseDownload,
        resumeDownload,
        getDownload,
        isDownloaded,
      }}
    >
      {children}
    </DownloadsContext.Provider>
  )
}

export function useDownloads() {
  const context = useContext(DownloadsContext)
  if (context === undefined) {
    throw new Error("useDownloads must be used within a DownloadsProvider")
  }
  return context
}
