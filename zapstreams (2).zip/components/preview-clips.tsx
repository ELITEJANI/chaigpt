"use client"

import { useState, useRef } from "react"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Play } from "lucide-react"
import Image from "next/image"

interface Clip {
  id: string
  title: string
  thumbnail: string
  videoSrc: string
  duration: string
}

interface PreviewClipsProps {
  clips: Clip[]
}

export function PreviewClips({ clips }: PreviewClipsProps) {
  const [selectedClip, setSelectedClip] = useState<Clip | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  if (!clips || clips.length === 0) {
    return null
  }

  const handleClipClick = (clip: Clip) => {
    setSelectedClip(clip)
  }

  const handleDialogChange = (open: boolean) => {
    if (!open && videoRef.current) {
      videoRef.current.pause()
    }
    if (!open) {
      setSelectedClip(null)
    }
  }

  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold mb-6">Preview Clips</h2>
      <ScrollArea className="w-full">
        <div className="flex space-x-4 pb-4">
          {clips.map((clip) => (
            <div
              key={clip.id}
              className="relative w-[280px] flex-shrink-0 cursor-pointer group"
              onClick={() => handleClipClick(clip)}
            >
              <div className="relative aspect-video overflow-hidden rounded-md">
                <Image
                  src={clip.thumbnail || "/placeholder.svg"}
                  alt={clip.title}
                  fill
                  className="object-cover transition-all group-hover:scale-105"
                  sizes="280px"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="rounded-full bg-black/50 p-3">
                    <Play className="h-8 w-8" />
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs">{clip.duration}</div>
              </div>
              <h3 className="mt-2 text-sm font-medium line-clamp-1">{clip.title}</h3>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      <Dialog open={!!selectedClip} onOpenChange={handleDialogChange}>
        <DialogContent className="max-w-4xl p-0 bg-black border-white/10">
          {selectedClip && (
            <div className="relative aspect-video w-full">
              <video
                ref={videoRef}
                src={selectedClip.videoSrc}
                controls
                autoPlay
                className="w-full h-full"
                poster={selectedClip.thumbnail}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
