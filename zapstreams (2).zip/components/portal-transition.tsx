"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { usePathname } from "next/navigation"

interface PortalTransitionProps {
  children: React.ReactNode
}

export function PortalTransition({ children }: PortalTransitionProps) {
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [content, setContent] = useState(children)
  const pathname = usePathname()

  // Listen for path changes
  useEffect(() => {
    setIsTransitioning(true)

    const timer = setTimeout(() => {
      setContent(children)
      setIsTransitioning(false)
    }, 800)

    return () => clearTimeout(timer)
  }, [pathname, children])

  return (
    <div className="bg-black min-h-screen">
      <AnimatePresence mode="wait">
        {isTransitioning ? (
          <motion.div
            key="portal"
            className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none bg-black"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: [0, 1, 30], opacity: [0, 1, 0] }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ duration: 0.8, times: [0, 0.3, 1] }}
              className="w-40 h-40 rounded-full bg-gradient-to-r from-zapred via-zapred/50 to-black/50 animate-spin"
            />
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
