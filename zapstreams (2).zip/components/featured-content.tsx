"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Play, Info, ChevronLeft, ChevronRight } from "lucide-react"
import { useState, useEffect, useRef } from "react"

interface FeaturedContentProps {
  featuredItems: Array<{
    id: string
    title: string
    description: string
    image: string
    rating: string
    genres: string[]
    year?: string
  }>
  initialIndex?: number
  onChangeBackground: (id: string) => void
}

export function FeaturedContent({ featuredItems, initialIndex = 0, onChangeBackground }: FeaturedContentProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex)
  const currentItem = featuredItems[currentIndex]
  const firstRender = useRef(true)

  // Auto-rotate featured content every 45 seconds exactly
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % featuredItems.length)
    }, 45000) // 45 seconds

    return () => clearInterval(interval)
  }, [featuredItems.length])

  // Only call onChangeBackground when currentIndex changes, not during initial render
  useEffect(() => {
    // Skip the first render to avoid the initial state update
    if (firstRender.current) {
      firstRender.current = false
      return
    }

    onChangeBackground(featuredItems[currentIndex].id)
  }, [currentIndex, featuredItems, onChangeBackground])

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? featuredItems.length - 1 : prevIndex - 1))
  }

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % featuredItems.length)
  }

  return (
    <div className="relative h-[80vh] w-full overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16 z-10">
        <div className="max-w-2xl bg-black/20 p-6 rounded-lg border border-white/10">
          <h1 className="text-5xl font-bold text-zapred mb-4">{currentItem.title}</h1>
          <p className="mb-6 text-lg text-white">{currentItem.description}</p>

          <div className="mb-6 flex flex-wrap gap-2">
            {currentItem.genres.map((genre) => (
              <Badge
                key={genre}
                variant="outline"
                className="rounded-full border border-white/20 bg-black/30 px-4 py-1 text-sm"
              >
                {genre}
              </Badge>
            ))}
            <Badge variant="outline" className="rounded-full border border-white/20 bg-black/30 px-4 py-1 text-sm">
              ⭐ {currentItem.rating}
            </Badge>
            {currentItem.year && (
              <Badge variant="outline" className="rounded-full border border-white/20 bg-black/30 px-4 py-1 text-sm">
                {currentItem.year}
              </Badge>
            )}
          </div>

          <div className="flex flex-wrap gap-4">
            <Button asChild size="lg" className="bg-zapred hover:bg-zapred/90">
              <Link href={`/media/${currentItem.id}`}>
                <Play className="mr-2 h-4 w-4" />
                Play Now
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href={`/media/${currentItem.id}`}>
                <Info className="mr-2 h-4 w-4" />
                Details
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Carousel controls */}
      <div className="absolute bottom-1/2 left-4 z-10">
        <Button variant="outline" size="icon" className="rounded-full bg-black/30 border-white/20" onClick={handlePrev}>
          <ChevronLeft className="h-6 w-6" />
        </Button>
      </div>
      <div className="absolute bottom-1/2 right-4 z-10">
        <Button variant="outline" size="icon" className="rounded-full bg-black/30 border-white/20" onClick={handleNext}>
          <ChevronRight className="h-6 w-6" />
        </Button>
      </div>

      {/* Carousel indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 flex gap-2">
        {featuredItems.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full ${index === currentIndex ? "bg-zapred" : "bg-white/30"}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  )
}
