import Link from "next/link"
import { Logo } from "./logo"
import { Button } from "@/components/ui/button"
import { Search, Download, List, Sparkles } from "lucide-react"
import { ProfileDropdown } from "./profile-dropdown"

export function Navbar() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-black/80 to-transparent">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Logo />
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium hover:text-white/80 transition-colors">
              Home
            </Link>
            <Link href="/browse" className="text-sm font-medium hover:text-white/80 transition-colors">
              Browse
            </Link>
            <Link href="/my-list" className="text-sm font-medium hover:text-white/80 transition-colors">
              My List
            </Link>
            <Link href="/downloads" className="text-sm font-medium hover:text-white/80 transition-colors">
              Downloads
            </Link>
            <Link
              href="/surprise-me"
              className="text-sm font-medium text-zapred hover:text-zapred/80 transition-colors flex items-center gap-1"
            >
              <Sparkles className="h-4 w-4" />
              Surprise Me
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/search">
            <Button variant="ghost" size="icon" className="text-white">
              <Search className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/my-list" className="md:hidden">
            <Button variant="ghost" size="icon" className="text-white">
              <List className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/downloads" className="md:hidden">
            <Button variant="ghost" size="icon" className="text-white">
              <Download className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/surprise-me" className="md:hidden">
            <Button variant="ghost" size="icon" className="text-zapred">
              <Sparkles className="h-5 w-5" />
            </Button>
          </Link>
          <ProfileDropdown />
        </div>
      </div>
    </header>
  )
}
