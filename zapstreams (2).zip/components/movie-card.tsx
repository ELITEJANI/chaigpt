"use client"

import type React from "react"

import Image from "next/image"
import { useState, useRef, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Play, Plus, Info, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import { useMyList } from "@/hooks/use-my-list"

interface MovieCardProps {
  id: string
  title: string
  image: string
  rating?: string
  year?: string
  genres?: string[]
  description?: string
  badges?: string[]
  isNew?: boolean
  is4K?: boolean
  isDolbyAtmos?: boolean
  isTopTen?: boolean
  onFocus?: (id: string) => void
  trailerSrc?: string
  posterSrc?: string
}

export function MovieCard({
  id,
  title,
  image,
  rating,
  year,
  genres,
  description,
  badges = [],
  isNew,
  is4K,
  isDolbyAtmos,
  isTopTen,
  onFocus,
  trailerSrc,
  posterSrc,
}: MovieCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isVantageMode, setIsVantageMode] = useState(false)
  const [isTrailerPlaying, setIsTrailerPlaying] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const cardRef = useRef<HTMLDivElement>(null)
  const popupRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const { myList, addToMyList, removeFromMyList } = useMyList()
  const isInMyList = myList.some((item) => item.id === id)

  // Videos to use for trailers
  const videos: Record<string, string> = {
    "big-buck-bunny": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "tears-of-steel": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    default: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  }

  // Poster images for free media
  const posters: Record<string, string> = {
    "big-buck-bunny": "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
    "tears-of-steel": "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
  }

  const videoSrc = trailerSrc || videos[id] || videos.default
  const actualImage = posterSrc || posters[id] || image

  // Adjust popup position to ensure it's fully visible
  const adjustPopupPosition = () => {
    if (!cardRef.current || !popupRef.current) return

    const cardRect = cardRef.current.getBoundingClientRect()
    const popupRect = popupRef.current.getBoundingClientRect()
    const viewportHeight = window.innerHeight
    const viewportWidth = window.innerWidth

    // Check if popup would go below viewport
    if (cardRect.bottom + popupRect.height > viewportHeight) {
      popupRef.current.style.bottom = "100%"
      popupRef.current.style.top = "auto"
      popupRef.current.style.marginBottom = "8px"
      popupRef.current.style.marginTop = "0"
    } else {
      popupRef.current.style.top = "100%"
      popupRef.current.style.bottom = "auto"
      popupRef.current.style.marginTop = "8px"
      popupRef.current.style.marginBottom = "0"
    }

    // Check if popup would go beyond right edge
    if (cardRect.left + popupRect.width > viewportWidth) {
      const overflow = cardRect.left + popupRect.width - viewportWidth
      popupRef.current.style.left = `-${overflow}px`
    } else {
      popupRef.current.style.left = "0"
    }
  }

  const handleMouseEnter = () => {
    setIsHovered(true)
    if (onFocus) onFocus(id)

    // Start timer for vantage mode
    timeoutRef.current = setTimeout(() => {
      setIsVantageMode(true)
    }, 2000)

    // Start playing trailer
    if (videoRef.current) {
      videoRef.current.currentTime = 0
      videoRef.current
        .play()
        .then(() => setIsTrailerPlaying(true))
        .catch((error) => console.error("Error playing trailer:", error))
    }

    // Adjust popup position after a small delay to ensure it's rendered
    setTimeout(adjustPopupPosition, 10)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
    setIsVantageMode(false)
    setIsTrailerPlaying(false)

    // Clear the timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
      timeoutRef.current = null
    }

    // Pause trailer
    if (videoRef.current) {
      videoRef.current.pause()
    }
  }

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    router.push(`/media/${id}`)
  }

  const handleAddToMyList = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (isInMyList) {
      removeFromMyList(id)
    } else {
      addToMyList({
        id,
        title,
        image: actualImage,
        rating,
        year,
        genres,
      })
    }
  }

  // Adjust popup position on window resize
  useEffect(() => {
    if (isHovered) {
      window.addEventListener("resize", adjustPopupPosition)
      window.addEventListener("scroll", adjustPopupPosition)
      return () => {
        window.removeEventListener("resize", adjustPopupPosition)
        window.removeEventListener("scroll", adjustPopupPosition)
      }
    }
  }, [isHovered])

  return (
    <div
      ref={cardRef}
      className={cn(
        "relative transition-all duration-300 z-0",
        isHovered ? "z-50" : "",
        isVantageMode ? "scale-125" : "",
      )}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
    >
      <div
        className={cn(
          "movie-card block w-[160px] flex-shrink-0 cursor-pointer transition-all duration-300",
          isVantageMode ? "transform-gpu scale-110" : "",
        )}
      >
        <div className="relative aspect-[2/3] overflow-hidden rounded-md">
          {/* Image or Video */}
          {isTrailerPlaying ? (
            <video
              ref={videoRef}
              src={videoSrc}
              className="absolute inset-0 h-full w-full object-cover"
              muted
              loop
              playsInline
            />
          ) : (
            <Image
              src={actualImage || "/placeholder.svg"}
              alt={title}
              fill
              className={cn("object-cover transition-transform duration-700", isVantageMode ? "scale-110" : "")}
              sizes="(max-width: 768px) 160px, 160px"
            />
          )}

          {/* Badges overlay */}
          <div className="absolute top-2 left-2 flex flex-wrap gap-1">
            {isNew && (
              <Badge variant="outline" className="bg-zapred/80 text-white text-xs backdrop-blur-sm border-none">
                NEW
              </Badge>
            )}
            {is4K && (
              <Badge variant="outline" className="bg-black/50 text-white text-xs backdrop-blur-sm border-white/20">
                4K HDR
              </Badge>
            )}
            {isDolbyAtmos && (
              <Badge variant="outline" className="bg-black/50 text-white text-xs backdrop-blur-sm border-white/20">
                ATMOS
              </Badge>
            )}
            {isTopTen && (
              <Badge variant="outline" className="bg-black/50 text-white text-xs backdrop-blur-sm border-white/20">
                TOP 10
              </Badge>
            )}
          </div>

          {/* Rating badge */}
          {rating && (
            <div className="absolute bottom-2 right-2">
              <Badge variant="outline" className="bg-black/50 text-white text-xs backdrop-blur-sm border-white/20">
                ⭐ {rating}
              </Badge>
            </div>
          )}
        </div>

        {/* Title */}
        <h3 className="mt-2 text-sm font-medium truncate">{title}</h3>

        {/* Quick Info Popup - Always render but conditionally show */}
        <div
          ref={popupRef}
          className={`absolute top-full left-0 right-0 bg-black/90 backdrop-blur-md rounded-md p-3 shadow-lg border border-white/10 z-[100] transition-opacity duration-300 w-[200px] ${
            isHovered ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
          style={{
            marginTop: "8px",
            transform: "translateY(0)", // Ensure it's not affected by parent transforms
          }}
        >
          <h4 className="font-bold text-sm mb-1">{title}</h4>
          {year && <div className="text-xs text-white/70 mb-1">{year}</div>}
          {genres && genres.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              {genres.slice(0, 2).map((genre) => (
                <span key={genre} className="text-xs text-white/70">
                  {genre}
                </span>
              ))}
            </div>
          )}
          <div className="flex gap-1">
            <Button size="icon" className="h-7 w-7 rounded-full bg-zapred hover:bg-zapred/90">
              <Play className="h-3 w-3" />
            </Button>
            <Button size="icon" variant="outline" className="h-7 w-7 rounded-full" onClick={handleAddToMyList}>
              {isInMyList ? <Check className="h-3 w-3" /> : <Plus className="h-3 w-3" />}
            </Button>
            <Button size="icon" variant="outline" className="h-7 w-7 rounded-full">
              <Info className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
