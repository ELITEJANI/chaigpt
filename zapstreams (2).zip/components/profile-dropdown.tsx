"use client"

import { useState } from "react"
import { User, Settings, LogOut, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Link from "next/link"
import { useTheme } from "next-themes"
import { useProfiles } from "@/hooks/use-profiles"
import { StreakBadge } from "./streak-badge"
import Image from "next/image"

export function ProfileDropdown() {
  const [open, setOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const { activeProfile, profiles } = useProfiles()

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="rounded-full">
          {activeProfile?.avatar ? (
            <div className="h-8 w-8 rounded-full overflow-hidden">
              <Image
                src={activeProfile.avatar || "/placeholder.svg"}
                alt={activeProfile.name}
                width={32}
                height={32}
                className="object-cover"
                crossOrigin="anonymous"
                unoptimized={true}
              />
            </div>
          ) : (
            <User className="h-5 w-5" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-black/90 backdrop-blur-md border-white/10">
        {activeProfile && (
          <div className="px-2 py-1.5 text-sm font-medium">
            <div className="flex items-center justify-between">
              <span className="text-white/70">{activeProfile.name}</span>
              <StreakBadge />
            </div>
          </div>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/profiles" className="flex items-center">
            <User className="mr-2 h-4 w-4" />
            Manage Profiles
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link href="/settings" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="flex items-center">
          {theme === "dark" ? <Sun className="mr-2 h-4 w-4" /> : <Moon className="mr-2 h-4 w-4" />}
          {theme === "dark" ? "Light Mode" : "Dark Mode"}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="flex items-center">
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
