"use client"

import { useState } from "react"
import Image from "next/image"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

interface AvatarSelectorProps {
  currentAvatar: string
  onSelect: (avatar: string) => void
}

export function AvatarSelector({ currentAvatar, onSelect }: AvatarSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState(currentAvatar)

  // Avatar options
  const avatarOptions = [
    "/placeholder.svg?height=200&width=200",
    "https://media-hosting.imagekit.io/1273cbc2c8ec4674/netflix-profile-pictures-1000-x-1000-qo9h82134t9nv0j0.jpg",
    "https://media-hosting.imagekit.io/729b3c652c2740d2/netflix-profile-pictures-5yup5hd2i60x7ew3.jpg",
    "https://media-hosting.imagekit.io/5ee7017bd1f24306/OIP.jpg",
    "https://media-hosting.imagekit.io/6a1c536df0004bd3/visualThumbnail1626625@2x.jpg",
    "https://media-hosting.imagekit.io/c3911e2bb1ea4d00/cute-animals-forest-farm-domestic-polar-in-cartoon-style-giraffe-elephant-crab-rabbit-fox-chick-deer-hippo-lion-zebra-free-vector.jpg",
    "https://media-hosting.imagekit.io/cedd64dd1f2d4b26/OIP%20(1).jpg",
    "https://media-hosting.imagekit.io/f303f0f3c1764945/OIP%20(2).jpg",
    "https://media-hosting.imagekit.io/83ca72eb54864c25/OIP%20(3).jpg",
  ]

  const handleSelect = () => {
    onSelect(selectedAvatar)
    setIsOpen(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Change Avatar</Button>
      </DialogTrigger>
      <DialogContent className="bg-black/90 border-white/10 max-w-3xl">
        <DialogHeader>
          <DialogTitle>Select Avatar</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-3 md:grid-cols-4 gap-4 py-4">
          {avatarOptions.map((avatar, index) => (
            <div key={index} className="relative cursor-pointer" onClick={() => setSelectedAvatar(avatar)}>
              <div
                className={`relative h-24 w-24 md:h-32 md:w-32 overflow-hidden rounded-md border-2 ${
                  selectedAvatar === avatar ? "border-zapred" : "border-transparent"
                }`}
              >
                <Image
                  src={avatar || "/placeholder.svg"}
                  alt={`Avatar option ${index + 1}`}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 96px, 128px"
                  crossOrigin="anonymous"
                  unoptimized={true}
                />
                {selectedAvatar === avatar && (
                  <div className="absolute inset-0 bg-zapred/20 flex items-center justify-center">
                    <Check className="h-8 w-8 text-white" />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button className="bg-zapred hover:bg-zapred/90" onClick={handleSelect}>
            Select Avatar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
