"use client"

import { Zap } from "lucide-react"
import Link from "next/link"
import { useTheme } from "next-themes"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"

export function Logo() {
  const { theme } = useTheme()
  const [accentColor, setAccentColor] = useState("zapred")

  // Load saved accent color on component mount
  useEffect(() => {
    const savedAccentColor = localStorage.getItem("zapstreams-accent-color")
    if (savedAccentColor) {
      setAccentColor(savedAccentColor)
    }
  }, [])

  // Listen for accent color changes
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "zapstreams-accent-color" && e.newValue) {
        setAccentColor(e.newValue)
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  // Determine the accent color class
  const getAccentColorClass = () => {
    return `text-${accentColor}`
  }

  // Determine the animation class
  const getAnimationClass = () => {
    switch (accentColor) {
      case "zapred":
        return "animate-pulse"
      case "zapblue":
        return "animate-pulse-blue"
      case "zapgreen":
        return "animate-pulse-green"
      case "zappurple":
        return "animate-pulse-purple"
      case "zapyellow":
        return "animate-pulse-yellow"
      case "zapgray":
        return "animate-pulse-gray"
      default:
        return "animate-pulse"
    }
  }

  return (
    <Link href="/" className="flex items-center gap-1 group">
      <span
        className={cn(
          "text-2xl font-bold transition-all duration-300 group-hover:text-opacity-90",
          getAccentColorClass(),
        )}
      >
        Zap
      </span>
      <Zap className={cn("h-5 w-5", getAnimationClass(), getAccentColorClass())} />
      <span className="text-2xl font-bold transition-all duration-300 group-hover:text-white/90">STREAMS</span>
    </Link>
  )
}
