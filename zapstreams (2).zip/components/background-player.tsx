"use client"

import { useEffect, useRef } from "react"

interface BackgroundPlayerProps {
  videoId: string
  posterImage: string
}

export function BackgroundPlayer({ videoId, posterImage }: BackgroundPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  // Videos to use
  const videos: Record<string, string> = {
    "big-buck-bunny": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "tears-of-steel": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    "elephant-dream": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    sintel: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    "for-bigger-blazes": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    "for-bigger-escapes": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    "for-bigger-fun": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    "for-bigger-joyrides": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    "for-bigger-meltdowns": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    default: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  }

  const videoSrc = videos[videoId] || videos.default

  // Ensure video is loaded and ready to play with sound
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    // Keep video muted to allow autoplay
    video.muted = true
    video.volume = 0

    // Create a flag to track if component is still mounted
    let isMounted = true

    // Play the video with proper error handling
    const playVideo = async () => {
      if (video.paused && !video.ended) {
        try {
          await video.play()
        } catch (err) {
          // Only log errors if the component is still mounted
          if (isMounted) {
            console.error("Error playing video:", err)
          }
        }
      }
    }

    // Add event listener for when video is ready to play
    const handleCanPlay = () => {
      if (isMounted) {
        playVideo()
      }
    }

    video.addEventListener("canplay", handleCanPlay)

    // Initial play attempt
    if (video.readyState >= 3) {
      // HAVE_FUTURE_DATA or higher
      playVideo()
    }

    // Cleanup function
    return () => {
      isMounted = false
      video.removeEventListener("canplay", handleCanPlay)

      // Cancel any pending play operation by pausing the video
      if (!video.paused) {
        video.pause()
      }
    }
  }, [videoSrc])

  return (
    <div className="fixed inset-0 w-full h-full" style={{ zIndex: 0 }}>
      <video
        ref={videoRef}
        src={videoSrc}
        poster={posterImage}
        autoPlay
        muted
        loop
        playsInline
        className="absolute inset-0 h-full w-full object-cover"
      />
      {/* Subtle gradient at the bottom for text readability */}
      <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black/70 to-transparent pointer-events-none" />
    </div>
  )
}
