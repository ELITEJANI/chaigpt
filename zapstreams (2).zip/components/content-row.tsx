"use client"

import { MovieCard } from "./movie-card"
import { useState } from "react"

interface ContentRowProps {
  title: string
  movies: {
    id: string
    title: string
    image: string
    rating?: string
    year?: string
    genres?: string[]
    description?: string
    badges?: string[]
    isNew?: boolean
    is4K?: boolean
    isDolbyAtmos?: boolean
    isTopTen?: boolean
  }[]
  onFocusChange?: (id: string) => void
}

export function ContentRow({ title, movies, onFocusChange }: ContentRowProps) {
  const [focusedId, setFocusedId] = useState<string | null>(null)

  const handleFocus = (id: string) => {
    setFocusedId(id)
    if (onFocusChange) {
      onFocusChange(id)
    }
  }

  return (
    <div className="mb-16">
      <h2 className="mb-4 text-xl font-bold">{title}</h2>
      <div className="flex gap-4 overflow-x-auto overflow-y-visible py-8 scrollbar-hide">
        {movies.map((movie) => (
          <MovieCard key={movie.id} {...movie} onFocus={handleFocus} />
        ))}
      </div>
    </div>
  )
}
