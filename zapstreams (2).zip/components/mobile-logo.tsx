import { Zap } from "lucide-react"
import Link from "next/link"

export function MobileLogo() {
  return (
    <Link href="/" className="flex items-center gap-1">
      <span className="text-zapred text-xl font-bold">Zap</span>
      <Zap className="h-4 w-4 text-zapred" />
      <span className="text-xl font-bold">STREAMS</span>
    </Link>
  )
}
