"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Play, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface TopPicksProps {
  picks: Array<{
    id: string
    title: string
    description: string
    image: string
    backdropImage: string
    posterImage: string
    rating: string
    genres: string[]
    year: string
    match?: number
  }>
}

export function TopPicks({ picks }: TopPicksProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isHovering, setIsHovering] = useState(false)

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? picks.length - 1 : prevIndex - 1))
  }

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % picks.length)
  }

  const currentPick = picks[currentIndex]

  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold mb-4">TOP PICKS FOR YOU</h2>

      <div className="relative">
        {/* Navigation buttons */}
        <Button
          variant="outline"
          size="icon"
          className="absolute left-2 top-1/2 -translate-y-1/2 z-10 rounded-full bg-black/50 border-white/20"
          onClick={handlePrev}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          className="absolute right-2 top-1/2 -translate-y-1/2 z-10 rounded-full bg-black/50 border-white/20"
          onClick={handleNext}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>

        {/* Main content */}
        <div
          className="relative overflow-hidden rounded-lg"
          onMouseEnter={() => setIsHovering(true)}
          onMouseLeave={() => setIsHovering(false)}
        >
          {/* Background image */}
          <div className="relative aspect-[21/9] w-full">
            <Image
              src={currentPick.backdropImage || currentPick.image || "/placeholder.svg"}
              alt={currentPick.title}
              fill
              className={cn("object-cover transition-transform duration-700", isHovering ? "scale-105" : "")}
              priority
            />

            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
          </div>

          {/* Content overlay */}
          <div className="absolute top-0 left-0 p-6 md:p-10 flex flex-col h-full justify-center max-w-lg">
            <div className="flex items-center gap-2 mb-2">
              <Badge className="bg-zapred border-none">TOP PICK</Badge>
              {currentPick.match && (
                <Badge variant="outline" className="bg-black/50 border-white/20">
                  {currentPick.match}% Match
                </Badge>
              )}
            </div>

            <h3 className="text-3xl md:text-4xl font-bold mb-2">{currentPick.title}</h3>

            <div className="flex items-center gap-2 text-sm mb-3">
              <span>{currentPick.year}</span>
              <span className="text-white/70">|</span>
              <span>⭐ {currentPick.rating}</span>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              {currentPick.genres.map((genre) => (
                <Badge key={genre} variant="outline" className="rounded-full border-white/20 bg-black/30">
                  {genre}
                </Badge>
              ))}
            </div>

            <p className="text-white/80 mb-6 line-clamp-3">{currentPick.description}</p>

            <div className="flex gap-3">
              <Button asChild className="bg-zapred hover:bg-zapred/90">
                <Link href={`/media/${currentPick.id}`}>
                  <Play className="mr-2 h-4 w-4" />
                  Play
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link href={`/media/${currentPick.id}`}>
                  <Info className="mr-2 h-4 w-4" />
                  More Info
                </Link>
              </Button>
            </div>
          </div>

          {/* Poster image */}
          <div className="hidden md:block absolute right-10 bottom-10 w-[200px] h-[300px] shadow-xl">
            <Image
              src={currentPick.posterImage || currentPick.image}
              alt={`${currentPick.title} poster`}
              fill
              className="object-cover rounded-md border-2 border-white/20"
            />
          </div>
        </div>

        {/* Carousel indicators */}
        <div className="flex justify-center gap-2 mt-4">
          {picks.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full ${index === currentIndex ? "bg-zapred" : "bg-white/30"}`}
              onClick={() => setCurrentIndex(index)}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
