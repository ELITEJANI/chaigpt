"use client"
import { ThemeProvider as NextThemesProvider } from "next-themes"
import type { ThemeProviderProps } from "next-themes"
import { useEffect, useState } from "react"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  const [mounted, setMounted] = useState(false)

  // Apply saved theme on mount and ensure it persists
  useEffect(() => {
    setMounted(true)

    // Get saved theme from localStorage
    const savedTheme = localStorage.getItem("zapstreams-theme") || "dark"

    // Apply the theme to document
    document.documentElement.classList.remove("dark", "light", "blue-radiance", "apple-tv", "emerald")
    document.documentElement.classList.add(savedTheme)

    // Force dark mode if no theme is set
    if (!savedTheme) {
      localStorage.setItem("zapstreams-theme", "dark")
      document.documentElement.classList.add("dark")
    }

    // Prevent theme flashing by setting a class on the body
    document.body.classList.add("theme-loaded")
  }, [])

  // Only render the provider when mounted to avoid hydration mismatch
  if (!mounted) {
    return <div className="bg-black min-h-screen">{children}</div>
  }

  return (
    <NextThemesProvider {...props} forcedTheme="dark" defaultTheme="dark">
      {children}
    </NextThemesProvider>
  )
}
