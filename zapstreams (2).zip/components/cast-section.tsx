import Image from "next/image"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

interface CastMember {
  id: string
  name: string
  character: string
  image: string
}

interface CastSectionProps {
  cast: CastMember[]
}

export function CastSection({ cast }: CastSectionProps) {
  if (!cast || cast.length === 0) {
    return null
  }

  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold mb-6">Cast</h2>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-4 pb-4">
          {cast.map((actor) => (
            <div key={actor.id} className="w-[150px] flex-shrink-0">
              <div className="relative h-[200px] w-[150px] overflow-hidden rounded-md">
                <Image
                  src={actor.image || "/placeholder.svg"}
                  alt={actor.name}
                  fill
                  className="object-cover transition-all hover:scale-105"
                  sizes="150px"
                />
              </div>
              <div className="mt-2">
                <h3 className="font-medium text-sm">{actor.name}</h3>
                <p className="text-sm text-muted-foreground">{actor.character}</p>
              </div>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
