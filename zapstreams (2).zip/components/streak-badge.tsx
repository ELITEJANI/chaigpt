"use client"

import { useStreak } from "@/hooks/use-streak"
import { Flame } from "lucide-react"
import { cn } from "@/lib/utils"

export function StreakBadge() {
  const { currentStreak } = useStreak()

  if (currentStreak === 0) {
    return null
  }

  return (
    <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-black/30 border border-white/10">
      <Flame
        className={cn(
          "h-4 w-4",
          currentStreak >= 30 ? "text-purple-500" : currentStreak >= 7 ? "text-yellow-500" : "text-zapred",
        )}
      />
      <span className="text-xs font-medium">{currentStreak}-day streak</span>
    </div>
  )
}
