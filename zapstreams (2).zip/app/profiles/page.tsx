"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useProfiles, type Profile } from "@/hooks/use-profiles"
import { Logo } from "@/components/logo"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Pencil, Trash2, Plus, Check, Lock } from "lucide-react"
import Image from "next/image"
import { toast } from "@/hooks/use-toast"
import { AvatarSelector } from "@/components/avatar-selector"

export default function ProfilesPage() {
  const { profiles, activeProfile, addProfile, updateProfile, deleteProfile, setActiveProfile } = useProfiles()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isPinDialogOpen, setIsPinDialogOpen] = useState(false)
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null)
  const [newProfile, setNewProfile] = useState<Omit<Profile, "id">>({
    name: "",
    avatar: "/placeholder.svg?height=200&width=200",
    isKids: false,
    isPinProtected: false,
    language: "english",
    maturityLevel: "18+",
    autoplayEnabled: true,
  })
  const [pin, setPin] = useState("")
  const router = useRouter()

  const handleAddProfile = () => {
    if (!newProfile.name.trim()) {
      toast({
        title: "Profile name required",
        description: "Please enter a name for the profile",
        variant: "destructive",
      })
      return
    }

    addProfile(newProfile)
    setIsAddDialogOpen(false)
    setNewProfile({
      name: "",
      avatar: "/placeholder.svg?height=200&width=200",
      isKids: false,
      isPinProtected: false,
      language: "english",
      maturityLevel: "18+",
      autoplayEnabled: true,
    })

    toast({
      title: "Profile Added",
      description: `${newProfile.name} profile has been created`,
    })
  }

  const handleEditProfile = () => {
    if (!selectedProfile) return

    updateProfile(selectedProfile.id, selectedProfile)
    setIsEditDialogOpen(false)

    toast({
      title: "Profile Updated",
      description: `${selectedProfile.name} profile has been updated`,
    })
  }

  const handleDeleteProfile = () => {
    if (!selectedProfile) return

    const profileName = selectedProfile.name
    deleteProfile(selectedProfile.id)
    setIsDeleteDialogOpen(false)

    toast({
      title: "Profile Deleted",
      description: `${profileName} profile has been deleted`,
    })
  }

  const handleSetPin = () => {
    if (!selectedProfile) return

    if (pin.length !== 4 || !/^\d+$/.test(pin)) {
      toast({
        title: "Invalid PIN",
        description: "PIN must be 4 digits",
        variant: "destructive",
      })
      return
    }

    updateProfile(selectedProfile.id, {
      isPinProtected: true,
      pin,
    })
    setIsPinDialogOpen(false)
    setPin("")

    toast({
      title: "PIN Set",
      description: `PIN has been set for ${selectedProfile.name}`,
    })
  }

  const handleSelectProfile = (profile: Profile) => {
    if (profile.isPinProtected) {
      setSelectedProfile(profile)
      setIsPinDialogOpen(true)
    } else {
      setActiveProfile(profile.id)
      toast({
        title: "Profile Changed",
        description: `Switched to ${profile.name}'s profile`,
      })
      router.push("/")
    }
  }

  const handlePinSubmit = () => {
    if (!selectedProfile) return

    if (selectedProfile.pin === pin) {
      setActiveProfile(selectedProfile.id)
      setIsPinDialogOpen(false)
      setPin("")
      toast({
        title: "Profile Changed",
        description: `Switched to ${selectedProfile.name}'s profile`,
      })
      router.push("/")
    } else {
      toast({
        title: "Incorrect PIN",
        description: "The PIN you entered is incorrect",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-black flex flex-col">
      <header className="p-8">
        <Logo />
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <h1 className="text-3xl font-bold mb-8">Who's Watching?</h1>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-12">
          {profiles.map((profile) => (
            <div key={profile.id} className="flex flex-col items-center">
              <div className="relative group">
                <button
                  className="relative w-32 h-32 rounded-lg overflow-hidden focus:outline-none focus:ring-2 focus:ring-zapred"
                  onClick={() => handleSelectProfile(profile)}
                >
                  <Image
                    src={profile.avatar || "/placeholder.svg"}
                    alt={profile.name}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 128px, 128px"
                    crossOrigin="anonymous"
                    unoptimized={true}
                  />
                  {profile.isPinProtected && (
                    <div className="absolute top-2 right-2 bg-black/50 rounded-full p-1">
                      <Lock className="h-4 w-4 text-white" />
                    </div>
                  )}
                  {profile.isKids && (
                    <div className="absolute bottom-0 left-0 right-0 bg-blue-500 text-white text-xs py-1 text-center">
                      KIDS
                    </div>
                  )}
                </button>

                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-2 transition-opacity rounded-lg">
                  <Button
                    size="icon"
                    variant="ghost"
                    className="rounded-full"
                    onClick={() => {
                      setSelectedProfile(profile)
                      setIsEditDialogOpen(true)
                    }}
                  >
                    <Pencil className="h-5 w-5" />
                  </Button>

                  <Button
                    size="icon"
                    variant="ghost"
                    className="rounded-full text-red-500"
                    onClick={() => {
                      setSelectedProfile(profile)
                      setIsDeleteDialogOpen(true)
                    }}
                    disabled={profiles.length <= 1}
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              <span className="mt-2 text-center">{profile.name}</span>
              {activeProfile?.id === profile.id && (
                <div className="mt-1 flex items-center justify-center">
                  <Check className="h-4 w-4 text-zapred mr-1" />
                  <span className="text-xs text-zapred">Active</span>
                </div>
              )}
            </div>
          ))}

          {profiles.length < 5 && (
            <button
              className="w-32 h-32 rounded-lg border-2 border-dashed border-white/30 flex items-center justify-center hover:border-white/50 transition-colors focus:outline-none focus:ring-2 focus:ring-zapred"
              onClick={() => setIsAddDialogOpen(true)}
            >
              <Plus className="h-8 w-8 text-white/50" />
            </button>
          )}
        </div>

        <Button variant="outline" onClick={() => router.push("/settings")}>
          Manage Profiles
        </Button>
      </main>

      {/* Add Profile Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="bg-black/90 border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Add Profile</DialogTitle>
          </DialogHeader>

          <div className="grid gap-6 py-4">
            <div className="flex flex-col items-center gap-4">
              <div className="relative w-24 h-24 rounded-lg overflow-hidden">
                <Image
                  src={newProfile.avatar || "/placeholder.svg"}
                  alt="Avatar"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 96px, 96px"
                  crossOrigin="anonymous"
                  unoptimized={true}
                />
              </div>

              <AvatarSelector
                currentAvatar={newProfile.avatar || "/placeholder.svg?height=200&width=200"}
                onSelect={(avatar) => setNewProfile({ ...newProfile, avatar })}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="profileName">Name</Label>
              <Input
                id="profileName"
                value={newProfile.name}
                onChange={(e) => setNewProfile({ ...newProfile, name: e.target.value })}
                className="bg-black/50 border-white/20"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="isKids">Kids Profile</Label>
              <Switch
                id="isKids"
                checked={newProfile.isKids}
                onCheckedChange={(checked) => setNewProfile({ ...newProfile, isKids: checked })}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="isPinProtected">PIN Protection</Label>
              <Switch
                id="isPinProtected"
                checked={newProfile.isPinProtected}
                onCheckedChange={(checked) => setNewProfile({ ...newProfile, isPinProtected: checked })}
              />
            </div>

            {newProfile.isPinProtected && (
              <div className="grid gap-2">
                <Label htmlFor="pin">PIN (4 digits)</Label>
                <Input
                  id="pin"
                  type="password"
                  maxLength={4}
                  value={newProfile.pin || ""}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                    setNewProfile({ ...newProfile, pin: value })
                  }}
                  className="bg-black/50 border-white/20"
                />
              </div>
            )}

            {newProfile.isKids ? (
              <div className="grid gap-2">
                <Label htmlFor="maturityLevel">Content Rating</Label>
                <Select
                  value={newProfile.maturityLevel}
                  onValueChange={(value) => setNewProfile({ ...newProfile, maturityLevel: value as any })}
                >
                  <SelectTrigger id="maturityLevel" className="bg-black/50 border-white/20">
                    <SelectValue placeholder="Select content rating" />
                  </SelectTrigger>
                  <SelectContent className="bg-black/90 border-white/10">
                    <SelectItem value="all">All Ages</SelectItem>
                    <SelectItem value="7+">7+</SelectItem>
                    <SelectItem value="13+">13+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="grid gap-2">
                <Label htmlFor="maturityLevel">Content Rating</Label>
                <Select
                  value={newProfile.maturityLevel}
                  onValueChange={(value) => setNewProfile({ ...newProfile, maturityLevel: value as any })}
                >
                  <SelectTrigger id="maturityLevel" className="bg-black/50 border-white/20">
                    <SelectValue placeholder="Select content rating" />
                  </SelectTrigger>
                  <SelectContent className="bg-black/90 border-white/10">
                    <SelectItem value="all">All Ages</SelectItem>
                    <SelectItem value="7+">7+</SelectItem>
                    <SelectItem value="13+">13+</SelectItem>
                    <SelectItem value="16+">16+</SelectItem>
                    <SelectItem value="18+">18+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-zapred hover:bg-zapred/90" onClick={handleAddProfile}>
              Add Profile
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Profile Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-black/90 border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>

          {selectedProfile && (
            <div className="grid gap-6 py-4">
              <div className="flex flex-col items-center gap-4">
                <div className="relative w-24 h-24 rounded-lg overflow-hidden">
                  <Image
                    src={selectedProfile.avatar || "/placeholder.svg"}
                    alt="Avatar"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 96px, 96px"
                    crossOrigin="anonymous"
                    unoptimized={true}
                  />
                </div>

                <AvatarSelector
                  currentAvatar={selectedProfile.avatar || "/placeholder.svg?height=200&width=200"}
                  onSelect={(avatar) => setSelectedProfile({ ...selectedProfile, avatar })}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="editProfileName">Name</Label>
                <Input
                  id="editProfileName"
                  value={selectedProfile.name}
                  onChange={(e) => setSelectedProfile({ ...selectedProfile, name: e.target.value })}
                  className="bg-black/50 border-white/20"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="editIsKids">Kids Profile</Label>
                <Switch
                  id="editIsKids"
                  checked={selectedProfile.isKids}
                  onCheckedChange={(checked) => setSelectedProfile({ ...selectedProfile, isKids: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="editIsPinProtected">PIN Protection</Label>
                <Switch
                  id="editIsPinProtected"
                  checked={selectedProfile.isPinProtected}
                  onCheckedChange={(checked) => setSelectedProfile({ ...selectedProfile, isPinProtected: checked })}
                />
              </div>

              {selectedProfile.isPinProtected && (
                <div className="grid gap-2">
                  <Label htmlFor="editPin">PIN (4 digits)</Label>
                  <Input
                    id="editPin"
                    type="password"
                    maxLength={4}
                    value={selectedProfile.pin || ""}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                      setSelectedProfile({ ...selectedProfile, pin: value })
                    }}
                    className="bg-black/50 border-white/20"
                  />
                </div>
              )}

              <div className="grid gap-2">
                <Label htmlFor="editMaturityLevel">Content Rating</Label>
                <Select
                  value={selectedProfile.maturityLevel}
                  onValueChange={(value) => setSelectedProfile({ ...selectedProfile, maturityLevel: value as any })}
                >
                  <SelectTrigger id="editMaturityLevel" className="bg-black/50 border-white/20">
                    <SelectValue placeholder="Select content rating" />
                  </SelectTrigger>
                  <SelectContent className="bg-black/90 border-white/10">
                    <SelectItem value="all">All Ages</SelectItem>
                    <SelectItem value="7+">7+</SelectItem>
                    <SelectItem value="13+">13+</SelectItem>
                    <SelectItem value="16+">16+</SelectItem>
                    <SelectItem value="18+">18+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="editAutoplay">Autoplay Next Episode</Label>
                <Switch
                  id="editAutoplay"
                  checked={selectedProfile.autoplayEnabled}
                  onCheckedChange={(checked) => setSelectedProfile({ ...selectedProfile, autoplayEnabled: checked })}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-zapred hover:bg-zapred/90" onClick={handleEditProfile}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Profile Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-black/90 border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Profile</DialogTitle>
          </DialogHeader>

          <div className="py-4">
            <p>Are you sure you want to delete the profile "{selectedProfile?.name}"?</p>
            <p className="text-white/70 mt-2">This action cannot be undone.</p>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteProfile}>
              Delete Profile
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* PIN Dialog */}
      <Dialog open={isPinDialogOpen} onOpenChange={setIsPinDialogOpen}>
        <DialogContent className="bg-black/90 border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Enter PIN</DialogTitle>
          </DialogHeader>

          <div className="py-4">
            <p className="mb-4">Enter the PIN for {selectedProfile?.name}</p>
            <Input
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                setPin(value)
              }}
              className="bg-black/50 border-white/20 text-center text-xl tracking-widest"
              autoFocus
            />
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsPinDialogOpen(false)
                setPin("")
              }}
            >
              Cancel
            </Button>
            <Button className="bg-zapred hover:bg-zapred/90" onClick={handlePinSubmit}>
              Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
