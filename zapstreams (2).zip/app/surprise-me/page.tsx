"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { Loader2 } from "lucide-react"

export default function SurpriseMePage() {
  const [isAnimating, setIsAnimating] = useState(true)
  const [randomContent, setRandomContent] = useState<any>(null)
  const router = useRouter()
  const animationTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // List of all available content
  const allContent = [
    {
      id: "big-buck-bunny",
      title: "Big Buck Bunny",
      image: "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
    },
    {
      id: "tears-of-steel",
      title: "Tears of Steel",
      image: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
    },
    {
      id: "sintel",
      title: "Sintel",
      image: "/placeholder.svg?height=600&width=400&text=Sintel",
    },
    {
      id: "elephant-dream",
      title: "Elephant Dream",
      image: "/placeholder.svg?height=600&width=400&text=Elephant+Dream",
    },
    {
      id: "for-bigger-blazes",
      title: "For Bigger Blazes",
      image: "/placeholder.svg?height=600&width=400&text=For+Bigger+Blazes",
    },
    {
      id: "stranger-things",
      title: "Stranger Things",
      image: "/placeholder.svg?height=600&width=400&text=Stranger+Things",
    },
    {
      id: "money-heist",
      title: "Money Heist",
      image: "/placeholder.svg?height=600&width=400&text=Money+Heist",
    },
    {
      id: "breaking-bad",
      title: "Breaking Bad",
      image: "/placeholder.svg?height=600&width=400&text=Breaking+Bad",
    },
    {
      id: "game-of-thrones",
      title: "Game of Thrones",
      image: "/placeholder.svg?height=600&width=400&text=Game+of+Thrones",
    },
    {
      id: "the-last-of-us",
      title: "The Last of Us",
      image: "/placeholder.svg?height=600&width=400&text=The+Last+of+Us",
    },
  ]

  // Generate floating poster elements
  const generatePosters = () => {
    return allContent.map((content, index) => {
      // Random position, scale, and rotation
      const x = Math.random() * 100 - 50 // -50 to 50 vw
      const y = Math.random() * 100 - 50 // -50 to 50 vh
      const z = Math.random() * 500 // 0 to 500
      const scale = 0.5 + Math.random() * 1.5 // 0.5 to 2
      const rotate = Math.random() * 360 // 0 to 360 degrees

      return (
        <motion.div
          key={content.id}
          className="absolute"
          initial={{
            x: `${x}vw`,
            y: `${y}vh`,
            z: z,
            scale: scale,
            rotate: rotate,
            opacity: 0,
          }}
          animate={{
            x: [`${x}vw`, `${x + (Math.random() * 40 - 20)}vw`, `${x + (Math.random() * 80 - 40)}vw`],
            y: [`${y}vh`, `${y + (Math.random() * 40 - 20)}vh`, `${y + (Math.random() * 80 - 40)}vh`],
            z: [z, z + 200, z - 100],
            scale: [scale, scale * 1.5, scale * 0.8],
            rotate: [rotate, rotate + 180, rotate + 360],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 5,
            times: [0, 0.5, 1],
            delay: index * 0.2,
            ease: "easeInOut",
          }}
        >
          <div className="relative w-32 h-48 overflow-hidden rounded-lg shadow-lg">
            <Image src={content.image || "/placeholder.svg"} alt={content.title} fill className="object-cover" />
          </div>
        </motion.div>
      )
    })
  }

  // Earth spinning animation
  const EarthAnimation = () => (
    <motion.div
      className="absolute inset-0 flex items-center justify-center"
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1, rotate: 720 }}
      transition={{ duration: 4, delay: 1 }}
    >
      <div className="relative w-64 h-64 rounded-full overflow-hidden">
        <Image src="/placeholder.svg?height=400&width=400&text=Earth" alt="Earth" fill className="object-cover" />
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-zapred/50 to-transparent"
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        />
      </div>
    </motion.div>
  )

  // Glass shattering effect
  const GlassShatter = () => {
    const fragments = Array.from({ length: 20 }).map((_, i) => {
      const x = Math.random() * 200 - 100
      const y = Math.random() * 200 - 100
      const rotate = Math.random() * 360
      const scale = 0.5 + Math.random() * 1

      return (
        <motion.div
          key={i}
          className="absolute bg-white/30 backdrop-blur-sm"
          style={{
            width: `${20 + Math.random() * 40}px`,
            height: `${20 + Math.random() * 40}px`,
            borderRadius: `${Math.random() * 5}px`,
          }}
          initial={{ x: 0, y: 0, rotate: 0, scale: 0, opacity: 0 }}
          animate={{
            x: x * 5,
            y: y * 5,
            rotate: rotate,
            scale: scale,
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 2,
            delay: 3 + i * 0.05,
            ease: "easeOut",
          }}
        />
      )
    })

    return <div className="absolute inset-0 flex items-center justify-center overflow-hidden">{fragments}</div>
  }

  // Final explosion effect
  const FinalExplosion = () => (
    <motion.div
      className="absolute inset-0 bg-zapred"
      initial={{ scale: 0, opacity: 0, borderRadius: "100%" }}
      animate={{ scale: 2, opacity: [0, 0.8, 0], borderRadius: "0%" }}
      transition={{ duration: 1.5, delay: 5, ease: "easeOut" }}
    />
  )

  // Select random content and redirect after animation
  useEffect(() => {
    // Select random content
    const randomIndex = Math.floor(Math.random() * allContent.length)
    setRandomContent(allContent[randomIndex])

    // Set timeout to redirect after animation completes
    animationTimeoutRef.current = setTimeout(() => {
      setIsAnimating(false)
      router.push(`/media/${allContent[randomIndex].id}`)
    }, 7000) // Animation duration + buffer

    return () => {
      if (animationTimeoutRef.current) {
        clearTimeout(animationTimeoutRef.current)
      }
    }
  }, [router])

  return (
    <main className="min-h-screen bg-black overflow-hidden">
      <Navbar />

      <div className="relative w-full h-screen flex items-center justify-center">
        <AnimatePresence>
          {isAnimating && (
            <>
              {/* Background with stars */}
              <div className="absolute inset-0 bg-black">
                <div className="stars-container">
                  {Array.from({ length: 100 }).map((_, i) => (
                    <div
                      key={i}
                      className="star"
                      style={{
                        top: `${Math.random() * 100}%`,
                        left: `${Math.random() * 100}%`,
                        width: `${Math.random() * 3}px`,
                        height: `${Math.random() * 3}px`,
                        animationDelay: `${Math.random() * 5}s`,
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Floating posters */}
              {generatePosters()}

              {/* Earth animation */}
              <EarthAnimation />

              {/* Glass shatter effect */}
              <GlassShatter />

              {/* Final explosion */}
              <FinalExplosion />

              {/* Loading text */}
              <motion.div
                className="absolute bottom-20 flex flex-col items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
              >
                <Loader2 className="h-8 w-8 animate-spin text-zapred mb-2" />
                <p className="text-xl font-bold">Finding something amazing for you...</p>
                {randomContent && (
                  <motion.p
                    className="text-zapred text-2xl font-bold mt-4"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 4 }}
                  >
                    {randomContent.title}
                  </motion.p>
                )}
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>

      <style jsx>{`
        .stars-container {
          position: absolute;
          width: 100%;
          height: 100%;
        }
        .star {
          position: absolute;
          background-color: white;
          border-radius: 50%;
          animation: twinkle 5s infinite;
        }
        @keyframes twinkle {
          0%, 100% { opacity: 0.2; }
          50% { opacity: 1; }
        }
      `}</style>
    </main>
  )
}
