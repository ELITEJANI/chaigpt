"use client"

import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import Image from "next/image"
import { Share2, Plus, Play, Check, Download } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useState, useRef, useEffect } from "react"
import { useMyList } from "@/hooks/use-my-list"
import { useDownloads } from "@/hooks/use-downloads"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter, useSearchParams } from "next/navigation"
import { toast } from "@/hooks/use-toast"
import { CastSection } from "@/components/cast-section"
import { PreviewClips } from "@/components/preview-clips"
import { useStreak } from "@/hooks/use-streak"

interface MediaDetailPageProps {
  params: {
    id: string
  }
}

export default function MediaDetailPage({ params }: MediaDetailPageProps) {
  const [isTrailerPlaying, setIsTrailerPlaying] = useState(false)
  const [selectedSeason, setSelectedSeason] = useState("1")
  const [isDownloading, setIsDownloading] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const trailerRef = useRef<HTMLVideoElement>(null)
  const { myList, addToMyList, removeFromMyList } = useMyList()
  const { addDownload, isDownloaded, getDownload } = useDownloads()
  const router = useRouter()
  const searchParams = useSearchParams()
  const isOfflineMode = searchParams.get("offline") === "true"
  const isInMyList = myList.some((item) => item.id === params.id)
  const { incrementStreak } = useStreak()

  // Videos to use
  const videos: Record<string, string> = {
    "big-buck-bunny": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "tears-of-steel": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    sintel: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    "elephant-dream": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "for-bigger-blazes": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    "for-bigger-escapes": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    "for-bigger-fun": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    "for-bigger-joyrides": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    "for-bigger-meltdowns": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    default: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  }

  // Poster images for free media
  const posters: Record<string, string> = {
    "big-buck-bunny": "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
    "tears-of-steel": "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
    sintel: "https://upload.wikimedia.org/wikipedia/commons/a/a7/Sintel_poster.jpg",
    "elephant-dream": "https://upload.wikimedia.org/wikipedia/commons/d/d2/Elephants_Dream_poster.jpg",
  }

  const videoSrc = videos[params.id] || videos.default
  const trailerSrc = videos[params.id] || videos.default
  const posterSrc = posters[params.id]
  const alreadyDownloaded = isDownloaded(params.id)
  const downloadItem = getDownload(params.id)

  // Play trailer
  const playTrailer = () => {
    setIsTrailerPlaying(true)
    if (trailerRef.current) {
      trailerRef.current.currentTime = 0
      trailerRef.current.play().catch((error) => console.error("Error playing trailer:", error))
    }
  }

  // Stop trailer
  const stopTrailer = () => {
    setIsTrailerPlaying(false)
    if (trailerRef.current) {
      trailerRef.current.pause()
    }
  }

  // Mock data based on ID
  const getMediaData = (id: string) => {
    if (id === "big-buck-bunny") {
      return {
        id: id,
        title: "BIG BUCK BUNNY",
        description:
          "A large and lovable rabbit deals with three bullies, led by a flying squirrel, who harass him and the forest animals.",
        image: posterSrc || "/placeholder.svg?height=1080&width=1920",
        year: "2008",
        duration: "10m",
        genres: ["ANIMATION", "COMEDY", "SHORT"],
        is4K: true,
        isDolbyAtmos: true,
        isTopTen: true,
        rating: "7.8",
        type: "movie",
        cast: [
          {
            id: "actor1",
            name: "Sacha Goedegebure",
            character: "Big Buck Bunny",
            image: "/placeholder.svg?height=200&width=150&text=Sacha",
          },
          {
            id: "actor2",
            name: "Ivo van Bolhuis",
            character: "Frank the Flying Squirrel",
            image: "/placeholder.svg?height=200&width=150&text=Ivo",
          },
          {
            id: "actor3",
            name: "Nathan Dunsworth",
            character: "Rodney Rabbit",
            image: "/placeholder.svg?height=200&width=150&text=Nathan",
          },
          {
            id: "actor4",
            name: "Tara Hetharia",
            character: "Betty Bunny",
            image: "/placeholder.svg?height=200&width=150&text=Tara",
          },
        ],
        previewClips: [
          {
            id: "clip1",
            title: "Opening Scene",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Opening+Scene",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            duration: "0:30",
          },
          {
            id: "clip2",
            title: "Butterfly Chase",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Butterfly+Chase",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            duration: "0:45",
          },
          {
            id: "clip3",
            title: "Final Confrontation",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Final+Confrontation",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            duration: "1:20",
          },
        ],
      }
    } else if (id === "tears-of-steel") {
      return {
        id: id,
        title: "TEARS OF STEEL",
        description:
          "In an apocalyptic future, a group of soldiers and scientists takes refuge in Amsterdam to try to stop an army of robots that threatens the planet.",
        image: posterSrc || "/placeholder.svg?height=1080&width=1920",
        year: "2012",
        duration: "12m",
        genres: ["SCI-FI", "ACTION", "SHORT"],
        isNew: true,
        is4K: true,
        rating: "6.5",
        type: "series",
        seasons: 3,
        episodes: [
          { season: 1, number: 1, title: "The Beginning", duration: "48m" },
          { season: 1, number: 2, title: "The Encounter", duration: "52m" },
          { season: 1, number: 3, title: "The Revelation", duration: "45m" },
          { season: 2, number: 1, title: "New Horizons", duration: "50m" },
          { season: 2, number: 2, title: "The Resistance", duration: "55m" },
          { season: 3, number: 1, title: "Final Stand", duration: "60m" },
        ],
        cast: [
          {
            id: "actor1",
            name: "Derek de Lint",
            character: "Thom",
            image: "/placeholder.svg?height=200&width=150&text=Derek",
          },
          {
            id: "actor2",
            name: "Sergio Hasselbaink",
            character: "Jager",
            image: "/placeholder.svg?height=200&width=150&text=Sergio",
          },
          {
            id: "actor3",
            name: "Rogier Schippers",
            character: "Armand",
            image: "/placeholder.svg?height=200&width=150&text=Rogier",
          },
          {
            id: "actor4",
            name: "Vanja Rukavina",
            character: "Thom's Robot",
            image: "/placeholder.svg?height=200&width=150&text=Vanja",
          },
          {
            id: "actor5",
            name: "Denise Rebergen",
            character: "Elise",
            image: "/placeholder.svg?height=200&width=150&text=Denise",
          },
        ],
        previewClips: [
          {
            id: "clip1",
            title: "Robot Attack",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Robot+Attack",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            duration: "0:40",
          },
          {
            id: "clip2",
            title: "Amsterdam Ruins",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Amsterdam+Ruins",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            duration: "0:55",
          },
          {
            id: "clip3",
            title: "Final Battle",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Final+Battle",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            duration: "1:10",
          },
        ],
      }
    } else if (id === "sintel") {
      return {
        id: id,
        title: "SINTEL",
        description:
          "A lonely girl travels through harsh landscapes in search of a mysterious dragon who stole her friend.",
        image: posterSrc || "/placeholder.svg?height=1080&width=1920",
        year: "2010",
        duration: "15m",
        genres: ["ANIMATION", "FANTASY", "SHORT"],
        is4K: true,
        rating: "7.6",
        type: "movie",
        cast: [
          {
            id: "actor1",
            name: "Halina Reijn",
            character: "Sintel",
            image: "/placeholder.svg?height=200&width=150&text=Halina",
          },
          {
            id: "actor2",
            name: "Thom Hoffman",
            character: "Shaman",
            image: "/placeholder.svg?height=200&width=150&text=Thom",
          },
        ],
        previewClips: [
          {
            id: "clip1",
            title: "Dragon Encounter",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Dragon+Encounter",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            duration: "0:50",
          },
          {
            id: "clip2",
            title: "Mountain Journey",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Mountain+Journey",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            duration: "1:05",
          },
        ],
      }
    } else if (id === "elephant-dream") {
      return {
        id: id,
        title: "ELEPHANT DREAM",
        description:
          "The first Blender Open Movie from 2006, about two strange characters exploring a strange mechanical world.",
        image: posterSrc || "/placeholder.svg?height=1080&width=1920",
        year: "2006",
        duration: "11m",
        genres: ["ANIMATION", "SCI-FI", "SHORT"],
        isTopTen: true,
        rating: "6.9",
        type: "movie",
        cast: [
          {
            id: "actor1",
            name: "Tygo Gernandt",
            character: "Emo",
            image: "/placeholder.svg?height=200&width=150&text=Tygo",
          },
          {
            id: "actor2",
            name: "Cas Jansen",
            character: "Proog",
            image: "/placeholder.svg?height=200&width=150&text=Cas",
          },
        ],
        previewClips: [
          {
            id: "clip1",
            title: "Machine World",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Machine+World",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "0:45",
          },
          {
            id: "clip2",
            title: "Strange Encounter",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Strange+Encounter",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "1:00",
          },
        ],
      }
    } else if (id === "stranger-things") {
      return {
        id: id,
        title: "STRANGER THINGS",
        description:
          "When a young boy disappears, his mother, a police chief, and his friends must confront terrifying supernatural forces in order to get him back.",
        image: "/placeholder.svg?height=1080&width=1920",
        year: "2016",
        genres: ["DRAMA", "FANTASY", "HORROR"],
        isNew: true,
        is4K: true,
        rating: "8.7",
        type: "series",
        seasons: 4,
        episodes: [
          { season: 1, number: 1, title: "Chapter One: The Vanishing of Will Byers", duration: "48m" },
          { season: 1, number: 2, title: "Chapter Two: The Weirdo on Maple Street", duration: "52m" },
          { season: 1, number: 3, title: "Chapter Three: Holly, Jolly", duration: "45m" },
          { season: 2, number: 1, title: "Chapter One: MADMAX", duration: "50m" },
          { season: 2, number: 2, title: "Chapter Two: Trick or Treat, Freak", duration: "55m" },
          { season: 3, number: 1, title: "Chapter One: Suzie, Do You Copy?", duration: "60m" },
          { season: 4, number: 1, title: "Chapter One: The Hellfire Club", duration: "65m" },
        ],
        cast: [
          {
            id: "actor1",
            name: "Millie Bobby Brown",
            character: "Eleven",
            image: "/placeholder.svg?height=200&width=150&text=Millie",
          },
          {
            id: "actor2",
            name: "Finn Wolfhard",
            character: "Mike Wheeler",
            image: "/placeholder.svg?height=200&width=150&text=Finn",
          },
          {
            id: "actor3",
            name: "Winona Ryder",
            character: "Joyce Byers",
            image: "/placeholder.svg?height=200&width=150&text=Winona",
          },
          {
            id: "actor4",
            name: "David Harbour",
            character: "Jim Hopper",
            image: "/placeholder.svg?height=200&width=150&text=David",
          },
          {
            id: "actor5",
            name: "Gaten Matarazzo",
            character: "Dustin Henderson",
            image: "/placeholder.svg?height=200&width=150&text=Gaten",
          },
          {
            id: "actor6",
            name: "Caleb McLaughlin",
            character: "Lucas Sinclair",
            image: "/placeholder.svg?height=200&width=150&text=Caleb",
          },
        ],
        previewClips: [
          {
            id: "clip1",
            title: "The Upside Down",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Upside+Down",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "1:20",
          },
          {
            id: "clip2",
            title: "Eleven's Powers",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Eleven's+Powers",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "0:55",
          },
          {
            id: "clip3",
            title: "Demogorgon Attack",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Demogorgon",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "1:45",
          },
          {
            id: "clip4",
            title: "Hawkins Lab",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Hawkins+Lab",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "1:10",
          },
        ],
      }
    } else {
      return {
        id: params.id,
        title: params.id.toUpperCase().replace(/-/g, " "),
        description:
          "A young blade runner's discovery of a long-buried secret leads him to track down former blade runner Rick Deckard, who's been missing for thirty years.",
        image: "/placeholder.svg?height=1080&width=1920",
        year: "2017",
        duration: "2h 44min",
        genres: ["ACTION", "DRAMA", "SCI-FI"],
        rating: "8.0",
        type: "movie",
        cast: [
          {
            id: "actor1",
            name: "Actor One",
            character: "Character One",
            image: "/placeholder.svg?height=200&width=150&text=Actor+1",
          },
          {
            id: "actor2",
            name: "Actor Two",
            character: "Character Two",
            image: "/placeholder.svg?height=200&width=150&text=Actor+2",
          },
          {
            id: "actor3",
            name: "Actor Three",
            character: "Character Three",
            image: "/placeholder.svg?height=200&width=150&text=Actor+3",
          },
        ],
        previewClips: [
          {
            id: "clip1",
            title: "Preview Clip 1",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Preview+1",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "1:30",
          },
          {
            id: "clip2",
            title: "Preview Clip 2",
            thumbnail: "/placeholder.svg?height=180&width=320&text=Preview+2",
            videoSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration: "0:45",
          },
        ],
      }
    }
  }

  const media = getMediaData(params.id)

  // Handle Add/Remove from My List
  const handleMyListToggle = () => {
    if (isInMyList) {
      removeFromMyList(params.id)
      toast({
        title: "Removed from My List",
        description: `${media.title} has been removed from your list`,
      })
    } else {
      addToMyList({
        id: params.id,
        title: media.title,
        image: posterSrc || media.image,
        rating: media.rating,
        year: media.year,
        genres: media.genres,
      })
      toast({
        title: "Added to My List",
        description: `${media.title} has been added to your list`,
      })
    }
  }

  // Handle download
  const handleDownload = () => {
    if (alreadyDownloaded) {
      toast({
        title: "Already Downloaded",
        description: `${media.title} is already downloaded`,
      })
      return
    }

    setIsDownloading(true)

    // Add to downloads
    addDownload({
      id: params.id,
      title: media.title,
      image: posterSrc || media.image,
      size: media.type === "movie" ? "1.2 GB" : "450 MB",
      url: videoSrc,
      type: media.type as "movie" | "series",
    })

    toast({
      title: "Download Started",
      description: `${media.title} is being downloaded`,
    })

    setTimeout(() => {
      setIsDownloading(false)
      router.push(`/downloads`)
    }, 1000)
  }

  // Handle episode download
  const handleEpisodeDownload = (episode: any) => {
    addDownload({
      id: `${params.id}-s${episode.season}e${episode.number}`,
      title: `${media.title} - ${episode.title}`,
      image: posterSrc || media.image,
      size: "450 MB",
      url: videoSrc,
      type: "series",
      episode: {
        season: episode.season,
        number: episode.number,
        title: episode.title,
      },
    })

    toast({
      title: "Episode Download Started",
      description: `${episode.title} is being downloaded`,
    })

    router.push(`/downloads`)
  }

  // Ensure video is loaded and ready to play with sound
  useEffect(() => {
    const video = videoRef.current
    if (video) {
      const handleCanPlay = () => {
        // Make sure the video is not muted
        video.muted = false
        video.volume = 0.5 // Set a reasonable volume level

        // If video is paused and should be playing, play it
        if (video.paused && !video.ended) {
          video.play().catch((err) => console.error("Error playing video:", err))
        }
      }

      video.addEventListener("canplay", handleCanPlay)

      return () => {
        video.removeEventListener("canplay", handleCanPlay)
      }
    }
  }, [videoSrc])

  const similarMedia = [
    {
      id: "john-wick",
      title: "John Wick",
      image: "/placeholder.svg?height=600&width=400",
    },
    {
      id: "ex-machina",
      title: "Ex Machina",
      image: "/placeholder.svg?height=600&width=400",
    },
    {
      id: "mad-max",
      title: "Mad Max: Fury Road",
      image: "/placeholder.svg?height=600&width=400",
    },
    {
      id: "movie-4",
      title: "Movie 4",
      image: "/placeholder.svg?height=600&width=400",
    },
  ]

  // Filter episodes by selected season
  const seasonEpisodes =
    media.type === "series" && media.episodes
      ? media.episodes.filter((ep) => ep.season === Number.parseInt(selectedSeason))
      : []

  // Add this function to handle play
  const handlePlay = () => {
    // Increment streak when user plays content
    incrementStreak()

    // You can add additional play functionality here
    toast({
      title: "Now Playing",
      description: `${media.title} is now playing`,
    })
  }

  return (
    <main className="min-h-screen bg-black">
      {/* Background Video */}
      <div className="fixed inset-0 w-full h-full" style={{ zIndex: 0 }}>
        <video
          ref={videoRef}
          src={isOfflineMode && downloadItem?.localUrl ? downloadItem.localUrl : videoSrc}
          poster={media.image}
          autoPlay
          loop
          playsInline
          className="absolute inset-0 h-full w-full object-cover"
        />
        {/* Subtle gradient for text readability */}
        <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black/70 to-transparent pointer-events-none" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        <Navbar />

        <div className="pt-24 px-4 md:px-8 lg:px-16">
          <div className="max-w-4xl">
            <h1 className="text-5xl font-bold text-zapred mb-4">{media.title}</h1>

            <div className="flex flex-wrap gap-4 text-sm mb-6">
              {media.genres.map((genre) => (
                <span key={genre}>{genre}</span>
              ))}
              <span className="text-white/70">|</span>
              {media.type === "movie" ? <span>{media.duration}</span> : <span>{media.seasons} Seasons</span>}
              <span className="text-white/70">|</span>
              <span>{media.year}</span>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              {media.isNew && (
                <Badge variant="outline" className="bg-zapred/80 text-white border-none">
                  NEW
                </Badge>
              )}
              {media.is4K && (
                <Badge variant="outline" className="bg-black/50 text-white border-white/20">
                  4K HDR
                </Badge>
              )}
              {media.isDolbyAtmos && (
                <Badge variant="outline" className="bg-black/50 text-white border-white/20">
                  DOLBY ATMOS
                </Badge>
              )}
              {media.isTopTen && (
                <Badge variant="outline" className="bg-black/50 text-white border-white/20">
                  TOP 10
                </Badge>
              )}
              {isOfflineMode && (
                <Badge variant="outline" className="bg-green-600 text-white border-none">
                  DOWNLOADED
                </Badge>
              )}
            </div>

            <p className="text-lg mb-8 max-w-2xl">{media.description}</p>

            <div className="flex flex-wrap gap-4 mb-8">
              <Button className="bg-zapred hover:bg-zapred/90 px-8" onClick={handlePlay}>
                <Play className="h-4 w-4 mr-2" />
                Play Now
              </Button>
              <Button variant="outline" onClick={handleMyListToggle}>
                {isInMyList ? (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    In My List
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Add to My List
                  </>
                )}
              </Button>

              {/* Trailer Dialog */}
              <Dialog onOpenChange={(open) => !open && stopTrailer()}>
                <DialogTrigger asChild>
                  <Button variant="outline" onClick={playTrailer}>
                    Watch Trailer
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl p-0 bg-black border-white/10">
                  <div className="relative aspect-video w-full">
                    <video
                      ref={trailerRef}
                      src={trailerSrc}
                      controls
                      className="w-full h-full"
                      autoPlay
                      poster={media.image}
                    />
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="flex gap-6 mb-16">
              {/* Audio/Subtitles Dialog */}
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="flex flex-col items-center gap-2">
                    <span>Select Audio/Subtitles</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-black/90 border-white/10">
                  <DialogHeader>
                    <DialogTitle>Audio & Subtitles</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-6 py-4">
                    <div>
                      <h3 className="mb-2 text-sm font-medium">Audio</h3>
                      <Select defaultValue="english">
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent className="bg-black/90 border-white/10">
                          <SelectItem value="english">English - Original</SelectItem>
                          <SelectItem value="spanish">Spanish</SelectItem>
                          <SelectItem value="french">French</SelectItem>
                          <SelectItem value="german">German</SelectItem>
                          <SelectItem value="japanese">Japanese</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <h3 className="mb-2 text-sm font-medium">Subtitles</h3>
                      <Select defaultValue="off">
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent className="bg-black/90 border-white/10">
                          <SelectItem value="off">Off</SelectItem>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="spanish">Spanish</SelectItem>
                          <SelectItem value="french">French</SelectItem>
                          <SelectItem value="german">German</SelectItem>
                          <SelectItem value="japanese">Japanese</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Button variant="ghost" className="flex flex-col items-center gap-2">
                <span>Rate This</span>
              </Button>
              <Button
                variant="ghost"
                className="flex flex-col items-center gap-2"
                onClick={handleDownload}
                disabled={isDownloading || alreadyDownloaded}
              >
                <Download className="h-5 w-5" />
                <span>{isDownloading ? "Starting..." : alreadyDownloaded ? "Downloaded" : "Download"}</span>
              </Button>
              <Button variant="ghost" className="flex flex-col items-center gap-2">
                <Share2 className="h-5 w-5" />
                <span>Share</span>
              </Button>
            </div>

            {/* Preview Clips Section */}
            {media.previewClips && <PreviewClips clips={media.previewClips} />}

            {/* Cast Section */}
            {media.cast && <CastSection cast={media.cast} />}

            {/* Series-specific content */}
            {media.type === "series" && (
              <div className="mb-16">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold">Episodes</h2>
                  <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Season" />
                    </SelectTrigger>
                    <SelectContent className="bg-black/90 border-white/10">
                      {Array.from({ length: media.seasons }, (_, i) => (
                        <SelectItem key={i + 1} value={(i + 1).toString()}>
                          Season {i + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-4">
                  {seasonEpisodes.map((episode) => (
                    <div
                      key={`${episode.season}-${episode.number}`}
                      className="flex gap-4 p-4 rounded-md bg-black/40 border border-white/10 hover:bg-black/60 transition-colors"
                    >
                      <div className="w-16 h-16 flex items-center justify-center bg-zapred/20 rounded-md">
                        <span className="text-xl font-bold">{episode.number}</span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold">{episode.title}</h3>
                        <p className="text-sm text-white/70">{episode.duration}</p>
                      </div>
                      <div className="flex items-center">
                        <Button size="icon" variant="ghost" className="rounded-full">
                          <Play className="h-5 w-5" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="rounded-full"
                          onClick={() => handleEpisodeDownload(episode)}
                        >
                          <Download className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-6">More Like This</h2>
              <div className="flex gap-4 overflow-x-auto pb-4">
                {similarMedia.map((item) => (
                  <div key={item.id} className="movie-card block w-[200px] flex-shrink-0">
                    <div className="relative aspect-video overflow-hidden rounded-md">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        fill
                        className="object-cover"
                        sizes="(max-width: 768px) 200px, 200px"
                      />
                    </div>
                    <h3 className="mt-2 text-center font-semibold">{item.title}</h3>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
