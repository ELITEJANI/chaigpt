"use client"

import { useState, useEffect } from "react"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import { MovieCard } from "@/components/movie-card"
import { useRouter } from "next/navigation"

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const router = useRouter()

  // Mock data for search results
  const allContent = [
    {
      id: "stranger-things",
      title: "Stranger Things",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.7",
      year: "2016",
      genres: ["Horror", "Sci-Fi"],
    },
    {
      id: "money-heist",
      title: "Money Heist",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.3",
      year: "2017",
      genres: ["Action", "Crime"],
    },
    {
      id: "breaking-bad",
      title: "Breaking Bad",
      image: "/placeholder.svg?height=600&width=400",
      rating: "9.5",
      year: "2008",
      genres: ["Crime", "Drama"],
    },
    {
      id: "big-buck-bunny",
      title: "Big Buck Bunny",
      image: "/placeholder.svg?height=600&width=400",
      rating: "7.8",
      year: "2008",
      genres: ["Animation", "Comedy"],
      posterSrc: "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
    },
    {
      id: "tears-of-steel",
      title: "Tears of Steel",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.5",
      year: "2012",
      genres: ["Sci-Fi", "Short"],
      posterSrc: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
    },
    {
      id: "blade-runner",
      title: "Blade Runner 2049",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.0",
      year: "2017",
      genres: ["Sci-Fi", "Drama"],
    },
    {
      id: "john-wick",
      title: "John Wick",
      image: "/placeholder.svg?height=600&width=400",
      rating: "7.4",
      year: "2014",
      genres: ["Action", "Thriller"],
    },
    {
      id: "dune",
      title: "Dune",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.0",
      year: "2021",
      genres: ["Adventure", "Sci-Fi"],
    },
  ]

  // Handle keyboard input
  const handleKeyPress = (key: string) => {
    if (key === "Space") {
      setSearchQuery((prev) => prev + " ")
    } else if (key === "⌫") {
      setSearchQuery((prev) => prev.slice(0, -1))
    } else if (key === "Clear") {
      setSearchQuery("")
    } else {
      setSearchQuery((prev) => prev + key)
    }
  }

  // Search functionality
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setSearchResults([])
      return
    }

    const query = searchQuery.toLowerCase()
    const results = allContent.filter(
      (item) =>
        item.title.toLowerCase().includes(query) ||
        item.genres.some((genre) => genre.toLowerCase().includes(query)) ||
        item.year.includes(query),
    )
    setSearchResults(results)
  }, [searchQuery])

  // Keyboard layout
  const rows = [
    ["A", "B", "C", "D", "E", "F"],
    ["G", "H", "I", "J", "K", "L"],
    ["M", "N", "O", "P", "Q", "R"],
    ["S", "T", "U", "V", "W", "X"],
    ["Y", "Z", "0", "1", "2", "3"],
    ["4", "5", "6", "7", "8", "9"],
  ]

  return (
    <div className="flex min-h-screen flex-col bg-black">
      <Navbar />

      <div className="container px-4 py-24">
        <div className="flex items-center gap-4 mb-8">
          <Search className="h-6 w-6 text-zapred" />
          <h1 className="text-3xl font-bold">Search</h1>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Left side - Keyboard */}
          <div className="flex flex-col">
            {/* Search input display */}
            <div className="relative mb-6">
              <div className="flex items-center border-b-2 border-zapred pb-2">
                <span className="text-xl">{searchQuery}</span>
                <span className="animate-pulse ml-1">|</span>
              </div>
            </div>

            {/* Keyboard */}
            <div className="grid gap-2">
              {rows.map((row, rowIndex) => (
                <div key={rowIndex} className="flex gap-2">
                  {row.map((key) => (
                    <Button
                      key={key}
                      variant="outline"
                      className="h-12 w-12 bg-black/50 border-white/20"
                      onClick={() => handleKeyPress(key)}
                    >
                      {key}
                    </Button>
                  ))}
                </div>
              ))}

              {/* Bottom row with special keys - fixed width buttons */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="h-12 w-[calc(50%-4px)] bg-black/50 border-white/20"
                  onClick={() => handleKeyPress("Space")}
                >
                  Space
                </Button>
                <Button
                  variant="outline"
                  className="h-12 w-12 bg-black/50 border-white/20"
                  onClick={() => handleKeyPress("⌫")}
                >
                  ⌫
                </Button>
                <Button
                  variant="outline"
                  className="h-12 w-[calc(50%-4px)] bg-black/50 border-white/20"
                  onClick={() => handleKeyPress("Clear")}
                >
                  Clear
                </Button>
              </div>
            </div>
          </div>

          {/* Right side - Search Results/Empty State */}
          <div className="flex flex-col">
            {searchQuery.trim() === "" ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Search className="h-24 w-24 text-white/20 mb-6" />
                <h2 className="text-2xl font-bold mb-2">Search for movies and TV shows</h2>
                <p className="text-white/60">Use the keyboard to search for your favorite content</p>
              </div>
            ) : searchResults.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <h2 className="text-2xl font-bold mb-2">No results found</h2>
                <p className="text-white/60">Try a different search term</p>
              </div>
            ) : (
              <div>
                <h2 className="text-xl font-bold mb-4">Search Results ({searchResults.length})</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {searchResults.map((item) => (
                    <MovieCard
                      key={item.id}
                      id={item.id}
                      title={item.title}
                      image={item.image}
                      rating={item.rating}
                      year={item.year}
                      genres={item.genres}
                      posterSrc={item.posterSrc}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
