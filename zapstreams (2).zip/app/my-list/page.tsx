"use client"

import { Navbar } from "@/components/navbar"
import { useMyList } from "@/hooks/use-my-list"
import { MovieCard } from "@/components/movie-card"
import { Button } from "@/components/ui/button"
import { Trash2 } from "lucide-react"
import { useState } from "react"

export default function MyListPage() {
  const { myList, clearMyList } = useMyList()
  const [focusedContentId, setFocusedContentId] = useState<string | null>(null)

  const handleFocusChange = (id: string) => {
    setFocusedContentId(id)
  }

  return (
    <main className="min-h-screen bg-black">
      <Navbar />

      <div className="container px-4 py-24">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">My List</h1>
          {myList.length > 0 && (
            <Button variant="outline" onClick={clearMyList}>
              <Trash2 className="h-4 w-4 mr-2" />
              Clear List
            </Button>
          )}
        </div>

        {myList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16">
            <p className="text-xl text-white/70 mb-4">Your list is empty</p>
            <p className="text-white/50 mb-8">Add movies and shows to your list to watch them later</p>
            <Button asChild className="bg-zapred hover:bg-zapred/90">
              <a href="/">Browse Content</a>
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {myList.map((item) => (
              <MovieCard
                key={item.id}
                id={item.id}
                title={item.title}
                image={item.image}
                rating={item.rating}
                year={item.year}
                genres={item.genres}
                onFocus={handleFocusChange}
              />
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
