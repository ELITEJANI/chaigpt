"use client"

import { useState, useEffect } from "react"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { MovieCard } from "@/components/movie-card"
import { Filter, X, Sliders } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Mock data for genres
const allGenres = [
  "Action",
  "Adventure",
  "Animation",
  "Comedy",
  "Crime",
  "Documentary",
  "Drama",
  "Family",
  "Fantasy",
  "Horror",
  "Mystery",
  "Romance",
  "Sci-Fi",
  "Thriller",
  "War",
]

// Mock data for content
const allContent = [
  {
    id: "stranger-things",
    title: "Stranger Things",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.7",
    year: "2016",
    genres: ["Horror", "Sci-Fi", "Drama"],
    type: "series",
    maturityRating: "16+",
  },
  {
    id: "money-heist",
    title: "Money Heist",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.3",
    year: "2017",
    genres: ["Action", "Crime", "Drama"],
    type: "series",
    maturityRating: "18+",
  },
  {
    id: "breaking-bad",
    title: "Breaking Bad",
    image: "/placeholder.svg?height=600&width=400",
    rating: "9.5",
    year: "2008",
    genres: ["Crime", "Drama", "Thriller"],
    type: "series",
    maturityRating: "18+",
  },
  {
    id: "big-buck-bunny",
    title: "Big Buck Bunny",
    image: "/placeholder.svg?height=600&width=400",
    rating: "7.8",
    year: "2008",
    genres: ["Animation", "Comedy", "Family"],
    type: "movie",
    maturityRating: "G",
    posterSrc: "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
  },
  {
    id: "tears-of-steel",
    title: "Tears of Steel",
    image: "/placeholder.svg?height=600&width=400",
    rating: "6.5",
    year: "2012",
    genres: ["Sci-Fi", "Action", "Short"],
    type: "movie",
    maturityRating: "PG-13",
    posterSrc: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
  },
  {
    id: "blade-runner",
    title: "Blade Runner 2049",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.0",
    year: "2017",
    genres: ["Sci-Fi", "Drama", "Action"],
    type: "movie",
    maturityRating: "R",
  },
  {
    id: "john-wick",
    title: "John Wick",
    image: "/placeholder.svg?height=600&width=400",
    rating: "7.4",
    year: "2014",
    genres: ["Action", "Thriller", "Crime"],
    type: "movie",
    maturityRating: "R",
  },
  {
    id: "dune",
    title: "Dune",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.0",
    year: "2021",
    genres: ["Adventure", "Sci-Fi", "Drama"],
    type: "movie",
    maturityRating: "PG-13",
  },
  {
    id: "game-of-thrones",
    title: "Game of Thrones",
    image: "/placeholder.svg?height=600&width=400",
    rating: "9.2",
    year: "2011",
    genres: ["Action", "Adventure", "Drama"],
    type: "series",
    maturityRating: "18+",
  },
  {
    id: "the-last-of-us",
    title: "The Last of Us",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.8",
    year: "2023",
    genres: ["Action", "Adventure", "Drama"],
    type: "series",
    maturityRating: "18+",
  },
  {
    id: "the-mandalorian",
    title: "The Mandalorian",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.7",
    year: "2019",
    genres: ["Action", "Adventure", "Sci-Fi"],
    type: "series",
    maturityRating: "13+",
  },
  {
    id: "succession",
    title: "Succession",
    image: "/placeholder.svg?height=600&width=400",
    rating: "8.8",
    year: "2018",
    genres: ["Drama", "Comedy"],
    type: "series",
    maturityRating: "18+",
  },
]

export default function BrowsePage() {
  const [selectedGenres, setSelectedGenres] = useState<string[]>([])
  const [contentType, setContentType] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("relevance")
  const [yearRange, setYearRange] = useState<[number, number]>([2000, 2024])
  const [ratingRange, setRatingRange] = useState<[number, number]>([0, 10])
  const [maturityRating, setMaturityRating] = useState<string>("all")
  const [filteredContent, setFilteredContent] = useState(allContent)
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [activeFilters, setActiveFilters] = useState(0)

  // Apply filters
  useEffect(() => {
    let filtered = [...allContent]

    // Filter by content type
    if (contentType !== "all") {
      filtered = filtered.filter((item) => item.type === contentType)
    }

    // Filter by genres
    if (selectedGenres.length > 0) {
      filtered = filtered.filter((item) => item.genres.some((genre) => selectedGenres.includes(genre)))
    }

    // Filter by year range
    filtered = filtered.filter((item) => {
      const year = Number.parseInt(item.year)
      return year >= yearRange[0] && year <= yearRange[1]
    })

    // Filter by rating range
    filtered = filtered.filter((item) => {
      const rating = Number.parseFloat(item.rating)
      return rating >= ratingRange[0] && rating <= ratingRange[1]
    })

    // Filter by maturity rating
    if (maturityRating !== "all") {
      filtered = filtered.filter((item) => item.maturityRating === maturityRating)
    }

    // Sort content
    if (sortBy === "newest") {
      filtered.sort((a, b) => Number.parseInt(b.year) - Number.parseInt(a.year))
    } else if (sortBy === "oldest") {
      filtered.sort((a, b) => Number.parseInt(a.year) - Number.parseInt(b.year))
    } else if (sortBy === "highest") {
      filtered.sort((a, b) => Number.parseFloat(b.rating) - Number.parseFloat(a.rating))
    } else if (sortBy === "lowest") {
      filtered.sort((a, b) => Number.parseFloat(a.rating) - Number.parseFloat(b.rating))
    }

    setFilteredContent(filtered)

    // Count active filters
    let count = 0
    if (contentType !== "all") count++
    if (selectedGenres.length > 0) count++
    if (yearRange[0] !== 2000 || yearRange[1] !== 2024) count++
    if (ratingRange[0] !== 0 || ratingRange[1] !== 10) count++
    if (maturityRating !== "all") count++
    if (sortBy !== "relevance") count++
    setActiveFilters(count)
  }, [selectedGenres, contentType, sortBy, yearRange, ratingRange, maturityRating])

  const handleGenreToggle = (genre: string) => {
    if (selectedGenres.includes(genre)) {
      setSelectedGenres(selectedGenres.filter((g) => g !== genre))
    } else {
      setSelectedGenres([...selectedGenres, genre])
    }
  }

  const resetFilters = () => {
    setSelectedGenres([])
    setContentType("all")
    setSortBy("relevance")
    setYearRange([2000, 2024])
    setRatingRange([0, 10])
    setMaturityRating("all")
  }

  return (
    <div className="min-h-screen bg-black">
      <Navbar />

      <div className="container px-4 py-24">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Browse</h1>
          <div className="flex items-center gap-4">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px] bg-black/50 border-white/20">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-black/90 border-white/10">
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="highest">Highest Rated</SelectItem>
                <SelectItem value="lowest">Lowest Rated</SelectItem>
              </SelectContent>
            </Select>

            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Filter className="h-4 w-4" />
                  Filters
                  {activeFilters > 0 && (
                    <span className="ml-1 rounded-full bg-zapred px-2 py-0.5 text-xs">{activeFilters}</span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent className="bg-black/95 border-white/10 w-full max-w-md">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>Refine your browsing experience with advanced filters.</SheetDescription>
                </SheetHeader>

                <div className="flex justify-between items-center mt-4 mb-6">
                  <Button variant="ghost" size="sm" onClick={resetFilters} className="text-zapred">
                    Reset All
                  </Button>
                  <Button size="sm" className="bg-zapred hover:bg-zapred/90" onClick={() => setIsFilterOpen(false)}>
                    Apply Filters
                  </Button>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium mb-3">Content Type</h3>
                    <div className="flex gap-2">
                      <Button
                        variant={contentType === "all" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setContentType("all")}
                        className={contentType === "all" ? "bg-zapred hover:bg-zapred/90" : ""}
                      >
                        All
                      </Button>
                      <Button
                        variant={contentType === "movie" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setContentType("movie")}
                        className={contentType === "movie" ? "bg-zapred hover:bg-zapred/90" : ""}
                      >
                        Movies
                      </Button>
                      <Button
                        variant={contentType === "series" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setContentType("series")}
                        className={contentType === "series" ? "bg-zapred hover:bg-zapred/90" : ""}
                      >
                        TV Shows
                      </Button>
                    </div>
                  </div>

                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="genres" className="border-white/10">
                      <AccordionTrigger className="text-sm font-medium">Genres</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-2 gap-2">
                          {allGenres.map((genre) => (
                            <div key={genre} className="flex items-center space-x-2">
                              <Checkbox
                                id={`genre-${genre}`}
                                checked={selectedGenres.includes(genre)}
                                onCheckedChange={() => handleGenreToggle(genre)}
                              />
                              <label
                                htmlFor={`genre-${genre}`}
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                {genre}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="year" className="border-white/10">
                      <AccordionTrigger className="text-sm font-medium">Release Year</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="flex justify-between">
                            <span>{yearRange[0]}</span>
                            <span>{yearRange[1]}</span>
                          </div>
                          <Slider
                            value={yearRange}
                            min={1900}
                            max={2024}
                            step={1}
                            onValueChange={(value) => setYearRange(value as [number, number])}
                          />
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="rating" className="border-white/10">
                      <AccordionTrigger className="text-sm font-medium">Rating</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="flex justify-between">
                            <span>{ratingRange[0].toFixed(1)}</span>
                            <span>{ratingRange[1].toFixed(1)}</span>
                          </div>
                          <Slider
                            value={ratingRange}
                            min={0}
                            max={10}
                            step={0.1}
                            onValueChange={(value) => setRatingRange(value as [number, number])}
                          />
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="maturity" className="border-white/10">
                      <AccordionTrigger className="text-sm font-medium">Maturity Rating</AccordionTrigger>
                      <AccordionContent>
                        <div className="flex flex-wrap gap-2">
                          <Button
                            variant={maturityRating === "all" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("all")}
                            className={maturityRating === "all" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            All
                          </Button>
                          <Button
                            variant={maturityRating === "G" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("G")}
                            className={maturityRating === "G" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            G
                          </Button>
                          <Button
                            variant={maturityRating === "PG" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("PG")}
                            className={maturityRating === "PG" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            PG
                          </Button>
                          <Button
                            variant={maturityRating === "PG-13" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("PG-13")}
                            className={maturityRating === "PG-13" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            PG-13
                          </Button>
                          <Button
                            variant={maturityRating === "R" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("R")}
                            className={maturityRating === "R" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            R
                          </Button>
                          <Button
                            variant={maturityRating === "13+" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("13+")}
                            className={maturityRating === "13+" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            13+
                          </Button>
                          <Button
                            variant={maturityRating === "16+" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("16+")}
                            className={maturityRating === "16+" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            16+
                          </Button>
                          <Button
                            variant={maturityRating === "18+" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setMaturityRating("18+")}
                            className={maturityRating === "18+" ? "bg-zapred hover:bg-zapred/90" : ""}
                          >
                            18+
                          </Button>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Active filters display */}
        {activeFilters > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {contentType !== "all" && (
              <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-sm">
                <span>Type: {contentType === "movie" ? "Movies" : "TV Shows"}</span>
                <button onClick={() => setContentType("all")}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
            {selectedGenres.map((genre) => (
              <div
                key={genre}
                className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-sm"
              >
                <span>{genre}</span>
                <button onClick={() => handleGenreToggle(genre)}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            {(yearRange[0] !== 2000 || yearRange[1] !== 2024) && (
              <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-sm">
                <span>
                  Year: {yearRange[0]} - {yearRange[1]}
                </span>
                <button onClick={() => setYearRange([2000, 2024])}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
            {(ratingRange[0] !== 0 || ratingRange[1] !== 10) && (
              <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-sm">
                <span>
                  Rating: {ratingRange[0].toFixed(1)} - {ratingRange[1].toFixed(1)}
                </span>
                <button onClick={() => setRatingRange([0, 10])}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
            {maturityRating !== "all" && (
              <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-sm">
                <span>Maturity: {maturityRating}</span>
                <button onClick={() => setMaturityRating("all")}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
            {sortBy !== "relevance" && (
              <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-sm">
                <span>
                  Sort:{" "}
                  {sortBy === "newest"
                    ? "Newest"
                    : sortBy === "oldest"
                      ? "Oldest"
                      : sortBy === "highest"
                        ? "Highest Rated"
                        : "Lowest Rated"}
                </span>
                <button onClick={() => setSortBy("relevance")}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
            <button onClick={resetFilters} className="flex items-center gap-1 bg-zapred rounded-full px-3 py-1 text-sm">
              Clear All
            </button>
          </div>
        )}

        {/* Results */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {filteredContent.length > 0 ? (
            filteredContent.map((item) => (
              <MovieCard
                key={item.id}
                id={item.id}
                title={item.title}
                image={item.image}
                rating={item.rating}
                year={item.year}
                genres={item.genres}
                posterSrc={item.posterSrc}
              />
            ))
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center py-16">
              <Sliders className="h-16 w-16 text-white/20 mb-6" />
              <h2 className="text-2xl font-bold mb-2">No results found</h2>
              <p className="text-white/60 mb-6">Try adjusting your filters for more results</p>
              <Button className="bg-zapred hover:bg-zapred/90" onClick={resetFilters}>
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
