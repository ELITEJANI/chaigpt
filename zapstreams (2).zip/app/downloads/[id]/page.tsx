"use client"

import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Download, ArrowLeft, CheckCircle2, Play, Pause } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { toast } from "@/hooks/use-toast"

interface DownloadDetailPageProps {
  params: {
    id: string
  }
}

export default function DownloadDetailPage({ params }: DownloadDetailPageProps) {
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState<"queued" | "downloading" | "paused" | "completed">("downloading")
  const [downloadSpeed, setDownloadSpeed] = useState("0 MB/s")
  const [timeRemaining, setTimeRemaining] = useState("--:--")

  // Poster images for free media
  const posters: Record<string, string> = {
    "big-buck-bunny": "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
    "tears-of-steel": "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
  }

  // Mock data based on ID
  const getMediaData = (id: string) => {
    if (id === "big-buck-bunny") {
      return {
        id: id,
        title: "BIG BUCK BUNNY",
        description:
          "A large and lovable rabbit deals with three bullies, led by a flying squirrel, who harass him and the forest animals.",
        image: posters[id] || "/placeholder.svg?height=1080&width=1920",
        year: "2008",
        duration: "10m",
        size: "1.2 GB",
        quality: "1080p",
      }
    } else if (id === "tears-of-steel") {
      return {
        id: id,
        title: "TEARS OF STEEL",
        description:
          "In an apocalyptic future, a group of soldiers and scientists takes refuge in Amsterdam to try to stop an army of robots that threatens the planet.",
        image: posters[id] || "/placeholder.svg?height=1080&width=1920",
        year: "2012",
        duration: "12m",
        size: "2.4 GB",
        quality: "4K",
      }
    } else {
      return {
        id: params.id,
        title: params.id.toUpperCase().replace(/-/g, " "),
        description: "No description available.",
        image: "/placeholder.svg?height=1080&width=1920",
        year: "2023",
        duration: "Unknown",
        size: "1.5 GB",
        quality: "1080p",
      }
    }
  }

  const media = getMediaData(params.id)

  // Simulate download progress
  useEffect(() => {
    if (status === "downloading" && progress < 100) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 1
          if (newProgress >= 100) {
            setStatus("completed")
            setDownloadSpeed("0 MB/s")
            setTimeRemaining("00:00")
            toast({
              title: "Download Complete",
              description: `${media.title} has been downloaded successfully`,
            })
            clearInterval(interval)
          } else {
            // Simulate fluctuating download speed
            const speed = (Math.random() * 5 + 1).toFixed(1)
            setDownloadSpeed(`${speed} MB/s`)

            // Calculate time remaining
            const remainingPercent = 100 - newProgress
            const remainingSeconds = remainingPercent * 3 // 3 seconds per percent
            const minutes = Math.floor(remainingSeconds / 60)
            const seconds = Math.floor(remainingSeconds % 60)
            setTimeRemaining(`${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`)
          }
          return newProgress
        })
      }, 300)

      return () => clearInterval(interval)
    }
  }, [status, progress, media.title])

  const handleStartDownload = () => {
    setStatus("downloading")
    toast({
      title: "Download Started",
      description: `${media.title} is now downloading`,
    })
  }

  const handlePauseDownload = () => {
    if (status === "downloading") {
      setStatus("paused")
      toast({
        title: "Download Paused",
        description: `${media.title} download has been paused`,
      })
    } else if (status === "paused") {
      setStatus("downloading")
      toast({
        title: "Download Resumed",
        description: `${media.title} download has been resumed`,
      })
    }
  }

  const handleCancelDownload = () => {
    if (status !== "completed") {
      toast({
        title: "Download Cancelled",
        description: `${media.title} download has been cancelled`,
        variant: "destructive",
      })
    }
    window.history.back()
  }

  const handlePlayMedia = () => {
    toast({
      title: "Playing Media",
      description: `${media.title} is now playing`,
    })
    window.location.href = `/media/${params.id}`
  }

  return (
    <main className="min-h-screen bg-black">
      <Navbar />

      <div className="container px-4 py-24">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/downloads">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Download</h1>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="relative aspect-video overflow-hidden rounded-lg">
            <Image src={media.image || "/placeholder.svg"} alt={media.title} fill className="object-cover" />
            {status === "completed" && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                <Button className="bg-zapred hover:bg-zapred/90" size="lg" onClick={handlePlayMedia}>
                  <Play className="h-5 w-5 mr-2" />
                  Play Now
                </Button>
              </div>
            )}
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-2">{media.title}</h2>
            <p className="text-white/70 mb-6">{media.description}</p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div>
                <p className="text-sm text-white/50">Year</p>
                <p>{media.year}</p>
              </div>
              <div>
                <p className="text-sm text-white/50">Duration</p>
                <p>{media.duration}</p>
              </div>
              <div>
                <p className="text-sm text-white/50">Size</p>
                <p>{media.size}</p>
              </div>
              <div>
                <p className="text-sm text-white/50">Quality</p>
                <p>{media.quality}</p>
              </div>
            </div>

            <div className="bg-black/40 border border-white/10 rounded-md p-4 mb-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {status === "completed" && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                  {status === "downloading" && <Download className="h-5 w-5 text-blue-500" />}
                  {status === "paused" && <Pause className="h-5 w-5 text-yellow-500" />}
                  <span className="font-bold capitalize">{status}</span>
                </div>
                <span>{progress}%</span>
              </div>

              <Progress value={progress} className="h-2 mb-4" />

              {status !== "completed" && (
                <div className="flex justify-between text-sm text-white/70">
                  <span>Speed: {downloadSpeed}</span>
                  <span>Time remaining: {timeRemaining}</span>
                </div>
              )}
            </div>

            <div className="flex gap-4">
              {status === "queued" && (
                <Button className="bg-zapred hover:bg-zapred/90 flex-1" onClick={handleStartDownload}>
                  <Download className="h-4 w-4 mr-2" />
                  Start Download
                </Button>
              )}

              {status === "downloading" && (
                <Button className="bg-yellow-600 hover:bg-yellow-700 flex-1" onClick={handlePauseDownload}>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause Download
                </Button>
              )}

              {status === "paused" && (
                <Button className="bg-zapred hover:bg-zapred/90 flex-1" onClick={handlePauseDownload}>
                  <Play className="h-4 w-4 mr-2" />
                  Resume Download
                </Button>
              )}

              {status === "completed" && (
                <Button className="bg-green-600 hover:bg-green-700 flex-1" onClick={handlePlayMedia}>
                  <Play className="h-4 w-4 mr-2" />
                  Play
                </Button>
              )}

              <Button variant="outline" className="flex-1" onClick={handleCancelDownload}>
                {status === "completed" ? "Back" : "Cancel"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
