"use client"

import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Trash2, Play, Pause, CheckCircle2, Clock } from "lucide-react"
import Image from "next/image"
import { Progress } from "@/components/ui/progress"
import { useState } from "react"
import { useDownloads, type DownloadItem } from "@/hooks/use-downloads"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

export default function DownloadsPage() {
  const { downloads, removeDownload, pauseDownload, resumeDownload } = useDownloads()
  const [activeTab, setActiveTab] = useState("all")

  // Filter downloads based on active tab
  const filteredDownloads = downloads.filter((download) => {
    if (activeTab === "all") return true
    if (activeTab === "movies") return download.type === "movie"
    if (activeTab === "series") return download.type === "series"
    if (activeTab === "completed") return download.status === "completed"
    return true
  })

  const handleRemoveDownload = (id: string) => {
    removeDownload(id)
    toast({
      title: "Download Removed",
      description: "The download has been removed from your list",
    })
  }

  const handlePauseResumeDownload = (download: DownloadItem) => {
    if (download.status === "downloading") {
      pauseDownload(download.id)
      toast({
        title: "Download Paused",
        description: `${download.title} download has been paused`,
      })
    } else if (download.status === "paused") {
      resumeDownload(download.id)
      toast({
        title: "Download Resumed",
        description: `${download.title} download has been resumed`,
      })
    }
  }

  return (
    <main className="min-h-screen bg-black">
      <Navbar />

      <div className="container px-4 py-24">
        <h1 className="text-3xl font-bold mb-8">Downloads</h1>

        <Tabs defaultValue="all" className="mb-8" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-black/40 border border-white/10">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="movies">Movies</TabsTrigger>
            <TabsTrigger value="series">Series</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {filteredDownloads.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16">
                <p className="text-xl text-white/70 mb-4">No downloads</p>
                <p className="text-white/50 mb-8">Download movies and shows to watch them offline</p>
                <Button asChild className="bg-zapred hover:bg-zapred/90">
                  <a href="/">Browse Content</a>
                </Button>
              </div>
            ) : (
              <div className="grid gap-4">
                {filteredDownloads.map((download) => (
                  <div key={download.id} className="flex gap-4 p-4 rounded-md bg-black/40 border border-white/10">
                    <div className="relative w-24 h-16 overflow-hidden rounded-md">
                      <Image
                        src={download.image || "/placeholder.svg"}
                        alt={download.title}
                        fill
                        className="object-cover"
                      />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-bold">{download.title}</h3>
                        <span className="text-sm text-white/70">{download.size}</span>
                      </div>

                      <div className="flex items-center gap-2 mb-2">
                        {download.status === "completed" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                        {download.status === "downloading" && <Download className="h-4 w-4 text-blue-500" />}
                        {download.status === "paused" && <Pause className="h-4 w-4 text-yellow-500" />}
                        {download.status === "queued" && <Clock className="h-4 w-4 text-gray-500" />}

                        <span className="text-sm text-white/70 capitalize">{download.status}</span>
                      </div>

                      {download.status !== "completed" && <Progress value={download.progress} className="h-2" />}
                    </div>

                    <div className="flex items-center gap-2">
                      {download.status === "completed" && (
                        <Button size="icon" variant="ghost" className="rounded-full" asChild>
                          <Link href={`/media/${download.id}?offline=true`}>
                            <Play className="h-5 w-5" />
                          </Link>
                        </Button>
                      )}

                      {(download.status === "downloading" || download.status === "paused") && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="rounded-full"
                          onClick={() => handlePauseResumeDownload(download)}
                        >
                          {download.status === "downloading" ? (
                            <Pause className="h-5 w-5" />
                          ) : (
                            <Play className="h-5 w-5" />
                          )}
                        </Button>
                      )}

                      <Button
                        size="icon"
                        variant="ghost"
                        className="rounded-full text-red-500 hover:text-red-400"
                        onClick={() => handleRemoveDownload(download.id)}
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="bg-black/40 border border-white/10 rounded-md p-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-bold">Download Settings</h2>
          </div>

          <div className="grid gap-4">
            <div className="flex items-center justify-between">
              <span>Download Quality</span>
              <span className="text-white/70">High (1080p)</span>
            </div>

            <div className="flex items-center justify-between">
              <span>Download Location</span>
              <span className="text-white/70">Browser Storage</span>
            </div>

            <div className="flex items-center justify-between">
              <span>Wi-Fi Only</span>
              <span className="text-white/70">On</span>
            </div>

            <div className="flex items-center justify-between">
              <span>Smart Downloads</span>
              <span className="text-white/70">On</span>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
