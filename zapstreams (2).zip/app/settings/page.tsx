"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { MobileLogo } from "@/components/mobile-logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import Link from "next/link"
import Image from "next/image"
import { Save, ArrowLeft } from "lucide-react"
import { useProfiles } from "@/hooks/use-profiles"
import { useRouter } from "next/navigation"
import { toast } from "@/hooks/use-toast"
import { useTheme } from "next-themes"
import { AvatarSelector } from "@/components/avatar-selector"

export default function SettingsPage() {
  const { activeProfile, updateProfile } = useProfiles()
  const { theme, setTheme } = useTheme()
  const router = useRouter()

  const [activeTab, setActiveTab] = useState("profile")
  const [isPinDialogOpen, setIsPinDialogOpen] = useState(false)
  const [pin, setPin] = useState("")
  const [confirmPin, setConfirmPin] = useState("")
  const [pinError, setPinError] = useState("")
  const [selectedColor, setSelectedColor] = useState("zapred")
  const [blurStrength, setBlurStrength] = useState(8)
  const [isDirty, setIsDirty] = useState(false)
  const [settings, setSettings] = useState({
    profileName: "",
    isKidsMode: false,
    isPinLocked: false,
    theme: "dark",
    language: "english",
    subtitlesEnabled: false,
    subtitlesLanguage: "english",
    audioLanguage: "english",
    autoplayEnabled: true,
    dataUsage: "auto",
    downloadQuality: "high",
    notificationsEnabled: true,
  })

  // Get HSL value for a color
  const getColorHsl = (colorName: string) => {
    switch (colorName) {
      case "zapred":
        return "0 72.2% 50.6%"
      case "zapblue":
        return "210 100% 50%"
      case "zapgreen":
        return "150 80% 40%"
      case "zappurple":
        return "280 60% 50%"
      case "zapyellow":
        return "40 100% 50%"
      case "zapgray":
        return "210 10% 50%"
      default:
        return "0 72.2% 50.6%"
    }
  }

  // Load settings from active profile
  useEffect(() => {
    if (activeProfile) {
      setSettings({
        profileName: activeProfile.name,
        isKidsMode: activeProfile.isKids,
        isPinLocked: activeProfile.isPinProtected,
        theme: theme || "dark",
        language: activeProfile.language,
        subtitlesEnabled: false,
        subtitlesLanguage: "english",
        audioLanguage: "english",
        autoplayEnabled: activeProfile.autoplayEnabled,
        dataUsage: "auto",
        downloadQuality: "high",
        notificationsEnabled: true,
      })
    }
  }, [activeProfile, theme])

  // Load saved accent color and theme on component mount
  useEffect(() => {
    const savedAccentColor = localStorage.getItem("zapstreams-accent-color")
    const savedTheme = localStorage.getItem("zapstreams-theme")

    if (savedAccentColor) {
      setSelectedColor(savedAccentColor)
      document.documentElement.style.setProperty("--primary", getColorHsl(savedAccentColor))
      document.documentElement.style.setProperty("--ring", getColorHsl(savedAccentColor))
    }

    if (savedTheme) {
      setSettings((prev) => ({ ...prev, theme: savedTheme }))
      document.documentElement.classList.remove("dark", "light", "blue-radiance", "apple-tv", "emerald")
      document.documentElement.classList.add(savedTheme)
      setTheme(savedTheme)
    }
  }, [setTheme])

  // Apply blur strength
  useEffect(() => {
    document.documentElement.style.setProperty("--blur-strength", `${blurStrength}px`)
  }, [blurStrength])

  // Handle settings changes
  const handleSettingChange = (key: string, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
    setIsDirty(true)
  }

  // Handle PIN dialog
  const handleOpenPinDialog = () => {
    setPin("")
    setConfirmPin("")
    setPinError("")
    setIsPinDialogOpen(true)
  }

  const handleSetPin = () => {
    if (pin.length !== 4 || !/^\d+$/.test(pin)) {
      setPinError("PIN must be 4 digits")
      return
    }

    if (pin !== confirmPin) {
      setPinError("PINs do not match")
      return
    }

    if (activeProfile) {
      updateProfile(activeProfile.id, {
        isPinProtected: true,
        pin,
      })
      setSettings((prev) => ({ ...prev, isPinLocked: true }))
      setIsPinDialogOpen(false)

      toast({
        title: "PIN Set",
        description: "Your PIN has been set successfully",
      })
    }
  }

  // Apply accent color immediately when the Apply button is clicked
  const applyAccentColor = () => {
    // Store the selected color in localStorage for persistence
    localStorage.setItem("zapstreams-accent-color", selectedColor)

    // Update the logo animation class based on the selected color
    const logoElements = document.querySelectorAll(
      ".animate-pulse, .animate-pulse-blue, .animate-pulse-green, .animate-pulse-purple, .animate-pulse-yellow, .animate-pulse-gray",
    )

    logoElements.forEach((logoElement) => {
      logoElement.classList.remove(
        "animate-pulse",
        "animate-pulse-blue",
        "animate-pulse-green",
        "animate-pulse-purple",
        "animate-pulse-yellow",
        "animate-pulse-gray",
      )

      if (selectedColor === "zapred") {
        logoElement.classList.add("animate-pulse")
      } else if (selectedColor === "zapblue") {
        logoElement.classList.add("animate-pulse-blue")
      } else if (selectedColor === "zapgreen") {
        logoElement.classList.add("animate-pulse-green")
      } else if (selectedColor === "zappurple") {
        logoElement.classList.add("animate-pulse-purple")
      } else if (selectedColor === "zapyellow") {
        logoElement.classList.add("animate-pulse-yellow")
      } else if (selectedColor === "zapgray") {
        logoElement.classList.add("animate-pulse-gray")
      }
    })

    // Update CSS variables for the accent color
    document.documentElement.style.setProperty("--primary", getColorHsl(selectedColor))
    document.documentElement.style.setProperty("--ring", getColorHsl(selectedColor))

    // Update all buttons with the selected color class
    const buttons = document.querySelectorAll(
      '[class*="bg-zapred"], [class*="bg-zapblue"], [class*="bg-zapgreen"], [class*="bg-zappurple"], [class*="bg-zapyellow"], [class*="bg-zapgray"]',
    )

    buttons.forEach((button) => {
      // Remove all color classes
      button.classList.remove(
        "bg-zapred",
        "hover:bg-zapred/90",
        "bg-zapblue",
        "hover:bg-zapblue/90",
        "bg-zapgreen",
        "hover:bg-zapgreen/90",
        "bg-zappurple",
        "hover:bg-zappurple/90",
        "bg-zapyellow",
        "hover:bg-zapyellow/90",
        "bg-zapgray",
        "hover:bg-zapgray/90",
      )

      // Add the selected color class
      button.classList.add(`bg-${selectedColor}`, `hover:bg-${selectedColor}/90`)
    })

    toast({
      title: "Accent Color Applied",
      description: "The accent color has been applied to the entire site",
    })
  }

  // Apply theme immediately when changed
  const handleThemeChange = (value: string) => {
    handleSettingChange("theme", value)

    // Store the theme in localStorage for persistence
    localStorage.setItem("zapstreams-theme", value)

    // Apply the theme to the document
    document.documentElement.classList.remove("dark", "light", "blue-radiance", "apple-tv", "emerald")
    document.documentElement.classList.add(value)

    // Also set the theme using the theme provider
    setTheme(value)

    toast({
      title: "Theme Applied",
      description: `The ${value} theme has been applied`,
    })
  }

  // Handle save settings
  const handleSaveSettings = () => {
    if (activeProfile) {
      updateProfile(activeProfile.id, {
        name: settings.profileName,
        isKids: settings.isKidsMode,
        isPinProtected: settings.isPinLocked,
        language: settings.language,
        autoplayEnabled: settings.autoplayEnabled,
      })

      // Save and apply theme
      localStorage.setItem("zapstreams-theme", settings.theme)
      document.documentElement.classList.remove("dark", "light", "blue-radiance", "apple-tv", "emerald")
      document.documentElement.classList.add(settings.theme)
      setTheme(settings.theme)

      // Apply accent color
      applyAccentColor()

      setIsDirty(false)

      toast({
        title: "Settings Saved",
        description: "Your settings have been saved successfully",
      })
    }
  }

  // Color options
  const colorOptions = [
    { name: "Red", value: "zapred", class: "bg-zapred" },
    { name: "Blue", value: "zapblue", class: "bg-zapblue" },
    { name: "Green", value: "zapgreen", class: "bg-zapgreen" },
    { name: "Purple", value: "zappurple", class: "bg-zappurple" },
    { name: "Yellow", value: "zapyellow", class: "bg-zapyellow" },
    { name: "Gray", value: "zapgray", class: "bg-zapgray" },
  ]

  // Handle tab navigation
  const handleTabClick = (e: React.MouseEvent<HTMLAnchorElement>, tab: string) => {
    e.preventDefault()
    setActiveTab(tab)
  }

  return (
    <div className="flex min-h-screen bg-black">
      {/* Sidebar */}
      <div className="w-[208px] border-r border-white/10 p-4">
        <div className="mb-8">
          <MobileLogo />
        </div>
        <nav className="text-sm text-muted-foreground grid gap-4">
          <Link href="/" className="flex items-center gap-2 text-white/70 hover:text-white">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
          <div className="border-t border-white/10 my-2"></div>
          <a
            href="#"
            className={`font-semibold ${activeTab === "profile" ? "text-white" : "text-white/70 hover:text-white"}`}
            onClick={(e) => handleTabClick(e, "profile")}
          >
            Profile
          </a>
          <a
            href="#"
            className={`${activeTab === "theme" ? "text-white font-semibold" : "text-white/70 hover:text-white"}`}
            onClick={(e) => handleTabClick(e, "theme")}
          >
            Theme
          </a>
          <a
            href="#"
            className={`${activeTab === "playback" ? "text-white font-semibold" : "text-white/70 hover:text-white"}`}
            onClick={(e) => handleTabClick(e, "playback")}
          >
            Playback
          </a>
          <a
            href="#"
            className={`${activeTab === "subtitles" ? "text-white font-semibold" : "text-white/70 hover:text-white"}`}
            onClick={(e) => handleTabClick(e, "subtitles")}
          >
            Subtitles & Audio
          </a>
          <a
            href="#"
            className={`${activeTab === "notifications" ? "text-white font-semibold" : "text-white/70 hover:text-white"}`}
            onClick={(e) => handleTabClick(e, "notifications")}
          >
            Notifications
          </a>
          <a
            href="#"
            className={`${activeTab === "account" ? "text-white font-semibold" : "text-white/70 hover:text-white"}`}
            onClick={(e) => handleTabClick(e, "account")}
          >
            Account
          </a>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <header className="border-b border-white/10 p-8 flex justify-between items-center">
          <h1 className="text-4xl font-bold">SETTINGS</h1>
          {isDirty && (
            <Button className="bg-zapred hover:bg-zapred/90" onClick={handleSaveSettings}>
              <Save className="h-4 w-4 mr-2" />
              SAVE CHANGES
            </Button>
          )}
        </header>

        <div className="flex">
          {/* Settings Categories */}
          <div className="w-[280px] border-r border-white/10">
            <div className="p-6">
              <h2 className="mb-6 text-xl font-semibold">Settings</h2>
              <nav className="grid gap-4">
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "profile" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "profile")}
                >
                  Profile
                </a>
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "theme" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "theme")}
                >
                  Theme
                </a>
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "playback" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "playback")}
                >
                  Playback
                </a>
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "subtitles" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "subtitles")}
                >
                  Subtitles & Audio
                </a>
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "notifications" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "notifications")}
                >
                  Notifications
                </a>
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "account" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "account")}
                >
                  Account
                </a>
                <a
                  href="#"
                  className={`flex items-center ${activeTab === "accessibility" ? "border-l-4 border-zapred pl-4 font-semibold" : "pl-4"}`}
                  onClick={(e) => handleTabClick(e, "accessibility")}
                >
                  Accessibility
                </a>
              </nav>
            </div>
          </div>

          {/* Settings Form */}
          <div className="flex-1 p-8">
            {activeTab === "profile" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Profile Settings</h2>

                <div className="grid gap-8">
                  <div className="grid gap-2">
                    <Label htmlFor="profileName">Profile Name</Label>
                    <Input
                      id="profileName"
                      value={settings.profileName}
                      onChange={(e) => handleSettingChange("profileName", e.target.value)}
                      className="bg-black/50 border-white/20"
                    />
                  </div>

                  <div className="grid gap-4">
                    <Label>Avatar</Label>
                    <div className="flex items-center gap-4">
                      <div className="relative h-16 w-16 overflow-hidden rounded-lg">
                        <Image
                          src={activeProfile?.avatar || "/placeholder.svg?height=64&width=64"}
                          alt="Avatar"
                          width={64}
                          height={64}
                          className="object-cover"
                        />
                      </div>
                      <span className="text-lg">Avatar</span>
                      <div className="ml-auto">
                        <AvatarSelector
                          currentAvatar={activeProfile?.avatar || "/placeholder.svg?height=200&width=200"}
                          onSelect={(avatar) => {
                            if (activeProfile) {
                              updateProfile(activeProfile.id, { avatar })
                              setIsDirty(true)
                            }
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="pinLock" className="text-base">
                        PIN Lock
                      </Label>
                      <p className="text-sm text-white/50">Protect your profile with a 4-digit PIN</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        id="pinLock"
                        checked={settings.isPinLocked}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            handleOpenPinDialog()
                          } else {
                            handleSettingChange("isPinLocked", false)
                            if (activeProfile) {
                              updateProfile(activeProfile.id, {
                                isPinProtected: false,
                                pin: undefined,
                              })
                            }
                          }
                        }}
                      />
                      {settings.isPinLocked && (
                        <Button variant="outline" size="sm" onClick={handleOpenPinDialog}>
                          Change PIN
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="kidsMode" className="text-base">
                        Kids Mode
                      </Label>
                      <p className="text-sm text-white/50">Restrict content to kid-friendly options</p>
                    </div>
                    <Switch
                      id="kidsMode"
                      checked={settings.isKidsMode}
                      onCheckedChange={(checked) => handleSettingChange("isKidsMode", checked)}
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="language">Language</Label>
                    <Select value={settings.language} onValueChange={(value) => handleSettingChange("language", value)}>
                      <SelectTrigger id="language" className="bg-black/50 border-white/20">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="spanish">Spanish</SelectItem>
                        <SelectItem value="french">French</SelectItem>
                        <SelectItem value="german">German</SelectItem>
                        <SelectItem value="japanese">Japanese</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            {activeTab === "theme" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Theme Settings</h2>

                <div className="grid gap-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-base">Theme Mode</Label>
                      <p className="text-sm text-white/50">Choose between light and dark mode</p>
                    </div>
                    <Select value={settings.theme} onValueChange={handleThemeChange}>
                      <SelectTrigger className="w-[180px] bg-black/50 border-white/20">
                        <SelectValue placeholder="Select theme" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="system">System</SelectItem>
                        <SelectItem value="blue-radiance">Blue Radiance</SelectItem>
                        <SelectItem value="apple-tv">Apple TV</SelectItem>
                        <SelectItem value="emerald">Emerald</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="colorSelector">Accent Color</Label>
                      <div className="flex gap-2">
                        {colorOptions.map((color) => (
                          <button
                            key={color.value}
                            className={`h-8 w-8 rounded-full ${color.class} ${selectedColor === color.value ? "ring-2 ring-white" : ""}`}
                            onClick={() => setSelectedColor(color.value)}
                            aria-label={`Select ${color.name} color`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="mt-4 p-4 rounded-md bg-black/30 border border-white/10">
                      <p className="text-sm">Preview accent color:</p>
                      <div className="mt-2 flex gap-2">
                        <Button className={`bg-${selectedColor} hover:bg-${selectedColor}/90`}>Primary Button</Button>
                        <Button variant="outline">Secondary Button</Button>
                      </div>
                      <div className="mt-4">
                        <Button onClick={applyAccentColor} className="w-full">
                          Apply Accent Color
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="blurStrength">Blur Strength</Label>
                    <div className="flex items-center gap-4">
                      <Slider
                        id="blurStrength"
                        value={[blurStrength]}
                        max={32}
                        step={1}
                        onValueChange={(value) => setBlurStrength(value[0])}
                        className="flex-1"
                      />
                      <span className="w-8 text-center">{blurStrength}px</span>
                    </div>
                    <div className="mt-4 p-4 rounded-md bg-black/30 border border-white/10 relative overflow-hidden">
                      <div className="absolute inset-0 backdrop-blur-dynamic">
                        <Image
                          src="/placeholder.svg?height=400&width=600"
                          alt="Blur preview"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="relative z-10 p-4">
                        <h3 className="font-bold mb-2">Blur Preview</h3>
                        <p>This shows how the blur effect will look with your selected strength.</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Custom Wallpaper</Label>
                    <Button variant="outline">Select</Button>
                  </div>
                </div>
              </>
            )}

            {activeTab === "playback" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Playback Settings</h2>

                <div className="grid gap-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="autoplay" className="text-base">
                        Autoplay Next Episode
                      </Label>
                      <p className="text-sm text-white/50">Automatically play the next episode in a series</p>
                    </div>
                    <Switch
                      id="autoplay"
                      checked={settings.autoplayEnabled}
                      onCheckedChange={(checked) => handleSettingChange("autoplayEnabled", checked)}
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="dataUsage">Data Usage</Label>
                    <Select
                      value={settings.dataUsage}
                      onValueChange={(value) => handleSettingChange("dataUsage", value)}
                    >
                      <SelectTrigger id="dataUsage" className="bg-black/50 border-white/20">
                        <SelectValue placeholder="Select data usage" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="auto">Auto</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="downloadQuality">Download Quality</Label>
                    <Select
                      value={settings.downloadQuality}
                      onValueChange={(value) => handleSettingChange("downloadQuality", value)}
                    >
                      <SelectTrigger id="downloadQuality" className="bg-black/50 border-white/20">
                        <SelectValue placeholder="Select download quality" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="low">Low (480p)</SelectItem>
                        <SelectItem value="medium">Medium (720p)</SelectItem>
                        <SelectItem value="high">High (1080p)</SelectItem>
                        <SelectItem value="ultra">Ultra (4K)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            {activeTab === "subtitles" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Subtitles & Audio Settings</h2>

                <div className="grid gap-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="subtitlesEnabled" className="text-base">
                        Subtitles
                      </Label>
                      <p className="text-sm text-white/50">Show subtitles during playback</p>
                    </div>
                    <Switch
                      id="subtitlesEnabled"
                      checked={settings.subtitlesEnabled}
                      onCheckedChange={(checked) => handleSettingChange("subtitlesEnabled", checked)}
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="subtitlesLanguage">Preferred Subtitle Language</Label>
                    <Select
                      value={settings.subtitlesLanguage}
                      onValueChange={(value) => handleSettingChange("subtitlesLanguage", value)}
                    >
                      <SelectTrigger id="subtitlesLanguage" className="bg-black/50 border-white/20">
                        <SelectValue placeholder="Select subtitle language" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="spanish">Spanish</SelectItem>
                        <SelectItem value="french">French</SelectItem>
                        <SelectItem value="german">German</SelectItem>
                        <SelectItem value="japanese">Japanese</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="audioLanguage">Preferred Audio Language</Label>
                    <Select
                      value={settings.audioLanguage}
                      onValueChange={(value) => handleSettingChange("audioLanguage", value)}
                    >
                      <SelectTrigger id="audioLanguage" className="bg-black/50 border-white/20">
                        <SelectValue placeholder="Select audio language" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="spanish">Spanish</SelectItem>
                        <SelectItem value="french">French</SelectItem>
                        <SelectItem value="german">German</SelectItem>
                        <SelectItem value="japanese">Japanese</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            {activeTab === "notifications" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Notification Settings</h2>

                <div className="grid gap-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="notificationsEnabled" className="text-base">
                        Notifications
                      </Label>
                      <p className="text-sm text-white/50">Receive notifications about new content and updates</p>
                    </div>
                    <Switch
                      id="notificationsEnabled"
                      checked={settings.notificationsEnabled}
                      onCheckedChange={(checked) => handleSettingChange("notificationsEnabled", checked)}
                    />
                  </div>

                  <div className="border-t border-white/10 pt-4">
                    <h3 className="font-semibold mb-4">Notification Types</h3>

                    <div className="grid gap-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="newContentNotifications" className="text-base">
                          New Content
                        </Label>
                        <Switch id="newContentNotifications" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="recommendationsNotifications" className="text-base">
                          Recommendations
                        </Label>
                        <Switch id="recommendationsNotifications" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="accountNotifications" className="text-base">
                          Account Updates
                        </Label>
                        <Switch id="accountNotifications" defaultChecked />
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {activeTab === "account" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Account Settings</h2>

                <div className="grid gap-8">
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      defaultValue="user@example.com"
                      className="bg-black/50 border-white/20"
                      disabled
                    />
                    <p className="text-sm text-white/50">Contact support to change your email address</p>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="flex gap-2">
                      <Input
                        id="password"
                        type="password"
                        defaultValue="********"
                        className="bg-black/50 border-white/20"
                        disabled
                      />
                      <Button variant="outline">Change</Button>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="subscription">Subscription Plan</Label>
                    <div className="bg-black/50 border border-white/20 rounded-md p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold">Premium Plan</span>
                        <span className="bg-zapred text-white text-xs px-2 py-1 rounded">ACTIVE</span>
                      </div>
                      <p className="text-sm text-white/70 mb-4">4K + HDR, Multiple Devices, Ad-free</p>
                      <Button variant="outline" size="sm">
                        Manage Subscription
                      </Button>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label>Billing Information</Label>
                    <div className="bg-black/50 border border-white/20 rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-10 h-6 bg-blue-500 rounded"></div>
                        <span>•••• •••• •••• 4242</span>
                      </div>
                      <p className="text-sm text-white/70 mb-4">Next billing date: May 15, 2023</p>
                      <Button variant="outline" size="sm">
                        Update Payment Method
                      </Button>
                    </div>
                  </div>

                  <div className="border-t border-white/10 pt-4">
                    <Button variant="destructive">Sign Out</Button>
                  </div>
                </div>
              </>
            )}

            {activeTab === "accessibility" && (
              <>
                <h2 className="mb-8 text-xl font-semibold">Accessibility Settings</h2>

                <div className="grid gap-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="highContrast" className="text-base">
                        High Contrast
                      </Label>
                      <p className="text-sm text-white/50">Increase contrast for better visibility</p>
                    </div>
                    <Switch id="highContrast" />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="reducedMotion" className="text-base">
                        Reduced Motion
                      </Label>
                      <p className="text-sm text-white/50">Minimize animations and transitions</p>
                    </div>
                    <Switch id="reducedMotion" />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="textSize">Text Size</Label>
                    <Select defaultValue="medium">
                      <SelectTrigger id="textSize" className="bg-black/50 border-white/20">
                        <SelectValue placeholder="Select text size" />
                      </SelectTrigger>
                      <SelectContent className="bg-black/90 border-white/10">
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                        <SelectItem value="xlarge">Extra Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            {isDirty && (
              <Button className="mt-8 w-full bg-zapred hover:bg-zapred/90" onClick={handleSaveSettings}>
                SAVE CHANGES
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* PIN Dialog */}
      <Dialog open={isPinDialogOpen} onOpenChange={setIsPinDialogOpen}>
        <DialogContent className="bg-black/90 border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Set PIN</DialogTitle>
          </DialogHeader>

          <div className="py-4">
            <p className="mb-4">Create a 4-digit PIN to protect your profile</p>

            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="pin">PIN</Label>
                <Input
                  id="pin"
                  type="password"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                    setPin(value)
                    setPinError("")
                  }}
                  className="bg-black/50 border-white/20 text-center text-xl tracking-widest"
                  autoFocus
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="confirmPin">Confirm PIN</Label>
                <Input
                  id="confirmPin"
                  type="password"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                    setConfirmPin(value)
                    setPinError("")
                  }}
                  className="bg-black/50 border-white/20 text-center text-xl tracking-widest"
                />
              </div>

              {pinError && <p className="text-red-500 text-sm">{pinError}</p>}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsPinDialogOpen(false)
                setPin("")
                setConfirmPin("")
                setPinError("")
              }}
            >
              Cancel
            </Button>
            <Button className="bg-zapred hover:bg-zapred/90" onClick={handleSetPin}>
              Set PIN
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
