import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { MyListProvider } from "@/hooks/use-my-list"
import { DownloadsProvider } from "@/hooks/use-downloads"
import { ProfilesProvider } from "@/hooks/use-profiles"
import { StreakProvider } from "@/hooks/use-streak"
import { PortalTransition } from "@/components/portal-transition"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ZapStreams",
  description: "Stream your favorite movies and TV shows",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body className={`${inter.className} bg-black text-white antialiased overflow-x-hidden`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} disableTransitionOnChange>
          <ProfilesProvider>
            <MyListProvider>
              <DownloadsProvider>
                <StreakProvider>
                  <PortalTransition>{children}</PortalTransition>
                </StreakProvider>
              </DownloadsProvider>
            </MyListProvider>
          </ProfilesProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
