"use client"

import { ContentRow } from "@/components/content-row"
import { FeaturedContent } from "@/components/featured-content"
import { Navbar } from "@/components/navbar"
import { BackgroundPlayer } from "@/components/background-player"
import { useState } from "react"
import { TopPicks } from "@/components/top-picks"

export default function Home() {
  const [focusedContentId, setFocusedContentId] = useState("the-witcher")

  // Mock data
  const featuredItems = [
    {
      id: "the-witcher",
      title: "THE WITCHER",
      description:
        "A mutated monster hunter for hire, Geralt of Rivia, journeys toward his destiny in a dark world full of dangerous beasts.",
      image: "/placeholder.svg?height=1080&width=1920",
      rating: "8.2",
      genres: ["Action", "Drama", "TV-MAA"],
      year: "2019",
    },
    {
      id: "big-buck-bunny",
      title: "BIG BUCK BUNNY",
      description:
        "A large and lovable rabbit deals with three bullies, led by a flying squirrel, who harass him and the forest animals.",
      image: "/placeholder.svg?height=1080&width=1920",
      rating: "7.8",
      genres: ["Animation", "Comedy", "Short"],
      year: "2008",
    },
    {
      id: "tears-of-steel",
      title: "TEARS OF STEEL",
      description:
        "In an apocalyptic future, a group of soldiers and scientists takes refuge in Amsterdam to try to stop an army of robots that threatens the planet.",
      image: "/placeholder.svg?height=1080&width=1920",
      rating: "6.5",
      genres: ["Sci-Fi", "Action", "Short"],
      year: "2012",
    },
    {
      id: "sintel",
      title: "SINTEL",
      description:
        "A lonely girl travels through harsh landscapes in search of a mysterious dragon who stole her friend.",
      image: "/placeholder.svg?height=1080&width=1920",
      rating: "7.6",
      genres: ["Animation", "Fantasy", "Short"],
      year: "2010",
    },
    {
      id: "elephant-dream",
      title: "ELEPHANT DREAM",
      description:
        "The first Blender Open Movie from 2006, about two strange characters exploring a strange mechanical world.",
      image: "/placeholder.svg?height=1080&width=1920",
      rating: "6.9",
      genres: ["Animation", "Sci-Fi", "Short"],
      year: "2006",
    },
    {
      id: "for-bigger-blazes",
      title: "FOR BIGGER BLAZES",
      description: "Introducing Chromecast. The easiest way to enjoy online video and music on your TV.",
      image: "/placeholder.svg?height=1080&width=1920",
      rating: "6.2",
      genres: ["Comedy", "Short"],
      year: "2013",
    },
  ]

  // Add the topPicks data after the featuredItems array
  const topPicks = [
    {
      id: "dune",
      title: "DUNE",
      description:
        "A noble family becomes embroiled in a war for control over the galaxy's most valuable asset while its heir becomes troubled by visions of a dark future.",
      image: "/placeholder.svg?height=600&width=400",
      backdropImage: "/placeholder.svg?height=1080&width=1920&text=DUNE+BACKDROP",
      posterImage: "/placeholder.svg?height=600&width=400",
      rating: "8.0",
      genres: ["Sci-Fi", "Adventure", "Drama"],
      year: "2021",
      match: 95,
    },
    {
      id: "stranger-things",
      title: "STRANGER THINGS",
      description:
        "When a young boy disappears, his mother, a police chief, and his friends must confront terrifying supernatural forces in order to get him back.",
      image: "/placeholder.svg?height=600&width=400",
      backdropImage: "/placeholder.svg?height=1080&width=1920&text=STRANGER+THINGS+BACKDROP",
      posterImage: "/placeholder.svg?height=600&width=400",
      rating: "8.7",
      genres: ["Horror", "Sci-Fi", "Drama"],
      year: "2016",
      match: 98,
    },
    {
      id: "big-buck-bunny",
      title: "BIG BUCK BUNNY",
      description:
        "A large and lovable rabbit deals with three bullies, led by a flying squirrel, who harass him and the forest animals.",
      image: "/placeholder.svg?height=600&width=400",
      backdropImage: "/placeholder.svg?height=1080&width=1920&text=BIG+BUCK+BUNNY+BACKDROP",
      posterImage: "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
      rating: "7.8",
      genres: ["Animation", "Comedy", "Short"],
      year: "2008",
      match: 92,
    },
    {
      id: "sintel",
      title: "SINTEL",
      description:
        "A lonely girl travels through harsh landscapes in search of a mysterious dragon who stole her friend.",
      image: "/placeholder.svg?height=600&width=400",
      backdropImage: "/placeholder.svg?height=1080&width=1920&text=SINTEL+BACKDROP",
      posterImage: "/placeholder.svg?height=600&width=400",
      rating: "7.6",
      genres: ["Animation", "Fantasy", "Short"],
      year: "2010",
      match: 89,
    },
  ]

  const continueWatching = [
    {
      id: "stranger-things",
      title: "Stranger Things",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.7",
      year: "2016",
      genres: ["Horror", "Sci-Fi"],
      isNew: true,
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "money-heist",
      title: "Money Heist",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.3",
      year: "2017",
      genres: ["Action", "Crime"],
      isDolbyAtmos: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "breaking-bad",
      title: "Breaking Bad",
      image: "/placeholder.svg?height=600&width=400",
      rating: "9.5",
      year: "2008",
      genres: ["Crime", "Drama"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "big-buck-bunny",
      title: "Big Buck Bunny",
      image: "/placeholder.svg?height=600&width=400",
      rating: "7.8",
      year: "2008",
      genres: ["Animation", "Comedy"],
      isTopTen: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      posterSrc: "https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg",
    },
    {
      id: "tears-of-steel",
      title: "Tears of Steel",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.5",
      year: "2012",
      genres: ["Sci-Fi", "Short"],
      isNew: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
      posterSrc: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Tears_of_Steel_poster.jpg",
    },
    {
      id: "sintel",
      title: "Sintel",
      image: "/placeholder.svg?height=600&width=400",
      rating: "7.6",
      year: "2010",
      genres: ["Animation", "Fantasy"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    },
  ]

  const trending = [
    {
      id: "for-bigger-blazes",
      title: "For Bigger Blazes",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.2",
      year: "2013",
      genres: ["Comedy", "Short"],
      isNew: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    },
    {
      id: "for-bigger-escapes",
      title: "For Bigger Escapes",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.4",
      year: "2013",
      genres: ["Adventure", "Short"],
      isTopTen: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    },
    {
      id: "for-bigger-fun",
      title: "For Bigger Fun",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.3",
      year: "2013",
      genres: ["Comedy", "Family"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    },
    {
      id: "for-bigger-joyrides",
      title: "For Bigger Joyrides",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.5",
      year: "2013",
      genres: ["Adventure", "Comedy"],
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    },
    {
      id: "for-bigger-meltdowns",
      title: "For Bigger Meltdowns",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.1",
      year: "2013",
      genres: ["Comedy", "Drama"],
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    },
    {
      id: "elephant-dream",
      title: "Elephant Dream",
      image: "/placeholder.svg?height=600&width=400",
      rating: "6.9",
      year: "2006",
      genres: ["Animation", "Sci-Fi"],
      isDolbyAtmos: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
  ]

  const popularMovies = [
    {
      id: "blade-runner",
      title: "Blade Runner 2049",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.0",
      year: "2017",
      genres: ["Sci-Fi", "Drama"],
      is4K: true,
      isDolbyAtmos: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "john-wick",
      title: "John Wick",
      image: "/placeholder.svg?height=600&width=400",
      rating: "7.4",
      year: "2014",
      genres: ["Action", "Thriller"],
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "mad-max",
      title: "Mad Max: Fury Road",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.1",
      year: "2015",
      genres: ["Action", "Adventure"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "ex-machina",
      title: "Ex Machina",
      image: "/placeholder.svg?height=600&width=400",
      rating: "7.7",
      year: "2014",
      genres: ["Drama", "Sci-Fi"],
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "dune",
      title: "Dune",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.0",
      year: "2021",
      genres: ["Adventure", "Sci-Fi"],
      is4K: true,
      isDolbyAtmos: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "inception",
      title: "Inception",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.8",
      year: "2010",
      genres: ["Action", "Sci-Fi"],
      isTopTen: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
  ]

  const popularShows = [
    {
      id: "game-of-thrones",
      title: "Game of Thrones",
      image: "/placeholder.svg?height=600&width=400",
      rating: "9.2",
      year: "2011",
      genres: ["Action", "Adventure"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "the-last-of-us",
      title: "The Last of Us",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.8",
      year: "2023",
      genres: ["Action", "Adventure"],
      isNew: true,
      isDolbyAtmos: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "the-mandalorian",
      title: "The Mandalorian",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.7",
      year: "2019",
      genres: ["Action", "Adventure"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "succession",
      title: "Succession",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.8",
      year: "2018",
      genres: ["Drama", "Comedy"],
      isTopTen: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "the-boys",
      title: "The Boys",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.7",
      year: "2019",
      genres: ["Action", "Comedy"],
      is4K: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "wednesday",
      title: "Wednesday",
      image: "/placeholder.svg?height=600&width=400",
      rating: "8.1",
      year: "2022",
      genres: ["Comedy", "Fantasy"],
      isNew: true,
      trailerSrc: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
  ]

  const handleFocusChange = (id: string) => {
    setFocusedContentId(id)
  }

  const handleBackgroundChange = (id: string) => {
    setFocusedContentId(id)
  }

  // Find the initial index for the featured content
  const initialFeaturedIndex = featuredItems.findIndex((item) => item.id === focusedContentId) || 0

  return (
    <main className="min-h-screen bg-black">
      {/* Background video player */}
      <BackgroundPlayer
        videoId={
          focusedContentId === "big-buck-bunny"
            ? "big-buck-bunny"
            : focusedContentId === "tears-of-steel"
              ? "tears-of-steel"
              : focusedContentId === "sintel"
                ? "sintel"
                : focusedContentId === "elephant-dream"
                  ? "elephant-dream"
                  : focusedContentId === "for-bigger-blazes"
                    ? "for-bigger-blazes"
                    : focusedContentId === "for-bigger-escapes"
                      ? "for-bigger-escapes"
                      : focusedContentId === "for-bigger-fun"
                        ? "for-bigger-fun"
                        : focusedContentId === "for-bigger-joyrides"
                          ? "for-bigger-joyrides"
                          : focusedContentId === "for-bigger-meltdowns"
                            ? "for-bigger-meltdowns"
                            : "default"
        }
        posterImage="/placeholder.svg?height=1080&width=1920"
      />

      {/* Content layers above the background */}
      <div className="relative z-10">
        <Navbar />
        <FeaturedContent
          featuredItems={featuredItems}
          initialIndex={initialFeaturedIndex >= 0 ? initialFeaturedIndex : 0}
          onChangeBackground={handleBackgroundChange}
        />
        {/* Add the TopPicks component after the FeaturedContent component in the return statement */}
        <div className="container px-4 py-8">
          <TopPicks picks={topPicks} />
          <ContentRow title="CONTINUE WATCHING" movies={continueWatching} onFocusChange={handleFocusChange} />
          <ContentRow title="TRENDING" movies={trending} onFocusChange={handleFocusChange} />
          <ContentRow title="POPULAR MOVIES" movies={popularMovies} onFocusChange={handleFocusChange} />
          <ContentRow title="POPULAR SHOWS" movies={popularShows} onFocusChange={handleFocusChange} />
        </div>
      </div>
    </main>
  )
}
