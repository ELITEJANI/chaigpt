import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs-extra';

// Function to check if ffmpeg is installed
export async function checkFfmpeg() {
return new Promise((resolve) => {
  ffmpeg.getAvailableFormats((err) => {
    if (err) {
      console.error('FFmpeg is not installed or not in PATH');
      resolve(false);
    } else {
      resolve(true);
    }
  });
});
}

// Function to analyze a video file using ffprobe
export async function analyzeVideoFile(filePath) {
console.log(`Analyzing video file: ${filePath}`);

// Check if file exists
if (!await fs.pathExists(filePath)) {
  console.error(`File not found: ${filePath}`);
  throw new Error(`File not found: ${filePath}`);
}

return new Promise((resolve, reject) => {
  ffmpeg.ffprobe(filePath, (err, metadata) => {
    if (err) {
      console.error(`Error analyzing video file: ${filePath}`, err);
      // Return default values if analysis fails
      resolve({
        hasSubtitles: false,
        audioTracks: [],
        duration: 0,
        resolution: 'unknown'
      });
      return;
    }
    
    try {
      // Extract video streams
      const videoStreams = metadata.streams.filter(stream => stream.codec_type === 'video');
      
      // Extract audio streams
      const audioStreams = metadata.streams.filter(stream => stream.codec_type === 'audio');
      const audioTracks = audioStreams.map(stream => {
        return {
          index: stream.index,
          language: stream.tags?.language || 'unknown',
          codec: stream.codec_name,
          channels: stream.channels
        };
      });
      
      // Extract subtitle streams
      const subtitleStreams = metadata.streams.filter(stream => stream.codec_type === 'subtitle');
      const hasSubtitles = subtitleStreams.length > 0;
      
      // Extract basic video info
      const videoInfo = videoStreams[0] || {};
      const width = videoInfo.width;
      const height = videoInfo.height;
      const resolution = width && height ? `${width}x${height}` : 'unknown';
      
      // Extract duration
      const duration = metadata.format.duration || 0;
      
      // Return video analysis results
      resolve({
        hasSubtitles,
        subtitleStreams: subtitleStreams.map(stream => ({
          index: stream.index,
          language: stream.tags?.language || 'unknown',
          codec: stream.codec_name
        })),
        audioTracks: audioTracks.map(track => track.language),
        audioStreams: audioTracks,
        duration,
        resolution,
        format: metadata.format.format_name,
        size: metadata.format.size,
        bitrate: metadata.format.bit_rate
      });
    } catch (error) {
      console.error(`Error processing video metadata: ${filePath}`, error);
      // Return default values if processing fails
      resolve({
        hasSubtitles: false,
        audioTracks: [],
        duration: 0,
        resolution: 'unknown'
      });
    }
  });
});
}