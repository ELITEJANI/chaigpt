// Simple in-memory cache implementation

class Cache {
  constructor(ttl = 60000) {
    this.cache = new Map();
    this.ttl = ttl; // Time to live in milliseconds
  }
  
  // Get item from cache
  get(key) {
    const item = this.cache.get(key);
    if (!item) return null;
    
    // Check if item has expired
    if (Date.now() > item.expiry) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value;
  }
  
  // Set item in cache
  set(key, value, ttl = this.ttl) {
    const expiry = Date.now() + ttl;
    this.cache.set(key, { value, expiry });
    return true;
  }
  
  // Delete item from cache
  delete(key) {
    return this.cache.delete(key);
  }
  
  // Clear entire cache
  clear() {
    this.cache.clear();
    return true;
  }
  
  // Get cache size
  size() {
    return this.cache.size;
  }
  
  // Clean expired items
  cleanExpired() {
    const now = Date.now();
    let count = 0;
    
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiry) {
        this.cache.delete(key);
        count++;
      }
    }
    
    return count;
  }
}

// Create cache instances
const caches = {
  movies: new Cache(300000), // 5 minutes
  series: new Cache(300000), // 5 minutes
  search: new Cache(60000),  // 1 minute
  stats: new Cache(60000)    // 1 minute
};

// Schedule cache cleanup
setInterval(() => {
  let total = 0;
  for (const [name, cache] of Object.entries(caches)) {
    const count = cache.cleanExpired();
    if (count > 0) {
      console.log(`Cleaned ${count} expired items from ${name} cache`);
      total += count;
    }
  }
  if (total > 0) {
    console.log(`Total cleaned items: ${total}`);
  }
}, 60000); // Clean every minute

export default caches;