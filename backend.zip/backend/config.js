// Configuration for the media library backend

export default {
  // Paths to scan
  paths: {
    movies: process.env.MOVIES_PATH || 'U:\\DriveSeed',
    series: process.env.SERIES_PATH || 'X:\\Series'
  },
  
  // Supported video file extensions
  videoExtensions: ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'],
  
  // Database settings
  database: {
    path: './mediaDB.json',
    backupPath: './mediaDB.backup.json',
    // How often to save the database during scanning (in milliseconds)
    saveInterval: 30000
  },
  
  // Scanning options
  scanning: {
    // If true, only scan files that have been modified since the last scan
    incremental: true,
    // Maximum number of concurrent file operations
    concurrency: 5,
    // If true, save database after each item is processed
    saveAfterEach: false
  },
  
  // File watcher options
  watcher: {
    // If true, watch for file changes
    enabled: true,
    // Stabilization time in milliseconds before processing a changed file
    stabilityThreshold: 5000
  },
  
  // API settings
  api: {
    port: process.env.PORT || 3000,
    // Enable CORS
    cors: true,
    // Rate limiting (requests per minute)
    rateLimit: 100
  },
  
  // Cache settings
  cache: {
    // Default TTL in milliseconds
    defaultTtl: 300000, // 5 minutes
    // TTLs for specific cache types
    ttls: {
      movies: 300000,    // 5 minutes
      series: 300000,    // 5 minutes
      search: 60000,     // 1 minute
      stats: 60000       // 1 minute
    }
  }
};