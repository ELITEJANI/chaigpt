import fs from 'fs-extra';
import path from 'path';
import { analyzeVideoFile } from './analyzer.js';
import { fetchMovieMetadata, fetchSeriesMetadata } from './metadata.js';
import { saveDatabase } from './database.js';
import config from './config.js';

// Function to check if a file is a video
const isVideoFile = (filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  return config.videoExtensions.includes(ext);
};

// Function to extract title and year from movie filename
const extractMovieInfo = (filename) => {
  // Example: "The.Dark.Knight.2008.1080p.mkv" -> title: "The Dark Knight", year: 2008
  const fileNameMatch = filename.match(/^(.+?)\.(\d{4})/);
  const title = fileNameMatch ? fileNameMatch[1].replace(/\./g, ' ') : path.parse(filename).name;
  const year = fileNameMatch ? parseInt(fileNameMatch[2]) : null;
  
  return { title, year };
};

// Function to extract series info from path and filename
const extractSeriesInfo = (filePath) => {
  // Example: "X:\Series\Breaking Bad\Season 01\Breaking.Bad.S01E01.mkv"
  const pathParts = filePath.split(path.sep);
  const seriesIndex = pathParts.indexOf('Series');
  const seriesName = seriesIndex !== -1 && seriesIndex + 1 < pathParts.length 
    ? pathParts[seriesIndex + 1].replace(/\./g, ' ') 
    : path.basename(path.dirname(path.dirname(filePath))).replace(/\./g, ' ');
  
  // Extract season and episode from filename
  // Example: "Breaking.Bad.S01E01.mkv" -> season: 1, episode: 1
  const fileNameMatch = path.basename(filePath).match(/S(\d+)E(\d+)/i);
  const season = fileNameMatch ? parseInt(fileNameMatch[1]) : null;
  const episode = fileNameMatch ? parseInt(fileNameMatch[2]) : null;
  
  return { seriesName, season, episode };
};

// Function to scan a directory recursively
async function scanDirectory(dirPath, fileList = []) {
  try {
    const items = await fs.readdir(dirPath);
    
    for (const item of items) {
      const itemPath = path.join(dirPath, item);
      const stats = await fs.stat(itemPath);
      
      if (stats.isDirectory()) {
        await scanDirectory(itemPath, fileList);
      } else if (isVideoFile(itemPath)) {
        fileList.push({
          path: itemPath,
          size: stats.size,
          mtime: stats.mtime.getTime()
        });
      }
    }
    
    return fileList;
  } catch (error) {
    console.error(`Error scanning directory ${dirPath}:`, error);
    return fileList;
  }
}

// Function to process a movie file
async function processMovieFile(filePath, db) {
  console.log(`Processing movie file: ${filePath}`);
  
  try {
    // Check if file exists
    if (!await fs.pathExists(filePath)) {
      console.error(`File not found: ${filePath}`);
      return null;
    }
    
    // Analyze video file
    const videoInfo = await analyzeVideoFile(filePath);
    
    // Extract title and year from filename
    const filename = path.basename(filePath);
    const { title, year } = extractMovieInfo(filename);
    
    // Fetch metadata
    const metadata = await fetchMovieMetadata(title, year);
    
    // Check for external subtitle files
    const baseName = path.parse(filePath).name;
    const dirName = path.dirname(filePath);
    const subtitleFiles = (await fs.readdir(dirName))
      .filter(f => f.startsWith(baseName) && f.endsWith('.srt'))
      .map(f => path.join(dirName, f));
    
    // Check for .nfo file
    const nfoPath = path.join(dirName, `${baseName}.nfo`);
    const hasNfo = await fs.pathExists(nfoPath);
    let nfoData = null;
    
    if (hasNfo) {
      try {
        const nfoContent = await fs.readFile(nfoPath, 'utf8');
        nfoData = { content: nfoContent };
      } catch (error) {
        console.error(`Error reading NFO file ${nfoPath}:`, error);
      }
    }
    
    // Check if movie already exists in database
    const existingIndex = db.movies.findIndex(movie => movie.path === filePath);
    const movieData = {
      title: metadata?.title || title,
      year: metadata?.year || year,
      path: filePath,
      metadata: metadata,
      nfoData: nfoData,
      externalSubtitles: subtitleFiles,
      embeddedSubtitles: videoInfo.hasSubtitles,
      audioTracks: videoInfo.audioTracks,
      lastScanned: Date.now()
    };
    
    if (existingIndex !== -1) {
      // Update existing movie
      db.movies[existingIndex] = movieData;
      console.log(`Updated movie: ${title} (${year || 'unknown year'})`);
    } else {
      // Add new movie
      db.movies.push(movieData);
      console.log(`Added new movie: ${title} (${year || 'unknown year'})`);
    }
    
    return movieData;
  } catch (error) {
    console.error(`Error processing movie file: ${filePath}`, error);
    return null;
  }
}

// Function to process a series file
async function processSeriesFile(filePath, db) {
  console.log(`Processing series file: ${filePath}`);
  
  try {
    // Check if file exists
    if (!await fs.pathExists(filePath)) {
      console.error(`File not found: ${filePath}`);
      return null;
    }
    
    // Analyze video file
    const videoInfo = await analyzeVideoFile(filePath);
    
    // Extract series info
    const { seriesName, season, episode } = extractSeriesInfo(filePath);
    
    // Fetch metadata
    const metadata = await fetchSeriesMetadata(seriesName, season, episode);
    
    // Check for external subtitle files
    const baseName = path.parse(filePath).name;
    const dirName = path.dirname(filePath);
    const subtitleFiles = (await fs.readdir(dirName))
      .filter(f => f.startsWith(baseName) && f.endsWith('.srt'))
      .map(f => path.join(dirName, f));
    
    // Check for .nfo file
    const nfoPath = path.join(dirName, `${baseName}.nfo`);
    const hasNfo = await fs.pathExists(nfoPath);
    let nfoData = null;
    
    if (hasNfo) {
      try {
        const nfoContent = await fs.readFile(nfoPath, 'utf8');
        nfoData = { content: nfoContent };
      } catch (error) {
        console.error(`Error reading NFO file ${nfoPath}:`, error);
      }
    }
    
    // Check if episode already exists in database
    const existingIndex = db.series.findIndex(ep => ep.path === filePath);
    const episodeData = {
      show: seriesName,
      season: season,
      episode: episode,
      title: metadata?.episodeTitle || `Episode ${episode}`,
      path: filePath,
      metadata: metadata,
      nfoData: nfoData,
      externalSubtitles: subtitleFiles,
      embeddedSubtitles: videoInfo.hasSubtitles,
      audioTracks: videoInfo.audioTracks,
      lastScanned: Date.now()
    };
    
    if (existingIndex !== -1) {
      // Update existing episode
      db.series[existingIndex] = episodeData;
      console.log(`Updated episode: ${seriesName} S${season}E${episode}`);
    } else {
      // Add new episode
      db.series.push(episodeData);
      console.log(`Added new episode: ${seriesName} S${season}E${episode}`);
    }
    
    return episodeData;
  } catch (error) {
    console.error(`Error processing series file: ${filePath}`, error);
    return null;
  }
}

// Function to scan media library
export async function scanMediaLibrary(db) {
  console.log('Scanning media library...');
  
  // Set last scan time
  db.lastScan = Date.now();
  
  // Scan movies directory
  console.log(`Scanning movies directory: ${config.paths.movies}`);
  let movieFiles = [];
  try {
    if (await fs.pathExists(config.paths.movies)) {
      movieFiles = await scanDirectory(config.paths.movies);
    } else {
      console.error(`Movies directory not found: ${config.paths.movies}`);
    }
  } catch (error) {
    console.error(`Error scanning movies directory: ${config.paths.movies}`, error);
  }
  
  // Scan series directory
  console.log(`Scanning series directory: ${config.paths.series}`);
  let seriesFiles = [];
  try {
    if (await fs.pathExists(config.paths.series)) {
      seriesFiles = await scanDirectory(config.paths.series);
    } else {
      console.error(`Series directory not found: ${config.paths.series}`);
    }
  } catch (error) {
    console.error(`Error scanning series directory: ${config.paths.series}`, error);
  }
  
  console.log(`Found ${movieFiles.length} movie files and ${seriesFiles.length} series files`);
  
  // Filter files if incremental scanning is enabled
  if (config.scanning.incremental && db.lastScan) {
    const lastScanTime = db.lastScan;
    
    movieFiles = movieFiles.filter(file => {
      // Check if file is new or modified since last scan
      const existingMovie = db.movies.find(movie => movie.path === file.path);
      return !existingMovie || file.mtime > lastScanTime;
    });
    
    seriesFiles = seriesFiles.filter(file => {
      // Check if file is new or modified since last scan
      const existingEpisode = db.series.find(episode => episode.path === file.path);
      return !existingEpisode || file.mtime > lastScanTime;
    });
    
    console.log(`After incremental filtering: ${movieFiles.length} movie files and ${seriesFiles.length} series files to process`);
  }
  
  // Process movie files
  let processedMovies = 0;
  let saveInterval = null;
  
  if (config.scanning.saveInterval > 0) {
    saveInterval = setInterval(() => {
      console.log('Saving database...');
      saveDatabase(db);
    }, config.scanning.saveInterval);
  }
  
  for (const file of movieFiles) {
    await processMovieFile(file.path, db);
    processedMovies++;
    
    if (config.scanning.saveAfterEach) {
      await saveDatabase(db);
    }
  }
  
  // Process series files
  let processedEpisodes = 0;
  for (const file of seriesFiles) {
    await processSeriesFile(file.path, db);
    processedEpisodes++;
    
    if (config.scanning.saveAfterEach) {
      await saveDatabase(db);
    }
  }
  
  if (saveInterval) {
    clearInterval(saveInterval);
  }
  
  // Save database
  await saveDatabase(db);
  
  console.log(`Processed ${processedMovies} movies and ${processedEpisodes} episodes`);
  
  return {
    movies: processedMovies,
    episodes: processedEpisodes
  };
}