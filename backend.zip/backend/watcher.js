import fs from 'fs-extra';
import path from 'path';
import { watch } from 'chokidar';
import { analyzeVideoFile } from './analyzer.js';
import { fetchMovieMetadata, fetchSeriesMetadata } from './metadata.js';
import { saveDatabase } from './database.js';
import config from './config.js';

// Function to check if a file is a video
const isVideoFile = (filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  return config.videoExtensions.includes(ext);
};

// Function to extract title and year from movie filename
const extractMovieInfo = (filename) => {
  // Example: "The.Dark.Knight.2008.1080p.mkv" -> title: "The Dark Knight", year: 2008
  const fileNameMatch = filename.match(/^(.+?)\.(\d{4})/);
  const title = fileNameMatch ? fileNameMatch[1].replace(/\./g, ' ') : path.parse(filename).name;
  const year = fileNameMatch ? parseInt(fileNameMatch[2]) : null;
  
  return { title, year };
};

// Function to extract series info from path and filename
const extractSeriesInfo = (filePath) => {
  // Example: "X:\Series\Breaking Bad\Season 01\Breaking.Bad.S01E01.mkv"
  const pathParts = filePath.split(path.sep);
  const seriesIndex = pathParts.indexOf('Series');
  const seriesName = seriesIndex !== -1 && seriesIndex + 1 < pathParts.length 
    ? pathParts[seriesIndex + 1].replace(/\./g, ' ') 
    : path.basename(path.dirname(path.dirname(filePath))).replace(/\./g, ' ');
  
  // Extract season and episode from filename
  // Example: "Breaking.Bad.S01E01.mkv" -> season: 1, episode: 1
  const fileNameMatch = path.basename(filePath).match(/S(\d+)E(\d+)/i);
  const season = fileNameMatch ? parseInt(fileNameMatch[1]) : null;
  const episode = fileNameMatch ? parseInt(fileNameMatch[2]) : null;
  
  return { seriesName, season, episode };
};

// Function to process a movie file
async function processMovieFile(filePath, db) {
  console.log(`Processing movie file: ${filePath}`);
  
  try {
    // Analyze video file
    const videoInfo = await analyzeVideoFile(filePath);
    
    // Extract title and year from filename
    const filename = path.basename(filePath);
    const { title, year } = extractMovieInfo(filename);
    
    // Fetch metadata
    const metadata = await fetchMovieMetadata(title, year);
    
    // Check for external subtitle files
    const baseName = path.parse(filePath).name;
    const dirName = path.dirname(filePath);
    const subtitleFiles = (await fs.readdir(dirName))
      .filter(f => f.startsWith(baseName) && f.endsWith('.srt'))
      .map(f => path.join(dirName, f));
    
    // Check for .nfo file
    const nfoPath = path.join(dirName, `${baseName}.nfo`);
    const hasNfo = await fs.pathExists(nfoPath);
    let nfoData = null;
    
    if (hasNfo) {
      try {
        const nfoContent = await fs.readFile(nfoPath, 'utf8');
        nfoData = { content: nfoContent };
      } catch (error) {
        console.error(`Error reading NFO file ${nfoPath}:`, error);
      }
    }
    
    // Check if movie already exists in database
    const existingIndex = db.movies.findIndex(movie => movie.path === filePath);
    const movieData = {
      title: metadata?.title || title,
      year: metadata?.year || year,
      path: filePath,
      metadata: metadata,
      nfoData: nfoData,
      externalSubtitles: subtitleFiles,
      embeddedSubtitles: videoInfo.hasSubtitles,
      audioTracks: videoInfo.audioTracks,
      lastScanned: Date.now()
    };
    
    if (existingIndex !== -1) {
      // Update existing movie
      db.movies[existingIndex] = movieData;
      console.log(`Updated movie: ${title} (${year || 'unknown year'})`);
    } else {
      // Add new movie
      db.movies.push(movieData);
      console.log(`Added new movie: ${title} (${year || 'unknown year'})`);
    }
    
    // Save database
    await saveDatabase(db);
    
    return movieData;
  } catch (error) {
    console.error(`Error processing movie file: ${filePath}`, error);
    return null;
  }
}

// Function to process a series file
async function processSeriesFile(filePath, db) {
  console.log(`Processing series file: ${filePath}`);
  
  try {
    // Analyze video file
    const videoInfo = await analyzeVideoFile(filePath);
    
    // Extract series info
    const { seriesName, season, episode } = extractSeriesInfo(filePath);
    
    // Fetch metadata
    const metadata = await fetchSeriesMetadata(seriesName, season, episode);
    
    // Check for external subtitle files
    const baseName = path.parse(filePath).name;
    const dirName = path.dirname(filePath);
    const subtitleFiles = (await fs.readdir(dirName))
      .filter(f => f.startsWith(baseName) && f.endsWith('.srt'))
      .map(f => path.join(dirName, f));
    
    // Check for .nfo file
    const nfoPath = path.join(dirName, `${baseName}.nfo`);
    const hasNfo = await fs.pathExists(nfoPath);
    let nfoData = null;
    
    if (hasNfo) {
      try {
        const nfoContent = await fs.readFile(nfoPath, 'utf8');
        nfoData = { content: nfoContent };
      } catch (error) {
        console.error(`Error reading NFO file ${nfoPath}:`, error);
      }
    }
    
    // Check if episode already exists in database
    const existingIndex = db.series.findIndex(ep => ep.path === filePath);
    const episodeData = {
      show: seriesName,
      season: season,
      episode: episode,
      title: metadata?.episodeTitle || `Episode ${episode}`,
      path: filePath,
      metadata: metadata,
      nfoData: nfoData,
      externalSubtitles: subtitleFiles,
      embeddedSubtitles: videoInfo.hasSubtitles,
      audioTracks: videoInfo.audioTracks,
      lastScanned: Date.now()
    };
    
    if (existingIndex !== -1) {
      // Update existing episode
      db.series[existingIndex] = episodeData;
      console.log(`Updated episode: ${seriesName} S${season}E${episode}`);
    } else {
      // Add new episode
      db.series.push(episodeData);
      console.log(`Added new episode: ${seriesName} S${season}E${episode}`);
    }
    
    // Save database
    await saveDatabase(db);
    
    return episodeData;
  } catch (error) {
    console.error(`Error processing series file: ${filePath}`, error);
    return null;
  }
}

// Function to handle file deletion
function handleDeletedFile(filePath, db) {
  console.log(`File deleted: ${filePath}`);
  
  // Check if it's a movie
  const movieIndex = db.movies.findIndex(movie => movie.path === filePath);
  if (movieIndex !== -1) {
    const movie = db.movies[movieIndex];
    console.log(`Removing movie from database: ${movie.title}`);
    db.movies.splice(movieIndex, 1);
    saveDatabase(db);
    return;
  }
  
  // Check if it's an episode
  const episodeIndex = db.series.findIndex(episode => episode.path === filePath);
  if (episodeIndex !== -1) {
    const episode = db.series[episodeIndex];
    console.log(`Removing episode from database: ${episode.show} S${episode.season}E${episode.episode}`);
    db.series.splice(episodeIndex, 1);
    saveDatabase(db);
    return;
  }
}

// Function to start watching for file changes
export function startFileWatcher(db) {
  console.log('Starting file watcher...');
  
  // Create watcher
  const watcher = watch([config.paths.movies, config.paths.series], {
    persistent: true,
    ignoreInitial: true,
    awaitWriteFinish: {
      stabilityThreshold: 2000,
      pollInterval: 100
    }
  });
  
  // Handle file add/change events
  watcher.on('add', async (filePath) => {
    if (isVideoFile(filePath)) {
      console.log(`New file detected: ${filePath}`);
      if (filePath.includes(config.paths.movies)) {
        await processMovieFile(filePath, db);
      } else if (filePath.includes(config.paths.series)) {
        await processSeriesFile(filePath, db);
      }
    }
  });
  
  watcher.on('change', async (filePath) => {
    if (isVideoFile(filePath)) {
      console.log(`File changed: ${filePath}`);
      if (filePath.includes(config.paths.movies)) {
        await processMovieFile(filePath, db);
      } else if (filePath.includes(config.paths.series)) {
        await processSeriesFile(filePath, db);
      }
    }
  });
  
  watcher.on('unlink', (filePath) => {
    if (isVideoFile(filePath)) {
      handleDeletedFile(filePath, db);
    }
  });
  
  watcher.on('error', (error) => {
    console.error('File watcher error:', error);
  });
  
  console.log(`Watching for changes in: ${config.paths.movies} and ${config.paths.series}`);
  
  return watcher;
}