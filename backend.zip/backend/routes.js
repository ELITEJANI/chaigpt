import { scanMediaLibrary } from './scanner.js';
import caches from './cache.js';

// Function to setup API routes
export function setupRoutes(app, db) {
  // Middleware to add cache headers
  const cacheControl = (maxAge) => (req, res, next) => {
    res.set('Cache-Control', `public, max-age=${maxAge}`);
    next();
  };
  
  // GET /api/movies - Return list of all movies
  app.get('/api/movies', cacheControl(60), (req, res) => {
    // Generate cache key based on query parameters
    const cacheKey = `movies_${JSON.stringify(req.query)}`;
    
    // Check cache
    const cachedResult = caches.movies.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    // Support pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    
    // Support sorting
    const sortBy = req.query.sort || 'title';
    const sortOrder = req.query.order === 'desc' ? -1 : 1;
    
    // Clone and sort movies
    const sortedMovies = [...db.movies].sort((a, b) => {
      if (sortBy === 'title') {
        return sortOrder * a.title.localeCompare(b.title);
      } else if (sortBy === 'year') {
        return sortOrder * ((a.year || 0) - (b.year || 0));
      }
      return 0;
    });
    
    // Paginate results
    const paginatedMovies = sortedMovies.slice(startIndex, endIndex);
    
    const result = {
      total: db.movies.length,
      page,
      limit,
      totalPages: Math.ceil(db.movies.length / limit),
      data: paginatedMovies
    };
    
    // Cache result
    caches.movies.set(cacheKey, result);
    
    res.json(result);
  });
  
  // GET /api/movies/:id - Return a specific movie by ID
  app.get('/api/movies/:id', cacheControl(300), (req, res) => {
    const id = req.params.id;
    const cacheKey = `movie_${id}`;
    
    // Check cache
    const cachedResult = caches.movies.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    const movie = db.movies.find(m => m.metadata?.imdbId === id || m.metadata?.tmdbId === parseInt(id));
    
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    
    // Cache result
    caches.movies.set(cacheKey, movie);
    
    res.json(movie);
  });
  
  // GET /api/series - Return list of all series/episodes
  app.get('/api/series', cacheControl(60), (req, res) => {
    const cacheKey = 'series_list';
    
    // Check cache
    const cachedResult = caches.series.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    // Group episodes by show
    const shows = {};
    
    db.series.forEach(episode => {
      if (!shows[episode.show]) {
        shows[episode.show] = {
          title: episode.show,
          seasons: {}
        };
      }
      
      if (episode.season !== null) {
        if (!shows[episode.show].seasons[episode.season]) {
          shows[episode.show].seasons[episode.season] = [];
        }
        
        shows[episode.show].seasons[episode.season].push(episode);
      }
    });
    
    // Convert to array
    const seriesArray = Object.values(shows).map(show => {
      // Convert seasons object to array
      const seasonsArray = Object.entries(show.seasons).map(([seasonNumber, episodes]) => {
        return {
          season: parseInt(seasonNumber),
          episodes: episodes.sort((a, b) => (a.episode || 0) - (b.episode || 0))
        };
      });
      
      return {
        title: show.title,
        seasons: seasonsArray.sort((a, b) => a.season - b.season)
      };
    });
    
    // Cache result
    caches.series.set(cacheKey, seriesArray);
    
    res.json(seriesArray);
  });
  
  // GET /api/series/:show - Return a specific show
  app.get('/api/series/:show', cacheControl(300), (req, res) => {
    const showName = req.params.show;
    const cacheKey = `series_${showName}`;
    
    // Check cache
    const cachedResult = caches.series.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    const episodes = db.series.filter(episode => 
      episode.show.toLowerCase() === showName.toLowerCase()
    );
    
    if (episodes.length === 0) {
      return res.status(404).json({ error: 'Show not found' });
    }
    
    // Group by season
    const seasons = {};
    episodes.forEach(episode => {
      if (episode.season !== null) {
        if (!seasons[episode.season]) {
          seasons[episode.season] = [];
        }
        
        seasons[episode.season].push(episode);
      }
    });
    
    // Convert to array
    const seasonsArray = Object.entries(seasons).map(([seasonNumber, episodes]) => {
      return {
        season: parseInt(seasonNumber),
        episodes: episodes.sort((a, b) => (a.episode || 0) - (b.episode || 0))
      };
    });
    
    const result = {
      title: episodes[0].show,
      seasons: seasonsArray.sort((a, b) => a.season - b.season)
    };
    
    // Cache result
    caches.series.set(cacheKey, result);
    
    res.json(result);
  });
  
  // GET /api/series/:show/:season/:episode - Return a specific episode
  app.get('/api/series/:show/:season/:episode', cacheControl(300), (req, res) => {
    const showName = req.params.show;
    const seasonNumber = parseInt(req.params.season);
    const episodeNumber = parseInt(req.params.episode);
    
    const cacheKey = `episode_${showName}_${seasonNumber}_${episodeNumber}`;
    
    // Check cache
    const cachedResult = caches.series.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    const episode = db.series.find(ep => 
      ep.show.toLowerCase() === showName.toLowerCase() &&
      ep.season === seasonNumber &&
      ep.episode === episodeNumber
    );
    
    if (!episode) {
      return res.status(404).json({ error: 'Episode not found' });
    }
    
    // Cache result
    caches.series.set(cacheKey, episode);
    
    res.json(episode);
  });
  
  // GET /api/media/:title - Search by title name
  app.get('/api/media/:title', (req, res) => {
    const title = req.params.title.toLowerCase();
    
    const cacheKey = `search_${title}`;
    
    // Check cache
    const cachedResult = caches.search.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    // Search in movies
    const movies = db.movies.filter(movie => 
      movie.title.toLowerCase().includes(title)
    );
    
    // Search in series
    const episodes = db.series.filter(episode => 
      episode.show.toLowerCase().includes(title) || 
      (episode.title && episode.title.toLowerCase().includes(title))
    );
    
    // Group episodes by show
    const shows = {};
    episodes.forEach(episode => {
      if (!shows[episode.show]) {
        shows[episode.show] = [];
      }
      shows[episode.show].push(episode);
    });
    
    const result = {
      movies,
      shows: Object.entries(shows).map(([show, episodes]) => ({
        title: show,
        episodes: episodes.length,
        firstEpisode: episodes[0]
      }))
    };
    
    // Cache result
    caches.search.set(cacheKey, result);
    
    res.json(result);
  });
  
  // GET /api/stats - Return statistics about the media library
  app.get('/api/stats', (req, res) => {
    const cacheKey = 'stats';
    
    // Check cache
    const cachedResult = caches.stats.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }
    
    // Count unique series
    const uniqueSeries = [...new Set(db.series.map(episode => episode.show))];
    
    // Count by video format
    const movieFormats = {};
    db.movies.forEach(movie => {
      const ext = movie.path.split('.').pop().toLowerCase();
      movieFormats[ext] = (movieFormats[ext] || 0) + 1;
    });
    
    const episodeFormats = {};
    db.series.forEach(episode => {
      const ext = episode.path.split('.').pop().toLowerCase();
      episodeFormats[ext] = (episodeFormats[ext] || 0) + 1;
    });
    
    const result = {
      lastScan: db.lastScan,
      totalMovies: db.movies.length,
      totalSeries: uniqueSeries.length,
      totalEpisodes: db.series.length,
      stats: {
        moviesWithSubtitles: db.movies.filter(m => m.embeddedSubtitles || m.externalSubtitles.length > 0).length,
        episodesWithSubtitles: db.series.filter(e => e.embeddedSubtitles || e.externalSubtitles.length > 0).length,
        moviesWithMultipleAudio: db.movies.filter(m => m.audioTracks.length > 1).length,
        episodesWithMultipleAudio: db.series.filter(e => e.audioTracks.length > 1).length
      },
      formats: {
        movies: movieFormats,
        episodes: episodeFormats
      }
    };
    
    // Cache result
    caches.stats.set(cacheKey, result);
    
    res.json(result);
  });
  
  // POST /api/scan - Trigger a new scan
  app.post('/api/scan', async (req, res) => {
    try {
      // Clear caches
      Object.values(caches).forEach(cache => cache.clear());
      
      // Start scan in background
      res.json({ message: 'Scan started' });
      
      // Perform scan
      await scanMediaLibrary(db);
    } catch (error) {
      console.error('Error during scan:', error);
    }
  });
  
  // GET /api/health - Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      uptime: process.uptime(),
      timestamp: Date.now()
    });
  });
  
  // GET /api/cache/stats - Get cache statistics
  app.get('/api/cache/stats', (req, res) => {
    const stats = {};
    
    for (const [name, cache] of Object.entries(caches)) {
      stats[name] = {
        size: cache.size(),
        ttl: cache.ttl
      };
    }
    
    res.json(stats);
  });
  
  // POST /api/cache/clear - Clear all caches
  app.post('/api/cache/clear', (req, res) => {
    Object.values(caches).forEach(cache => cache.clear());
    res.json({ message: 'All caches cleared' });
  });
}