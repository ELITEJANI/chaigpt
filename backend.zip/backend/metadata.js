import fetch from 'node-fetch';

// API keys
const TMDB_API_KEY = process.env.TMDB_API_KEY;
const OMDB_API_KEY = process.env.OMDB_API_KEY;

// TMDb API base URL
const TMDB_API_URL = 'https://api.themoviedb.org/3';

// OMDb API base URL
const OMDB_API_URL = 'http://www.omdbapi.com';

// Function to search for a movie on TMDb
async function searchMovieOnTMDb(title, year) {
  try {
    const query = encodeURIComponent(title);
    const yearParam = year ? `&year=${year}` : '';
    const url = `${TMDB_API_URL}/search/movie?api_key=${TMDB_API_KEY}&query=${query}${yearParam}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.results && data.results.length > 0) {
      return data.results[0];
    }
    
    return null;
  } catch (error) {
    console.error(`Error searching for movie on TMDb: ${title}`, error);
    return null;
  }
}

// Function to get movie details from TMDb
async function getMovieDetailsFromTMDb(tmdbId) {
  try {
    const url = `${TMDB_API_URL}/movie/${tmdbId}?api_key=${TMDB_API_KEY}&append_to_response=credits,images,videos`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    return data;
  } catch (error) {
    console.error(`Error getting movie details from TMDb: ${tmdbId}`, error);
    return null;
  }
}

// Function to search for a TV show on TMDb
async function searchTVShowOnTMDb(title) {
  try {
    const query = encodeURIComponent(title);
    const url = `${TMDB_API_URL}/search/tv?api_key=${TMDB_API_KEY}&query=${query}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.results && data.results.length > 0) {
      return data.results[0];
    }
    
    return null;
  } catch (error) {
    console.error(`Error searching for TV show on TMDb: ${title}`, error);
    return null;
  }
}

// Function to get TV show details from TMDb
async function getTVShowDetailsFromTMDb(tmdbId, season, episode) {
  try {
    // Get show details
    const showUrl = `${TMDB_API_URL}/tv/${tmdbId}?api_key=${TMDB_API_KEY}`;
    const showResponse = await fetch(showUrl);
    const showData = await showResponse.json();
    
    // Get season details
    const seasonUrl = `${TMDB_API_URL}/tv/${tmdbId}/season/${season}?api_key=${TMDB_API_KEY}`;
    const seasonResponse = await fetch(seasonUrl);
    const seasonData = await seasonResponse.json();
    
    // Get episode details
    const episodeUrl = `${TMDB_API_URL}/tv/${tmdbId}/season/${season}/episode/${episode}?api_key=${TMDB_API_KEY}`;
    const episodeResponse = await fetch(episodeUrl);
    const episodeData = await episodeResponse.json();
    
    return {
      show: showData,
      season: seasonData,
      episode: episodeData
    };
  } catch (error) {
    console.error(`Error getting TV show details from TMDb: ${tmdbId}`, error);
    return null;
  }
}

// Function to get movie details from OMDb
async function getMovieDetailsFromOMDb(title, year, imdbId) {
  try {
    let url;
    
    if (imdbId) {
      url = `${OMDB_API_URL}/?apikey=${OMDB_API_KEY}&i=${imdbId}`;
    } else {
      const query = encodeURIComponent(title);
      const yearParam = year ? `&y=${year}` : '';
      url = `${OMDB_API_URL}/?apikey=${OMDB_API_KEY}&t=${query}${yearParam}`;
    }
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.Response === 'True') {
      return data;
    }
    
    return null;
  } catch (error) {
    console.error(`Error getting movie details from OMDb: ${title}`, error);
    return null;
  }
}

// Function to get TV show details from OMDb
async function getTVShowDetailsFromOMDb(title, season, episode) {
  try {
    const query = encodeURIComponent(title);
    const url = `${OMDB_API_URL}/?apikey=${OMDB_API_KEY}&t=${query}&Season=${season}&Episode=${episode}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.Response === 'True') {
      return data;
    }
    
    return null;
  } catch (error) {
    console.error(`Error getting TV show details from OMDb: ${title}`, error);
    return null;
  }
}

// Function to fetch movie metadata from TMDb and OMDb
export async function fetchMovieMetadata(title, year) {
  console.log(`Fetching metadata for movie: ${title} (${year || 'unknown year'})`);
  
  try {
    // Search for movie on TMDb
    const tmdbMovie = await searchMovieOnTMDb(title, year);
    
    if (!tmdbMovie) {
      console.log(`Movie not found on TMDb: ${title}`);
      
      // Try OMDb as fallback
      const omdbMovie = await getMovieDetailsFromOMDb(title, year);
      
      if (!omdbMovie) {
        console.log(`Movie not found on OMDb: ${title}`);
        return null;
      }
      
      return {
        title: omdbMovie.Title,
        year: omdbMovie.Year ? parseInt(omdbMovie.Year) : null,
        imdbId: omdbMovie.imdbID,
        plot: omdbMovie.Plot,
        genres: omdbMovie.Genre ? omdbMovie.Genre.split(', ') : [],
        director: omdbMovie.Director,
        actors: omdbMovie.Actors ? omdbMovie.Actors.split(', ') : [],
        rating: omdbMovie.imdbRating ? parseFloat(omdbMovie.imdbRating) : null,
        poster: omdbMovie.Poster !== 'N/A' ? omdbMovie.Poster : null,
        runtime: omdbMovie.Runtime ? parseInt(omdbMovie.Runtime) : null,
        source: 'omdb'
      };
    }
    
    // Get more details from TMDb
    const tmdbDetails = await getMovieDetailsFromTMDb(tmdbMovie.id);
    
    // Get details from OMDb using IMDb ID
    let omdbDetails = null;
    if (tmdbDetails && tmdbDetails.imdb_id) {
      omdbDetails = await getMovieDetailsFromOMDb(null, null, tmdbDetails.imdb_id);
    }
    
    // Combine data from both sources
    const metadata = {
      title: tmdbDetails?.title || tmdbMovie.title,
      originalTitle: tmdbDetails?.original_title,
      year: tmdbDetails?.release_date ? parseInt(tmdbDetails.release_date.substring(0, 4)) : null,
      tmdbId: tmdbMovie.id,
      imdbId: tmdbDetails?.imdb_id,
      plot: tmdbDetails?.overview,
      tagline: tmdbDetails?.tagline,
      genres: tmdbDetails?.genres?.map(g => g.name) || [],
      director: omdbDetails?.Director,
      actors: tmdbDetails?.credits?.cast?.slice(0, 10).map(actor => ({
        name: actor.name,
        character: actor.character,
        profilePath: actor.profile_path
      })) || [],
      crew: tmdbDetails?.credits?.crew?.filter(person => 
        person.job === 'Director' || person.job === 'Producer' || person.job === 'Writer'
      ).map(person => ({
        name: person.name,
        job: person.job
      })) || [],
      rating: tmdbDetails?.vote_average,
      imdbRating: omdbDetails?.imdbRating ? parseFloat(omdbDetails.imdbRating) : null,
      poster: tmdbDetails?.poster_path ? `https://image.tmdb.org/t/p/w500${tmdbDetails.poster_path}` : null,
      backdrop: tmdbDetails?.backdrop_path ? `https://image.tmdb.org/t/p/original${tmdbDetails.backdrop_path}` : null,
      runtime: tmdbDetails?.runtime,
      budget: tmdbDetails?.budget,
      revenue: tmdbDetails?.revenue,
      productionCompanies: tmdbDetails?.production_companies?.map(company => company.name) || [],
      videos: tmdbDetails?.videos?.results?.filter(video => 
        video.site === 'YouTube' && (video.type === 'Trailer' || video.type === 'Teaser')
      ).map(video => ({
        name: video.name,
        key: video.key,
        type: video.type,
        site: video.site
      })) || [],
      source: 'tmdb+omdb'
    };
    
    return metadata;
  } catch (error) {
    console.error(`Error fetching movie metadata: ${title}`, error);
    return null;
  }
}

// Function to fetch series metadata from TMDb and OMDb
export async function fetchSeriesMetadata(title, season, episode) {
  console.log(`Fetching metadata for series: ${title} S${season}E${episode}`);
  
  try {
    // Search for TV show on TMDb
    const tmdbShow = await searchTVShowOnTMDb(title);
    
    if (!tmdbShow) {
      console.log(`TV show not found on TMDb: ${title}`);
      
      // Try OMDb as fallback
      const omdbShow = await getTVShowDetailsFromOMDb(title, season, episode);
      
      if (!omdbShow) {
        console.log(`TV show not found on OMDb: ${title}`);
        return null;
      }
      
      return {
        showTitle: omdbShow.Title,
        episodeTitle: omdbShow.Title,
        season: season,
        episode: episode,
        plot: omdbShow.Plot,
        imdbId: omdbShow.imdbID,
        rating: omdbShow.imdbRating ? parseFloat(omdbShow.imdbRating) : null,
        poster: omdbShow.Poster !== 'N/A' ? omdbShow.Poster : null,
        source: 'omdb'
      };
    }
    
    // Get more details from TMDb
    const tmdbDetails = await getTVShowDetailsFromTMDb(tmdbShow.id, season, episode);
    
    if (!tmdbDetails || !tmdbDetails.episode) {
      console.log(`Episode not found on TMDb: ${title} S${season}E${episode}`);
      return null;
    }
    
    // Combine data
    const metadata = {
      showTitle: tmdbShow.name,
      showOriginalTitle: tmdbShow.original_name,
      episodeTitle: tmdbDetails.episode.name,
      season: season,
      episode: episode,
      tmdbId: tmdbShow.id,
      episodeTmdbId: tmdbDetails.episode.id,
      plot: tmdbDetails.episode.overview,
      showPlot: tmdbDetails.show.overview,
      genres: tmdbDetails.show.genres?.map(g => g.name) || [],
      rating: tmdbDetails.episode.vote_average,
      showRating: tmdbDetails.show.vote_average,
      airDate: tmdbDetails.episode.air_date,
      poster: tmdbDetails.show.poster_path ? `https://image.tmdb.org/t/p/w500${tmdbDetails.show.poster_path}` : null,
      episodeStill: tmdbDetails.episode.still_path ? `https://image.tmdb.org/t/p/original${tmdbDetails.episode.still_path}` : null,
      backdrop: tmdbDetails.show.backdrop_path ? `https://image.tmdb.org/t/p/original${tmdbDetails.show.backdrop_path}` : null,
      episodeRuntime: tmdbDetails.show.episode_run_time?.[0],
      networks: tmdbDetails.show.networks?.map(network => network.name) || [],
      source: 'tmdb'
    };
    
    return metadata;
  } catch (error) {
    console.error(`Error fetching series metadata: ${title}`, error);
    return null;
  }
}