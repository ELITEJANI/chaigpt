import express from 'express';
import cors from 'cors';
import { scanMediaLibrary } from './scanner.js';
import { setupRoutes } from './routes.js';
import { loadDatabase } from './database.js';
import { startFileWatcher } from './watcher.js';
import { checkFfmpeg } from './analyzer.js';
import config from './config.js';

const app = express();

// Middleware
if (config.api.cors) {
  app.use(cors());
}
app.use(express.json());

// Initialize database
const db = loadDatabase();

// Welcome route
app.get('/', (req, res) => {
  res.json({ 
    message: 'Welcome to Media Library API',
    version: '1.0.0',
    endpoints: [
      '/api/movies',
      '/api/series',
      '/api/media/:title',
      '/api/stats',
      '/api/health',
      '/api/scan'
    ]
  });
});

// Setup API routes
setupRoutes(app, db);

// Start server
app.listen(config.api.port, async () => {
  console.log(`Server running on port ${config.api.port}`);
  
  // Check if FFmpeg is installed
  const ffmpegInstalled = await checkFfmpeg();
  if (!ffmpegInstalled) {
    console.error('WARNING: FFmpeg is not installed or not in PATH. Video analysis will not work properly.');
  }
  
  // Start scanning media library
  console.log('Starting media library scan...');
  try {
    await scanMediaLibrary(db);
    console.log('Media library scan completed');
    
    // Start file watcher after initial scan
    startFileWatcher(db);
  } catch (error) {
    console.error('Error scanning media library:', error);
  }
});

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down server...');
  process.exit(0);
});