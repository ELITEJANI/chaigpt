import fs from 'fs-extra';
import path from 'path';
import config from './config.js';

// Function to load database from file
export function loadDatabase() {
  const dbPath = config.database.path;
  
  try {
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      // Read database file
      const data = fs.readFileSync(dbPath, 'utf8');
      const db = JSON.parse(data);
      
      console.log(`Loaded database with ${db.movies.length} movies and ${db.series.length} episodes`);
      
      return db;
    }
  } catch (error) {
    console.error('Error loading database:', error);
    
    // Try to load backup if available
    try {
      if (fs.existsSync(config.database.backupPath)) {
        const backupData = fs.readFileSync(config.database.backupPath, 'utf8');
        const backupDb = JSON.parse(backupData);
        
        console.log(`Loaded database backup with ${backupDb.movies.length} movies and ${backupDb.series.length} episodes`);
        
        return backupDb;
      }
    } catch (backupError) {
      console.error('Error loading database backup:', backupError);
    }
  }
  
  // Create new database if none exists
  console.log('Creating new database');
  
  return {
    movies: [],
    series: [],
    lastScan: null
  };
}

// Function to save database to file
export async function saveDatabase(db) {
  const dbPath = config.database.path;
  
  try {
    // Create backup of existing database if it exists
    if (await fs.pathExists(dbPath)) {
      await fs.copy(dbPath, config.database.backupPath);
    }
    
    // Save database to file
    await fs.writeFile(dbPath, JSON.stringify(db, null, 2));
    
    console.log(`Saved database with ${db.movies.length} movies and ${db.series.length} episodes`);
    
    return true;
  } catch (error) {
    console.error('Error saving database:', error);
    return false;
  }
}