import { ProfileSelector } from "@/components/profile-selector"

export default function Profiles() {
  return (
    <div className="container mx-auto flex flex-col items-center justify-center min-h-[80vh]">
      <h1 className="text-3xl font-bold mb-10">Who's Watching?</h1>
      <ProfileSelector />
    </div>
  )
}
