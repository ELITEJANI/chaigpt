import { SeriesDetails } from "@/components/series-details"

export default function SeriesPage({ params }: { params: { id: string } }) {
  return <SeriesDetails id={params.id} />
}
