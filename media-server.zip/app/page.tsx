import { HomeHero } from "@/components/home-hero"
import { ContinueWatching } from "@/components/continue-watching"
import { ContentRow } from "@/components/content-row"

export default function Home() {
  return (
    <div className="flex flex-col gap-8">
      <HomeHero />
      <ContinueWatching />
      <ContentRow title="New Movies" type="movie" />
      <ContentRow title="Trending Shows" type="series" />
      <ContentRow title="Recommended For You" type="mixed" />
    </div>
  )
}
