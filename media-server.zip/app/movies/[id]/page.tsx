import { MovieDetails } from "@/components/movie-details"

export default function MoviePage({ params }: { params: { id: string } }) {
  return <MovieDetails id={params.id} />
}
