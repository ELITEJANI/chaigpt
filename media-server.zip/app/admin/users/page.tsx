import { UserList } from "@/components/user-list"
import { AddUserButton } from "@/components/add-user-button"

export default function Users() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">User Profiles</h1>
        <AddUserButton />
      </div>
      <UserList />
    </div>
  )
}
