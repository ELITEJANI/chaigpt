import { SettingsForm } from "@/components/settings-form"

export default function Settings() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Server Settings</h1>
      <SettingsForm />
    </div>
  )
}
