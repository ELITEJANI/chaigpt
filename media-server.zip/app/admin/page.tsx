import { DashboardStats } from "@/components/dashboard-stats"
import { ServerStatus } from "@/components/server-status"
import { RecentActivity } from "@/components/recent-activity"
import { QuickActions } from "@/components/quick-actions"

export default function AdminDashboard() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <DashboardStats />
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <ServerStatus />
        <RecentActivity />
      </div>
      <QuickActions />
    </div>
  )
}
