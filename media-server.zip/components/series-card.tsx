"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Play } from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"
import Image from "next/image"

interface SeriesCardProps {
  id: string
  title: string
  year: string
  poster: string
  seasons: number
}

export function SeriesCard({ id, title, year, poster, seasons }: SeriesCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Link href={`/series/${id}`}>
      <motion.div
        className="relative"
        initial={{ scale: 1 }}
        whileHover={{
          scale: 1.05,
          transition: { duration: 0.2 },
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <Card className="overflow-hidden border-0 bg-transparent">
          <CardContent className="relative p-0">
            <div className="aspect-[2/3] overflow-hidden rounded-lg">
              <Image
                src={poster || "/placeholder.svg?height=450&width=300"}
                alt={title}
                width={300}
                height={450}
                className="h-full w-full object-cover transition-transform duration-300 ease-in-out"
                style={{
                  transform: isHovered ? "scale(1.05)" : "scale(1)",
                }}
              />
            </div>
            {isHovered && (
              <motion.div
                className="absolute inset-0 flex items-center justify-center bg-black/60"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex flex-col items-center gap-2">
                  <div className="rounded-full bg-primary p-3">
                    <Play className="h-6 w-6 fill-primary-foreground text-primary-foreground" />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-white">{title}</h3>
                    <p className="text-sm text-white/80">
                      {year} • {seasons} {seasons === 1 ? "Season" : "Seasons"}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </Link>
  )
}
