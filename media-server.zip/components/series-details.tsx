"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Film, Heart, Info, Play, Star } from "lucide-react"
import Image from "next/image"
import { motion } from "framer-motion"

interface SeriesDetailsProps {
  id: string
}

export function SeriesDetails({ id }: SeriesDetailsProps) {
  const [selectedSeason, setSelectedSeason] = useState("1")

  // This would be fetched from an API in a real application
  const series = {
    id,
    title: "Stranger Things",
    year: "2016",
    rating: "TV-14",
    genres: ["Drama", "Fantasy", "Horror"],
    creators: ["The Duffer Brothers"],
    cast: ["Millie Bobby Brown", "Finn Wolfhard", "Winona Ryder"],
    plot: "When a young boy disappears, his mother, a police chief and his friends must confront terrifying supernatural forces in order to get him back.",
    imdbRating: "8.7",
    poster: "/placeholder.svg?height=450&width=300",
    backdrop: "/placeholder.svg?height=1080&width=1920",
    seasons: [
      {
        number: "1",
        year: "2016",
        episodes: [
          { number: "1", title: "Chapter One: The Vanishing of Will Byers", runtime: "47m" },
          { number: "2", title: "Chapter Two: The Weirdo on Maple Street", runtime: "55m" },
          { number: "3", title: "Chapter Three: Holly, Jolly", runtime: "51m" },
          { number: "4", title: "Chapter Four: The Body", runtime: "49m" },
          { number: "5", title: "Chapter Five: The Flea and the Acrobat", runtime: "52m" },
          { number: "6", title: "Chapter Six: The Monster", runtime: "46m" },
          { number: "7", title: "Chapter Seven: The Bathtub", runtime: "41m" },
          { number: "8", title: "Chapter Eight: The Upside Down", runtime: "54m" },
        ],
      },
      {
        number: "2",
        year: "2017",
        episodes: [
          { number: "1", title: "Chapter One: MADMAX", runtime: "48m" },
          { number: "2", title: "Chapter Two: Trick or Treat, Freak", runtime: "56m" },
          { number: "3", title: "Chapter Three: The Pollywog", runtime: "51m" },
          { number: "4", title: "Chapter Four: Will the Wise", runtime: "46m" },
          { number: "5", title: "Chapter Five: Dig Dug", runtime: "58m" },
          { number: "6", title: "Chapter Six: The Spy", runtime: "52m" },
          { number: "7", title: "Chapter Seven: The Lost Sister", runtime: "45m" },
          { number: "8", title: "Chapter Eight: The Mind Flayer", runtime: "47m" },
          { number: "9", title: "Chapter Nine: The Gate", runtime: "62m" },
        ],
      },
    ],
  }

  const currentSeason = series.seasons.find((s) => s.number === selectedSeason)

  return (
    <div className="relative -mx-4 -mt-4 md:-mx-6 md:-mt-6">
      <div className="absolute inset-0">
        <Image src={series.backdrop || "/placeholder.svg"} alt={series.title} fill className="object-cover" priority />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-background/40" />
      </div>
      <div className="relative z-10 flex min-h-[90vh] flex-col p-6 md:p-12">
        <div className="grid gap-6 md:grid-cols-[300px_1fr] lg:grid-cols-[350px_1fr]">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="overflow-hidden rounded-lg">
              <Image
                src={series.poster || "/placeholder.svg"}
                alt={series.title}
                width={350}
                height={525}
                className="h-auto w-full"
              />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <h1 className="mb-2 text-4xl font-bold tracking-tight md:text-5xl">{series.title}</h1>
            <div className="mb-4 flex flex-wrap items-center gap-2 text-muted-foreground">
              <span>{series.year}</span>
              <span>•</span>
              <span>{series.rating}</span>
              <span>•</span>
              <div className="flex items-center">
                <Star className="mr-1 h-4 w-4 fill-yellow-500 text-yellow-500" />
                <span>{series.imdbRating}</span>
              </div>
            </div>
            <div className="mb-6 flex flex-wrap gap-2">
              {series.genres.map((genre) => (
                <Badge key={genre} variant="secondary">
                  {genre}
                </Badge>
              ))}
            </div>
            <p className="mb-6 max-w-2xl text-lg">{series.plot}</p>
            <div className="mb-8 grid gap-4 md:grid-cols-2">
              <div>
                <h3 className="font-semibold">Creators</h3>
                <p className="text-muted-foreground">{series.creators.join(", ")}</p>
              </div>
              <div>
                <h3 className="font-semibold">Cast</h3>
                <p className="text-muted-foreground">{series.cast.join(", ")}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="gap-2">
                <Play className="h-5 w-5" /> Play
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Film className="h-5 w-5" /> Trailer
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Heart className="h-5 w-5" /> Add to Favorites
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Info className="h-5 w-5" /> More Info
              </Button>
            </div>
          </motion.div>
        </div>

        <div className="mt-12">
          <Tabs defaultValue="1" value={selectedSeason} onValueChange={setSelectedSeason}>
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">Episodes</h2>
              <TabsList>
                {series.seasons.map((season) => (
                  <TabsTrigger key={season.number} value={season.number}>
                    Season {season.number}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>
            {series.seasons.map((season) => (
              <TabsContent key={season.number} value={season.number} className="mt-6">
                <ScrollArea className="pb-4">
                  <div className="flex flex-col gap-4">
                    {season.episodes.map((episode) => (
                      <Card key={episode.number} className="overflow-hidden">
                        <CardContent className="flex p-0">
                          <div className="relative h-24 w-40 shrink-0">
                            <Image
                              src="/placeholder.svg?height=96&width=160"
                              alt={`${series.title} S${season.number}E${episode.number}`}
                              fill
                              className="object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 transition-opacity hover:opacity-100">
                              <Play className="h-8 w-8" />
                            </div>
                          </div>
                          <div className="flex flex-1 flex-col justify-center p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="font-medium">
                                  S{season.number}E{episode.number}
                                </span>
                                <span className="text-muted-foreground">•</span>
                                <span className="text-muted-foreground">{episode.runtime}</span>
                              </div>
                              <Button variant="ghost" size="icon">
                                <Info className="h-4 w-4" />
                              </Button>
                            </div>
                            <h3 className="font-medium">{episode.title}</h3>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </div>
  )
}
