"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Film, HardDrive, Users, Clock } from "lucide-react"

export function DashboardStats() {
  const stats = [
    {
      title: "Total Movies",
      value: "1,248",
      icon: Film,
      description: "+12 added today",
      trend: "up",
    },
    {
      title: "Total TV Shows",
      value: "342",
      icon: Clock,
      description: "+3 added today",
      trend: "up",
    },
    {
      title: "Storage Used",
      value: "4.2 TB",
      icon: HardDrive,
      description: "8.1 TB available",
      trend: "neutral",
    },
    {
      title: "Active Users",
      value: "6",
      icon: Users,
      description: "2 streaming now",
      trend: "neutral",
    },
  ]

  return (
    <>
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <stat.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <p className="text-xs text-muted-foreground">{stat.description}</p>
          </CardContent>
        </Card>
      ))}
    </>
  )
}
