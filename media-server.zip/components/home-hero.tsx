"use client"

import { Button } from "@/components/ui/button"
import { Info, Play } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"

export function HomeHero() {
  return (
    <div className="relative -mx-4 -mt-4 h-[70vh] md:-mx-6 md:-mt-6">
      <div className="absolute inset-0">
        <Image
          src="/placeholder.svg?height=1080&width=1920"
          alt="Featured movie backdrop"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/10" />
        <div className="absolute inset-0 bg-gradient-to-r from-background to-transparent" />
      </div>
      <div className="relative z-10 flex h-full flex-col justify-end p-6 md:p-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl"
        >
          <h1 className="mb-2 text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">Interstellar</h1>
          <p className="mb-4 max-w-md text-lg text-muted-foreground md:text-xl">
            A team of explorers travel through a wormhole in space in an attempt to ensure humanity&apos;s survival.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" asChild>
              <Link href="/movies/interstellar">
                <Play className="mr-2 h-5 w-5" /> Play
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/movies/interstellar">
                <Info className="mr-2 h-5 w-5" /> More Info
              </Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
