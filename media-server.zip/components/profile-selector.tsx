"use client"

import { Button } from "@/components/ui/button"
import { ProfileCard } from "@/components/profile-card"
import { motion } from "framer-motion"

export function ProfileSelector() {
  const profiles = [
    {
      id: "1",
      name: "John",
      avatar: "/placeholder.svg?height=96&width=96",
    },
    {
      id: "2",
      name: "Jane",
      avatar: "/placeholder.svg?height=96&width=96",
    },
    {
      id: "3",
      name: "Kids",
      avatar: "/placeholder.svg?height=96&width=96",
      isKid: true,
    },
    {
      id: "4",
      name: "Guest",
      avatar: "/placeholder.svg?height=96&width=96",
    },
  ]

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
        {profiles.map((profile) => (
          <ProfileCard key={profile.id} {...profile} />
        ))}
      </div>
      <div className="mt-12 flex justify-center">
        <Button variant="outline">Manage Profiles</Button>
      </div>
    </motion.div>
  )
}
