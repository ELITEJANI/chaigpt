"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus } from "lucide-react"

export function AddLibraryButton() {
  const [open, setOpen] = useState(false)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Library
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add Media Library</DialogTitle>
          <DialogDescription>Create a new library to organize your media content.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Library Name</Label>
            <Input id="name" placeholder="Movies, TV Shows, etc." />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="type">Library Type</Label>
            <Select>
              <SelectTrigger id="type">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="movies">Movies</SelectItem>
                <SelectItem value="tvshows">TV Shows</SelectItem>
                <SelectItem value="music">Music</SelectItem>
                <SelectItem value="photos">Photos</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="path">Folder Path</Label>
            <div className="flex gap-2">
              <Input id="path" placeholder="/media/movies" className="flex-1" />
              <Button variant="outline">Browse</Button>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={() => setOpen(false)}>Add Library</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
