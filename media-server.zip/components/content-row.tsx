"use client"

import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { MovieCard } from "@/components/movie-card"
import { SeriesCard } from "@/components/series-card"

interface ContentRowProps {
  title: string
  type: "movie" | "series" | "mixed"
}

export function ContentRow({ title, type }: ContentRowProps) {
  const movies = [
    {
      id: "1",
      title: "Inception",
      year: "2010",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "PG-13",
    },
    {
      id: "2",
      title: "The Dark Knight",
      year: "2008",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "PG-13",
    },
    {
      id: "3",
      title: "Interstellar",
      year: "2014",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "PG-13",
    },
    {
      id: "4",
      title: "Dune",
      year: "2021",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "PG-13",
    },
    {
      id: "5",
      title: "The Matrix",
      year: "1999",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "R",
    },
    {
      id: "6",
      title: "Blade Runner 2049",
      year: "2017",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "R",
    },
    {
      id: "7",
      title: "Avatar",
      year: "2009",
      poster: "/placeholder.svg?height=450&width=300",
      rating: "PG-13",
    },
  ]

  const series = [
    {
      id: "1",
      title: "Stranger Things",
      year: "2016",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 4,
    },
    {
      id: "2",
      title: "Breaking Bad",
      year: "2008",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 5,
    },
    {
      id: "3",
      title: "Game of Thrones",
      year: "2011",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 8,
    },
    {
      id: "4",
      title: "The Witcher",
      year: "2019",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 2,
    },
    {
      id: "5",
      title: "The Mandalorian",
      year: "2019",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 3,
    },
    {
      id: "6",
      title: "Loki",
      year: "2021",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 2,
    },
    {
      id: "7",
      title: "The Last of Us",
      year: "2023",
      poster: "/placeholder.svg?height=450&width=300",
      seasons: 1,
    },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold tracking-tight">{title}</h2>
      </div>
      <ScrollArea className="pb-4">
        <div className="flex gap-4">
          {type === "movie" && movies.map((movie) => <MovieCard key={movie.id} {...movie} />)}
          {type === "series" && series.map((series) => <SeriesCard key={series.id} {...series} />)}
          {type === "mixed" && (
            <>
              {movies.slice(0, 4).map((movie) => (
                <MovieCard key={movie.id} {...movie} />
              ))}
              {series.slice(0, 3).map((series) => (
                <SeriesCard key={series.id} {...series} />
              ))}
            </>
          )}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
