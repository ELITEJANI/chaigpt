import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Edit, Trash2 } from "lucide-react"
import { Switch } from "@/components/ui/switch"

export function UserList() {
  const users = [
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JD",
      role: "admin",
      lastActive: "2 hours ago",
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JS",
      role: "user",
      lastActive: "5 minutes ago",
    },
    {
      id: "3",
      name: "Kids",
      email: "",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "K",
      role: "restricted",
      lastActive: "1 day ago",
    },
    {
      id: "4",
      name: "Guest",
      email: "guest@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "G",
      role: "guest",
      lastActive: "1 week ago",
    },
  ]

  return (
    <div className="grid gap-4">
      {users.map((user) => (
        <Card key={user.id}>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                  <AvatarFallback>{user.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg">{user.name}</CardTitle>
                  <CardDescription>{user.email}</CardDescription>
                </div>
              </div>
              <Badge variant={user.role === "admin" ? "default" : user.role === "restricted" ? "secondary" : "outline"}>
                {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between text-sm">
              <span>Last active: {user.lastActive}</span>
              <div className="flex items-center gap-2">
                <span>Admin Access</span>
                <Switch checked={user.role === "admin"} />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-2 border-t bg-muted/50 px-6 py-3">
            <Button variant="ghost" size="sm">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
