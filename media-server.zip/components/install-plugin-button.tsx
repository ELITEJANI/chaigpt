"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Download, Plus } from "lucide-react"

export function InstallPluginButton() {
  const [open, setOpen] = useState(false)

  const featuredPlugins = [
    {
      id: "1",
      name: "Plex Import",
      description: "Import your Plex libraries and watched status.",
      author: "MediaHub",
      downloads: "10.5k",
      rating: 4.8,
    },
    {
      id: "2",
      name: "IMDb Ratings",
      description: "Display IMDb ratings for your media.",
      author: "Community",
      downloads: "8.2k",
      rating: 4.6,
    },
    {
      id: "3",
      name: "Auto Backup",
      description: "Automatically backup your database on a schedule.",
      author: "MediaHub",
      downloads: "5.7k",
      rating: 4.9,
    },
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Install Plugin
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Install Plugin</DialogTitle>
          <DialogDescription>Browse and install plugins to extend your media server functionality.</DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="browse">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="browse">Browse</TabsTrigger>
            <TabsTrigger value="upload">Upload</TabsTrigger>
          </TabsList>
          <TabsContent value="browse" className="space-y-4 py-4">
            <div className="flex items-center space-x-2">
              <Input placeholder="Search plugins..." />
              <Button variant="secondary">Search</Button>
            </div>
            <div className="grid gap-4">
              {featuredPlugins.map((plugin) => (
                <Card key={plugin.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle>{plugin.name}</CardTitle>
                      <Badge variant="outline">{plugin.author}</Badge>
                    </div>
                    <CardDescription>{plugin.description}</CardDescription>
                  </CardHeader>
                  <CardFooter className="flex justify-between pt-2">
                    <div className="text-xs text-muted-foreground">
                      {plugin.downloads} downloads • {plugin.rating} stars
                    </div>
                    <Button size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Install
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="upload" className="space-y-4 py-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="plugin-file">Plugin File</Label>
                <Input id="plugin-file" type="file" />
              </div>
              <p className="text-sm text-muted-foreground">
                Upload a .zip file containing the plugin. Make sure it follows the MediaHub plugin structure.
              </p>
            </div>
          </TabsContent>
        </Tabs>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
