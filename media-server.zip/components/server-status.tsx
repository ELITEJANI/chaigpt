"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export function ServerStatus() {
  const resources = [
    { name: "CPU", usage: 32, limit: "4 cores" },
    { name: "Memory", usage: 45, limit: "16 GB" },
    { name: "Network", usage: 18, limit: "1 Gbps" },
    { name: "Transcoding", usage: 0, limit: "2 streams" },
  ]

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Server Status</CardTitle>
          <Badge variant="outline" className="bg-green-500/10 text-green-500">
            Online
          </Badge>
        </div>
        <CardDescription>Server has been running for 24 days, 5 hours</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {resources.map((resource) => (
            <div key={resource.name} className="grid gap-2">
              <div className="flex items-center justify-between text-sm">
                <div className="font-medium">{resource.name}</div>
                <div className="text-muted-foreground">
                  {resource.usage}% of {resource.limit}
                </div>
              </div>
              <Progress value={resource.usage} />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
