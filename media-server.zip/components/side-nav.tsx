"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Film, Home, Library, PlusCircle, Search, Settings, Tv, Users } from "lucide-react"

export function SideNav() {
  const pathname = usePathname()
  const isAdmin = pathname.startsWith("/admin")

  if (!isAdmin && pathname === "/profiles") {
    return null
  }

  return (
    <div className="hidden border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 md:block">
      <div className="flex h-full flex-col gap-2 p-4">
        {isAdmin ? (
          <>
            <Button asChild variant={pathname === "/admin" ? "secondary" : "ghost"} size="sm" className="justify-start">
              <Link href="/admin" className="flex items-center">
                <Home className="mr-2 h-4 w-4" />
                Dashboard
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/admin/libraries" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/admin/libraries" className="flex items-center">
                <Library className="mr-2 h-4 w-4" />
                Libraries
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/admin/plugins" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/admin/plugins" className="flex items-center">
                <PlusCircle className="mr-2 h-4 w-4" />
                Plugins
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/admin/users" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/admin/users" className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                Users
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/admin/settings" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/admin/settings" className="flex items-center">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Link>
            </Button>
          </>
        ) : (
          <>
            <Button asChild variant={pathname === "/" ? "secondary" : "ghost"} size="sm" className="justify-start">
              <Link href="/" className="flex items-center">
                <Home className="mr-2 h-4 w-4" />
                Home
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/movies" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/movies" className="flex items-center">
                <Film className="mr-2 h-4 w-4" />
                Movies
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/series" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/series" className="flex items-center">
                <Tv className="mr-2 h-4 w-4" />
                TV Shows
              </Link>
            </Button>
            <Button
              asChild
              variant={pathname === "/search" ? "secondary" : "ghost"}
              size="sm"
              className="justify-start"
            >
              <Link href="/search" className="flex items-center">
                <Search className="mr-2 h-4 w-4" />
                Search
              </Link>
            </Button>
          </>
        )}
        <div className="mt-auto">
          {isAdmin ? (
            <Button asChild variant="outline" size="sm" className="justify-start">
              <Link href="/" className="flex items-center">
                <Film className="mr-2 h-4 w-4" />
                Exit Admin
              </Link>
            </Button>
          ) : (
            <Button asChild variant="outline" size="sm" className="justify-start">
              <Link href="/admin" className="flex items-center">
                <Settings className="mr-2 h-4 w-4" />
                Admin Panel
              </Link>
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
