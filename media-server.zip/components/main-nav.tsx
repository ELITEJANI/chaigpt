"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Film, Home, Search, Settings, Tv } from "lucide-react"

export function MainNav() {
  const pathname = usePathname()
  const isAdmin = pathname.startsWith("/admin")

  return (
    <div className="mr-4 flex">
      <Link href="/" className="mr-6 flex items-center space-x-2">
        <Film className="h-6 w-6 text-primary" />
        <span className="hidden font-bold sm:inline-block">MediaHub</span>
      </Link>
      <nav className="flex items-center space-x-4 lg:space-x-6">
        {isAdmin ? (
          <>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/admin"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/admin" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Home className="mr-2 h-4 w-4" />
                Dashboard
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/admin/libraries"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/admin/libraries" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Film className="mr-2 h-4 w-4" />
                Libraries
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/admin/plugins"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/admin/plugins" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Settings className="mr-2 h-4 w-4" />
                Plugins
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/admin/users"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/admin/users" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Settings className="mr-2 h-4 w-4" />
                Users
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/admin/settings"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/admin/settings" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Link>
            </Button>
          </>
        ) : (
          <>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Home className="mr-2 h-4 w-4" />
                Home
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/movies"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/movies" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Film className="mr-2 h-4 w-4" />
                Movies
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/series"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/series" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Tv className="mr-2 h-4 w-4" />
                TV Shows
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link
                href="/search"
                className={cn(
                  "flex items-center text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/search" ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Search className="mr-2 h-4 w-4" />
                Search
              </Link>
            </Button>
          </>
        )}
      </nav>
    </div>
  )
}
