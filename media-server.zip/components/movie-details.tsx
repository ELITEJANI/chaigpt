"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Film, Heart, Info, Play, Star } from "lucide-react"
import Image from "next/image"
import { motion } from "framer-motion"

interface MovieDetailsProps {
  id: string
}

export function MovieDetails({ id }: MovieDetailsProps) {
  // This would be fetched from an API in a real application
  const movie = {
    id,
    title: "Interstellar",
    year: "2014",
    runtime: "2h 49m",
    rating: "PG-13",
    genres: ["Adventure", "Drama", "Sci-Fi"],
    director: "Christopher Nolan",
    cast: ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"],
    plot: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    imdbRating: "8.6",
    poster: "/placeholder.svg?height=450&width=300",
    backdrop: "/placeholder.svg?height=1080&width=1920",
  }

  return (
    <div className="relative -mx-4 -mt-4 md:-mx-6 md:-mt-6">
      <div className="absolute inset-0">
        <Image src={movie.backdrop || "/placeholder.svg"} alt={movie.title} fill className="object-cover" priority />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-background/40" />
      </div>
      <div className="relative z-10 flex min-h-[90vh] flex-col justify-center p-6 md:p-12">
        <div className="grid gap-6 md:grid-cols-[300px_1fr] lg:grid-cols-[350px_1fr]">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="overflow-hidden rounded-lg">
              <Image
                src={movie.poster || "/placeholder.svg"}
                alt={movie.title}
                width={350}
                height={525}
                className="h-auto w-full"
              />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <h1 className="mb-2 text-4xl font-bold tracking-tight md:text-5xl">{movie.title}</h1>
            <div className="mb-4 flex flex-wrap items-center gap-2 text-muted-foreground">
              <span>{movie.year}</span>
              <span>•</span>
              <span>{movie.rating}</span>
              <span>•</span>
              <span>{movie.runtime}</span>
              <span>•</span>
              <div className="flex items-center">
                <Star className="mr-1 h-4 w-4 fill-yellow-500 text-yellow-500" />
                <span>{movie.imdbRating}</span>
              </div>
            </div>
            <div className="mb-6 flex flex-wrap gap-2">
              {movie.genres.map((genre) => (
                <Badge key={genre} variant="secondary">
                  {genre}
                </Badge>
              ))}
            </div>
            <p className="mb-6 max-w-2xl text-lg">{movie.plot}</p>
            <div className="mb-8 grid gap-4 md:grid-cols-2">
              <div>
                <h3 className="font-semibold">Director</h3>
                <p className="text-muted-foreground">{movie.director}</p>
              </div>
              <div>
                <h3 className="font-semibold">Cast</h3>
                <p className="text-muted-foreground">{movie.cast.join(", ")}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="gap-2">
                <Play className="h-5 w-5" /> Play
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Film className="h-5 w-5" /> Trailer
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Heart className="h-5 w-5" /> Add to Favorites
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Info className="h-5 w-5" /> More Info
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
