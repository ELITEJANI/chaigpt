import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RefreshCw, Database, Download, Upload, Settings, Users } from "lucide-react"

export function QuickActions() {
  const actions = [
    {
      title: "Scan Libraries",
      description: "Update your media libraries",
      icon: RefreshCw,
    },
    {
      title: "Backup Database",
      description: "Create a backup of your server",
      icon: Database,
    },
    {
      title: "Check for Updates",
      description: "Update server software",
      icon: Download,
    },
    {
      title: "Export Settings",
      description: "Save your configuration",
      icon: Upload,
    },
    {
      title: "System Settings",
      description: "Configure server options",
      icon: Settings,
    },
    {
      title: "Manage Users",
      description: "Add or remove users",
      icon: Users,
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
        <CardDescription>Common server management tasks</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
          {actions.map((action, index) => (
            <Button key={index} variant="outline" className="h-auto flex-col items-start gap-2 p-4 text-left">
              <div className="flex w-full items-center gap-2">
                <action.icon className="h-4 w-4" />
                <span className="font-semibold">{action.title}</span>
              </div>
              <p className="text-xs text-muted-foreground">{action.description}</p>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
