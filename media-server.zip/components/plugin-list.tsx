import { PluginItem } from "@/components/plugin-item"

export function PluginList() {
  const plugins = [
    {
      id: "1",
      name: "Metadata Fetcher",
      description: "Automatically fetch metadata for your media from online sources.",
      version: "2.1.0",
      author: "MediaHub",
      isEnabled: true,
      isOfficial: true,
    },
    {
      id: "2",
      name: "Subtitle Downloader",
      description: "Download subtitles for your media from various sources.",
      version: "1.5.2",
      author: "MediaHub",
      isEnabled: true,
      isOfficial: true,
    },
    {
      id: "3",
      name: "Trakt Integration",
      description: "Sync your watched status with Trakt.tv.",
      version: "1.2.0",
      author: "Community",
      isEnabled: false,
      isOfficial: false,
    },
    {
      id: "4",
      name: "DLNA Server",
      description: "Share your media with DLNA-compatible devices on your network.",
      version: "3.0.1",
      author: "MediaHub",
      isEnabled: true,
      isOfficial: true,
    },
    {
      id: "5",
      name: "Auto Organizer",
      description: "Automatically organize your media files based on metadata.",
      version: "1.0.3",
      author: "Community",
      isEnabled: true,
      isOfficial: false,
    },
  ]

  return (
    <div className="grid gap-4">
      {plugins.map((plugin) => (
        <PluginItem key={plugin.id} {...plugin} />
      ))}
    </div>
  )
}
