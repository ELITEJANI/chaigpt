"use client"

import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Play } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { useState } from "react"

interface ContinueWatchingItemProps {
  id: string
  type: "movie" | "series"
  title: string
  poster: string
  progress: number
  episode?: string
  season?: string
}

function ContinueWatchingItem({ id, type, title, poster, progress, episode, season }: ContinueWatchingItemProps) {
  const [isHovered, setIsHovered] = useState(false)
  const href = type === "movie" ? `/movies/${id}` : `/series/${id}`

  return (
    <Link href={href}>
      <motion.div
        className="relative min-w-[200px] max-w-[200px]"
        initial={{ scale: 1 }}
        whileHover={{
          scale: 1.05,
          transition: { duration: 0.2 },
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <Card className="overflow-hidden border-0 bg-transparent">
          <CardContent className="relative p-0">
            <div className="aspect-video overflow-hidden rounded-lg">
              <Image
                src={poster || "/placeholder.svg?height=112&width=200"}
                alt={title}
                width={200}
                height={112}
                className="h-full w-full object-cover transition-transform duration-300 ease-in-out"
                style={{
                  transform: isHovered ? "scale(1.05)" : "scale(1)",
                }}
              />
            </div>
            {isHovered && (
              <motion.div
                className="absolute inset-0 flex items-center justify-center bg-black/60"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.2 }}
              >
                <div className="rounded-full bg-primary p-2">
                  <Play className="h-5 w-5 fill-primary-foreground text-primary-foreground" />
                </div>
              </motion.div>
            )}
            <div className="absolute bottom-0 left-0 right-0">
              <div className="h-1 w-full bg-muted">
                <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
              </div>
            </div>
          </CardContent>
        </Card>
        <div className="mt-2">
          <h3 className="font-medium">{title}</h3>
          {type === "series" && (
            <p className="text-xs text-muted-foreground">
              S{season} E{episode}
            </p>
          )}
        </div>
      </motion.div>
    </Link>
  )
}

export function ContinueWatching() {
  const items = [
    {
      id: "1",
      type: "movie" as const,
      title: "Inception",
      poster: "/placeholder.svg?height=112&width=200",
      progress: 45,
    },
    {
      id: "2",
      type: "series" as const,
      title: "Stranger Things",
      poster: "/placeholder.svg?height=112&width=200",
      progress: 80,
      season: "4",
      episode: "5",
    },
    {
      id: "3",
      type: "movie" as const,
      title: "The Matrix",
      poster: "/placeholder.svg?height=112&width=200",
      progress: 30,
    },
    {
      id: "4",
      type: "series" as const,
      title: "Breaking Bad",
      poster: "/placeholder.svg?height=112&width=200",
      progress: 60,
      season: "3",
      episode: "7",
    },
    {
      id: "5",
      type: "movie" as const,
      title: "Dune",
      poster: "/placeholder.svg?height=112&width=200",
      progress: 20,
    },
    {
      id: "6",
      type: "series" as const,
      title: "The Witcher",
      poster: "/placeholder.svg?height=112&width=200",
      progress: 90,
      season: "2",
      episode: "1",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold tracking-tight">Continue Watching</h2>
      </div>
      <ScrollArea className="pb-4">
        <div className="flex gap-4">
          {items.map((item) => (
            <ContinueWatchingItem key={item.id} {...item} />
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
