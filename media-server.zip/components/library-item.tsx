import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Edit, Folder, RefreshCw, Trash2 } from "lucide-react"

interface LibraryItemProps {
  id: string
  name: string
  path: string
  type: "movies" | "tvshows" | "music"
  itemCount: number
  lastScan: string
}

export function LibraryItem({ id, name, path, type, itemCount, lastScan }: LibraryItemProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Folder className="h-5 w-5 text-primary" />
            {name}
          </CardTitle>
          <Badge variant={type === "movies" ? "default" : type === "tvshows" ? "secondary" : "outline"}>
            {type === "movies" ? "Movies" : type === "tvshows" ? "TV Shows" : "Music"}
          </Badge>
        </div>
        <CardDescription className="truncate">{path}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-sm">
          <span>{itemCount} items</span>
          <span>Last scan: {lastScan}</span>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between border-t bg-muted/50 px-6 py-3">
        <Button variant="outline" size="sm">
          <RefreshCw className="mr-2 h-4 w-4" />
          Scan
        </Button>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm">
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
            <Trash2 className="mr-2 h-4 w-4" />
            Remove
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
