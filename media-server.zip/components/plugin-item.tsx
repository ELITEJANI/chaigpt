import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Settings, Trash2 } from "lucide-react"
import { Switch } from "@/components/ui/switch"

interface PluginItemProps {
  id: string
  name: string
  description: string
  version: string
  author: string
  isEnabled: boolean
  isOfficial: boolean
}

export function PluginItem({ id, name, description, version, author, isEnabled, isOfficial }: PluginItemProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            {name}
            {isOfficial && (
              <Badge variant="secondary" className="ml-2">
                Official
              </Badge>
            )}
          </CardTitle>
          <Switch checked={isEnabled} />
        </div>
        <CardDescription>
          v{version} by {author}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter className="flex justify-between border-t bg-muted/50 px-6 py-3">
        <Button variant="outline" size="sm">
          <Settings className="mr-2 h-4 w-4" />
          Configure
        </Button>
        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
          <Trash2 className="mr-2 h-4 w-4" />
          Uninstall
        </Button>
      </CardFooter>
    </Card>
  )
}
