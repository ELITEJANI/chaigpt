import { LibraryItem } from "@/components/library-item"

export function LibraryList() {
  const libraries = [
    {
      id: "1",
      name: "Movies",
      path: "/media/movies",
      type: "movies" as const,
      itemCount: 1248,
      lastScan: "Today, 2:30 PM",
    },
    {
      id: "2",
      name: "TV Shows",
      path: "/media/tvshows",
      type: "tvshows" as const,
      itemCount: 342,
      lastScan: "Today, 2:30 PM",
    },
    {
      id: "3",
      name: "Kids Movies",
      path: "/media/kids/movies",
      type: "movies" as const,
      itemCount: 156,
      lastScan: "Yesterday, 9:15 AM",
    },
    {
      id: "4",
      name: "Documentaries",
      path: "/media/documentaries",
      type: "movies" as const,
      itemCount: 87,
      lastScan: "3 days ago",
    },
    {
      id: "5",
      name: "Anime",
      path: "/media/anime",
      type: "tvshows" as const,
      itemCount: 45,
      lastScan: "1 week ago",
    },
  ]

  return (
    <div className="grid gap-4">
      {libraries.map((library) => (
        <LibraryItem key={library.id} {...library} />
      ))}
    </div>
  )
}
