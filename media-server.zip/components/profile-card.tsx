"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { motion } from "framer-motion"

interface ProfileCardProps {
  id: string
  name: string
  avatar?: string
  isKid?: boolean
}

export function ProfileCard({ id, name, avatar, isKid }: ProfileCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Link href="/">
      <motion.div
        className="relative"
        initial={{ scale: 1, y: 0 }}
        whileHover={{
          scale: 1.05,
          y: -10,
          transition: { duration: 0.2 },
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <Card className={`overflow-hidden border-0 bg-transparent ${isKid ? "bg-blue-500/10" : ""}`}>
          <CardContent className="flex flex-col items-center gap-4 p-6">
            <Avatar className="h-24 w-24 border-2 border-primary">
              <AvatarImage src={avatar || "/placeholder.svg?height=96&width=96"} alt={name} />
              <AvatarFallback className="text-2xl">{name.charAt(0)}</AvatarFallback>
            </Avatar>
            <h3 className={`text-center text-lg font-medium ${isKid ? "text-blue-500" : ""}`}>{name}</h3>
          </CardContent>
        </Card>
      </motion.div>
    </Link>
  )
}
